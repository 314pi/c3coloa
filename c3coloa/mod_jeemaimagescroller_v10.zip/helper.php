<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
 
class ModJeemaImageScroller {
    
    public function getImages($args){
      $thumb_folder = JPATH_BASE.$args['thumb_folder'];
      $large_folder = JPATH_BASE.$args['large_folder'];
      $no_of_images = $args['no_of_images'];
      $random_images = $args['random_images'];
      
      // check folder:
      if (!is_dir($thumb_folder)){
        echo "problem on finding the folder ".$thumb_folder;
        return;
      }
      
      // create files array
      $files = array();

      // open directory
      if ($dir = @opendir($thumb_folder)){
        
        // go trough all files:
        while($file = readdir($dir)){
          if (strpos($file, '.gif',1)||strpos($file, '.jpg',1) || strpos($file,'.png') ) {
            // feed the array:
            $files[] = $file;
          }
        }
      // close directory
      closedir($dir);    
    } else {
        echo "problem on opening folder ".$thumb_folder;
    }
    if($random_images == "1"){
      $filekeys = array_rand($files,$no_of_images);
      $keycount = count($filekeys);
      for($i=0;$i<$no_of_images;$i++){
      	$newfiles[$i] = $files[$filekeys[$i]];
      }
      $files = $newfiles;
    }else{
    	$files = array_slice($files,0,$no_of_files,'');
    }

    return $files;
  }

}  
