<?php
//no direct access
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
 
// include the helper file
require_once(dirname(__FILE__).DS.'helper.php');

// get a parameter from the module's configuration
$args['moduleclass_sfx'] = $params->get('moduleclass_sfx');
$args['thumb_folder'] = $params->get('thumb_folder');
$args['large_folder'] = $params->get('large_folder');
$args['no_of_images'] = $params->get('no_of_images');
$args['random_images'] = $params->get('random_images');

$files = ModJeemaImageScroller::getImages($args);

// include the template for display
require(JModuleHelper::getLayoutPath('mod_jeemaimagescroller'));
?>
