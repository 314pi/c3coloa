<?php defined('_JEXEC') or die('Restricted access'); // no direct access ?>

<?php
  // get the parameter values
  $scroll_direction = $params->get('scroll_direction');
  $scroll_amount = $params->get('scroll_amount');
  $scroll_delay = $params->get('scroll_delay');
  $container_width = $params->get('container_width');
  $container_height = $params->get('container_height');
?>

<?php
  $thumb_folder = JURI::base().$params->get('thumb_folder');
  $large_folder = JURI::base().$params->get('large_folder');
  $thumb_width = $params->get('thumb_width');
  $thumb_height = $params->get('thumb_height');
  $enable_scroll = $params->get('enable_scroll');
?>

<?php
  if($enable_scroll == "1"){
?>
<marquee behavior="scroll" 
	       direction="<?php echo $scroll_direction; ?>"
	       loop="infinite"
         height="<?php echo $container_height; ?>"
         width="<?php echo $container_width; ?>"
         scrollamount="<?php echo $scroll_amount; ?>"
         scrolldelay="<?php echo $scroll_delay; ?>"
         onmouseover="this.stop()" onmouseout="this.start()">
<?php
  }
?>

<?php
  foreach ($files as $file) {
    $thumb_image = $thumb_folder.DS.$file;
    $large_image = $large_folder.DS.$file;
?>
    <a rel="lightbox" class="jcepopup" href="<?php echo $large_image; ?>"><img src="<?php echo $thumb_image;?>" width="<?php echo $thumb_width;?>" height="<?php echo $thumb_height;?>" /></a> <br/><br/>
<?php
  }
?>

<?php
  if($enable_scroll == "1"){
?>
</marquee>
<?php
  }
?>
