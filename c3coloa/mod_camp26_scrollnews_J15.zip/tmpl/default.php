<?php 
/**
* Module Camp26 Scroll News For Joomla 1.5.x
* Version 		: 1.0
* Created by 	: Rony Sandra Yofa Zebua - Yarfik Ardiansyah- camp26.biz Team
* License 		: http://www.gnu.org/copyleft/gpl.html GNU/GPL
* Email 		: camp26team@gmail.com
* Created on 	: 14 December 2008
* URL 			: http://www.camp26.biz
*/
// no direct access
defined('_JEXEC') or die('Restricted access'); 

$height 	= intval( $params->get( 'height', 20 ) );
$width 		= intval( $params->get( 'width', 100 ) );
$scrollamount 	= intval( $params->get( 'scrollamount', 5 ) );
$company_text 	= $params->get( 'company_text', '#Medio News#') ;
?>
<marquee behavior="scroll" align="center" direction="left" height="<?php echo $height; ?>" scrollamount="<?php echo $scrollamount; ?>" width="<?php echo $width; ?>%" onMouseOver="this.stop()" onMouseOut="this.start()" loop="infinite">
<?php foreach ($list as $item) :  ?>
	<span class="scrollnews1">
		<a href="<?php echo $item->link; ?>" class="latestnews<?php echo $params->get('moduleclass_sfx'); ?>"><?php echo $item->introtext; ?></a>
	</span>
	<span class="scrollnews2">
	<?php echo $company_text; ?>
	</span>
<?php endforeach; ?>
</marquee>