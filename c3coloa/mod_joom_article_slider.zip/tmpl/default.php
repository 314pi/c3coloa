<?php
/**
* @title		PQ Softs Content Slideshow Module
* @version		1.0
* @package		Joomla
* @website		http://www.pqsofts.com
* @copyright	Copyright (C) 2009 PQ Softs. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
$uri 					= JURI::getInstance();
$uniqid					= $params->get('uniqid', "1");
$width					= $params->get('width', "320");
$height					= $params->get('height', "200");
$slide_orientation 		= $params->get('sorient', "1");
$slide_word_limit 		= $params->get('slide_word_limit', "40");
$autoPlay 				= ($params->get("autoPlay", 1)  == 0) ? "false" : "true";
$interval 				= $params->get("interval", 5000);
$speed 					= $params->get("speed", 1000);
$showButton 			= ($params->get("showButton", 1)  == 0) ? false : true;
$showReadon 			= ($params->get("showReadon", 1)  == 0) ? false : true;
$readontext 			= $params->get("readontext", "Read More");
$transition 			= $params->get("transition", "Sine.easeOut");
$limit 					= $params->get("limit", 3);
$document = JFactory::getDocument();
$document->addStyleSheet(JURI::base() . 'modules/mod_pq_contentslider/css/style.css');
$document->addScript(JURI::base() . 'modules/mod_pq_contentslider/script/pq_contentslider.js')
?>
	<script type="text/javascript">
	window.addEvent('domready',function(){
		var pqcntsld<?php echo $uniqid; ?> = new PQSoftsContentSlide({
			box: $('pqscontbox<?php echo $uniqid; ?>'),
			items:[<?php for($i = 1; $i <= $limit-1; $i++){$slideamount= $i.',' ; echo $slideamount;  }  echo $limit;?>],
			<?php if($slide_orientation==1) { ?>
			mode: 'horizontal',
			size: <?php echo $width; ?>,
			<?php } else { ?>
			mode: 'vertical',
			size: <?php echo $height; ?>,
			<?php } ?>
			autoPlay: <?php echo $autoPlay; ?>,
			interval: <?php echo $interval; ?>,
			fxOptions: {
				duration: <?php echo $speed; ?>,
				transition: Fx.Transitions.<?php echo $transition; ?>,
				wait: false
			},
			<?php if($showButton) {?>
			buttons: {
				previous: $('prev<?php echo $uniqid; ?>'),
				next: $('next<?php echo $uniqid; ?>')
			}
			<?php } ?>
		});

	});
	</script>
<div id="pqscontbg<?php echo $uniqid; ?>">
<div class="pqscontmask<?php echo $uniqid; ?>">
<div id="pqscontbox<?php echo $uniqid; ?>">
<?php
foreach ($list as $item) :
?>

<div class="inner">
	<div class="inside">
<?php
		$src = '/src=[\'"]?([^\'" >]+)[\'" >]/'; 
		preg_match($src, $item->introtext, $match);
		if ($match) {
		echo "<img class=\"bg-img\" $match[0] alt=\"slide image\" align=\"right\" />";
		}
?>
<h4 class="title"><?php echo $item->title; ?></h4>
<p class="description">
	<?php 
		echo pqcntsldwordslimit(JFilterOutPut::cleanText($item->introtext),$slide_word_limit); 
		echo "...";
		$link = JRoute::_(ContentHelperRoute::getArticleRoute($item->slug, $item->catslug, $item->sectionid));
		if($showReadon) :
		 echo "<br /><a class=\"readon\" href='$link'>$readontext</a>";
		 endif ;
	?>
</p>
</div>
</div>
<?php endforeach; ?>
	
</div>
</div>
<?php if($showButton==true) {?>
	<div id="prev<?php echo $uniqid;?>" class="button-left<?php echo $uniqid;?>">
	</div>
	<div id="next<?php echo $uniqid;?>" class="button-right<?php echo $uniqid;?>">
	</div>
<?php } ?>	
</div>
<?php 
$style = '#pqscontbg'.$uniqid.'{width:'.$width.'px;}#pqscontbox'.$uniqid.' .inner{width:'.$width.'px;height:'.$height.'px;}.pqscontmask'.$uniqid.'{width:'.$width.'px;height:'.$height.'px;}'; 
$document->addStyleDeclaration( $style );
?>