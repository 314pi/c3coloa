<?php
/**
* @title		PQ Softs Content Slideshow Module
* @version		1.0
* @package		Joomla
* @website		http://www.pqsofts.com
* @copyright	Copyright (C) 2009 PQ Softs. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');

class modPQContentSildeHelper
{
	function getList(&$params)
	{
		global $mainframe;
		$db 	        = &JFactory::getDBO();
		$contentConfig	= &JComponentHelper::getParams( 'com_content' );
		$date 			= &JFactory::getDate();
		$now 			= $date->toMySQL();
		$catid 			= $params->get("catid", 1);
		$limit 			= $params->get("limit", 3);
		$nullDate		= $db->getNullDate();
		$query = 'SELECT a.*,' .
			' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(":", a.id, a.alias) ELSE a.id END as slug,'.
			' CASE WHEN CHAR_LENGTH(cc.alias) THEN CONCAT_WS(":", cc.id, cc.alias) ELSE cc.id END as catslug'.
			' FROM #__content AS a' .
			' INNER JOIN #__categories AS cc ON cc.id = a.catid' .
			' INNER JOIN #__sections AS s ON s.id = a.sectionid' .
			' WHERE a.state = 1 ' .
			' AND (a.publish_up = '.$db->Quote($nullDate).' OR a.publish_up <= '.$db->Quote($now).' ) ' .
			' AND (a.publish_down = '.$db->Quote($nullDate).' OR a.publish_down >= '.$db->Quote($now).' )' .
			' AND cc.id = '. (int) $catid .
			' AND cc.section = s.id' .
			' AND cc.published = 1' .
			' AND s.published = 1' .
			' ORDER BY a.ordering';
		$db->setQuery($query, 0, $limit);
		$rows = $db->loadObjectList();	
		return $rows;
	}
}

function pqcntsldwordslimit($string, $word_limit) {
     $words = explode(' ', $string);
     return implode(' ', array_slice($words, 0, $word_limit));
} 