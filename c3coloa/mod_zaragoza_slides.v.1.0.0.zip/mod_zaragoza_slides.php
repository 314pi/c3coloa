<?php

/**

		Zaragoza Online Lastest News

		Based on Lastest News Joomla core module.

		GNU license

*/



// no direct access

defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once

require_once (dirname(__FILE__).DS.'helper.php');

$list = modZaragozaSlidesHelper::getList($params);

require(JModuleHelper::getLayoutPath('mod_zaragoza_slides'));