<?php // no direct access
defined('_JEXEC') or die('Restricted access'); 
$document =& JFactory::getDocument();
$document->addScript( JURI::base() .'modules/mod_zaragoza_slides/js/zaragoza_slides.js' );

$width = (int) $params->get('width',600);

$header_padding_left = (int) $params->get('header_padding_left',20);
$header_padding_right = (int) $params->get('header_padding_right',20);
$header_padding_top = (int) $params->get('header_padding_top',12);
$header_padding_bottom = (int) $params->get('header_padding_bottom',12);
$intro_padding_left = (int) $params->get('intro_padding_left',20);
$intro_padding_right = (int) $params->get('intro_padding_right',20);
$intro_padding_top = (int) $params->get('intro_padding_top',7);
$intro_padding_bottom = (int) $params->get('intro_padding_bottom',7);
$readmore_padding_left = (int) $params->get('readmore_padding_left',20);
$readmore_padding_right = (int) $params->get('readmore_padding_right',20);
$readmore_padding_top = (int) $params->get('readmore_padding_top',12);
$readmore_padding_bottom = (int) $params->get('readmore_padding_bottom',0);
$height = (int) $params->get('height',300);
$texto = ''; $background = ''; $mascara_background = ''; $botones_background = '';
$border_left = ''; $border_right = ''; $texto1 = '';
$topbar_background = ''; $bottombar_background = '';

if($params->get('show_images',0)) {
	$texto1 = '
background-image:url('.JURI :: base().$params->get('folder','modules/mod_zaragoza_slides/images/').$params->get('image','image.jpg').');
background-repeat:no-repeat;
background-position:left top;';
}
if($params->get('show_borders',1)) {
	$border_left = 'border-left:'.$params->get('border','#FFF').' 1px solid;';
	$border_right = 'border-right:'.$params->get('border','#FFF').' 1px solid;';
}

if($params->get('show_header_background',1)==1) $header_background = '
background-image:url('.JURI :: base().'modules/mod_zaragoza_slides/images/transback.png);
background-repeat:repeat';
if($params->get('show_header_background',1)==2) $header_background = 'background-color:'.$params->get('header_background','#006699').';';	
if($params->get('show_backgrounds',1)) $background = 'background-color:'.$params->get('background','#333').';';
if($params->get('show_slides_backgrounds',1)) $mascara_background = 'background-color:'.$params->get('slides_background','#e3e1e0').';';
if($params->get('show_buttons_backgrounds',1)) $botones_background = 'background-color:'.$params->get('button_background','#333').';';
if($params->get('show_buttons_backgrounds_hover',1)) $botones_background_hover = 'background-color:'.$params->get('button_background_hover','#b73427').';';

if($params->get('show_topbar_background',1)) $topbar_background= 'background-color:'.$params->get('topbar_background','#FFF').';';
if($params->get('show_bottombar_background',1)) $bottombar_background = 'background-color:'.$params->get('bottombar_background','#000').';';


$estilos_aux = '';

if($params->get('show_slidesimages',1)) {

	$images = $params->get('image_list','');
	$images_array = explode(",",$images);
	$ii=0;
	foreach($images_array as $image) { 
		$ii++;
		$estilos_aux .= '
#zslide-'.$ii.'{
background-image:url('.JURI :: base().$params->get('folder','modules/mod_zaragoza_slides/images/').trim($image).');
background-repeat:no-repeat;
background-position:left top;
 }';
	}
}

if(!$params->get('show_header',1)) 	$estilos_aux .= '
.zaragoza-slides-container h3{
display:none;
visibility:hidden;
 }';


if($params->get('include_css',1)==2) 	$document->addStyleSheet(JURI :: base().'modules/mod_zaragoza_slides/css/'.$params->get('css','css1').'.css');
 
if($params->get('include_css',1)==1)	$document->addCustomTag('

<!-- Zaragoza Slides Styles -->
<style type="text/css">

.zaragoza-slides-container{
'.$background.$texto1.'
width:'.$width.'px;
}

#caja{
position:absolute;
}
.zaragoza-slides-slide{
width:'.$width.'px;
height:'.$height.'px;
float:left;
}
.zsh3{
	padding-top: '.$header_padding_top.'px;
	padding-right: '.$header_padding_right.'px;
	padding-bottom: '.$header_padding_bottom.'px;
	padding-left: '.$header_padding_left.'px;
'.$header_background.'
}
.zsh3 h3{
	color:'.$params->get('h3color','#FFF').';
}
.zsintrotext{
	padding-top: '.$intro_padding_top.'px;
	padding-right: '.$intro_padding_right.'px;
	padding-bottom: '.$intro_padding_bottom.'px;
	padding-left: '.$intro_padding_left.'px;
}
.zo-last-readmore-div{
	padding-top: '.$readmore_padding_top.'px;
	padding-right: '.$readmore_padding_right.'px;
	padding-bottom: '.$readmore_padding_bottom.'px;
	padding-left: '.$readmore_padding_left.'px;
}

#caja .buttons{
text-align:left
}
.zsplayer{
float:right;
margin-top:1px;
}
#zstabs{
'.$topbar_background.'
}
#bottombar{
'.$bottombar_background.'
}
.zsplayer-boton{
float:right;
padding:5px;
'.$botones_background.'
'.$border_left.'
}
.zsnumeros{
float:left;
margin-top:1px;
}
.zsnumero {
float:left;
padding:5px;
'.$botones_background.'
'.$border_right.'
}
.zstab{
float:left;
font-size:1.1em;
padding:7px;
padding-left:14px;
padding-right:14px;
'.$botones_background.'
'.$border_right.'
}
.zstab a:link, .zstab a:visited, .zsnumero a:link, .zsnumero a:visited, .zsplayer-boton a:link, .zsplayer-boton a:visited {
color:'.$params->get('button_link','#FFF').';
text-decoration:none;
}
.zstab a:hover, .zsnumero a:hover, .zsplayer-boton a:hover{
color:'.$params->get('button_link_hover','#FFF').';
text-decoration:none;
}
.zstab:hover, .zsnumero:hover, .zsplayer-boton:hover{
'.$botones_background_hover.'
}
.zstab.active, .zsnumero.active, .zsplayer-boton.active{
'.$botones_background_hover.'
}
.zstab:hover, .zsnumero:hover, .zsplayer-boton:hover{
'.$botones_background_hover.'
}
.zstab:hover a:link, .zsnumero:hover a:link, .zsplayer-boton:hover a:link, .zstab:hover a:visited, .zsnumero:hover a:visited, .zsplayer-boton:hover a:visited{
color:'.$params->get('button_link_hover','#FFF').';
}
.zstab.active a:link, .zsnumero.active a:link, .zsplayer-boton.active a:link, .zstab.active a:visited, .zsnumero.active a:visited, .zsplayer-boton.active a:visited{
color:'.$params->get('button_link_hover','#FFF').';
}

.zsclear{
clear:both;
}
.zaragoza-slides-container .buttons{
text-align:center;
clear:both;
}

.mascara{
position:relative;
width:'.$width.'px;
height:'.$height.'px;
overflow:hidden;
border-bottom:#FFFFFF 1px solid;
border-top:#FFFFFF 1px solid;
'.$mascara_background.'
}'.$estilos_aux.'
</style>
<!-- End of Zaragoza Slides Styles -->
		');
		
		
if($params->get('mode','horizontal')=='horizontal') $size = (int) $params->get('width',480)	;
else  $size = (int) $params->get('height',200);
		
?>
<script type="text/javascript">
	window.addEvent('domready',function(){
		<?php if($params->get('show_numbers',1)) { ?>var zsnumeros = $$('#zsnumeros div');<?php } ?>
		var ZnSlide = new ZaragozaSlide({
			box: $('caja'),
			items: $$('#caja h3'),
			mode:'<?php echo($params->get('mode','horizontal')); ?>',
			transition_:<?php echo($params->get('transition','Fx.Transitions.Quart.easeIn')); ?>,
			duration_:'<?php echo($params->get('duration',500)); ?>',
			size: <?php echo($size); ?>,
			<?php if($params->get('autoplay',0)) { ?>autoPlay: true,<?php } ?>
			handles: $$('#zstabs div'),
			interval:<?php echo($params->get('interval',5000)); ?>, 
			<?php if($params->get('show_player',1)) { ?>addButtons: {play: $('zsplay'), stop: $('zsstop')},<?php } ?>
			onWalk: function(currentItem,currentHandle){
				<?php if($params->get('show_numbers',1)) { ?>
				$$(this.handles,zsnumeros).removeClass('active');
				$$(zsnumeros[this.currentIndex]).addClass('active');
				<?php } ?>
				<?php if($params->get('show_tabs',1)) { ?>
				$$(this.handles).removeClass('active');
				$$(currentHandle).addClass('active');
				<?php } ?>
			}
		});
		 <?php if($params->get('show_numbers',1)) { ?>ZnSlide.addHandleButtons(zsnumeros);<?php } ?>
		ZnSlide.walk(0,true,true);
	});
	</script>
<div class="zaragoza-slides-container <?php echo $params->get('moduleclass_sfx'); ?>">
    <?php if($params->get('show_tabs',1)&&$params->get('tab_list','')) { 
	
		$tabs = $params->get('tab_list','');
		$tabs_array = explode(",",$tabs);
		$cuantos_tabs = count($tabs_array);
	?>
    <div class="buttons" id="zstabs">
    	<?php foreach($tabs_array as $tab) { ?>
        <div class="zstab"><span><a href="javascript:void(null);"><?php echo trim($tab); ?></a></span></div>
        <?php } ?>
        <div class="zsclear"></div>
    </div>
  <?php } ?>
		
    <div class="mascara">
        <div id="caja">
        <?php 
            $i=0;
            foreach ($list as $item) { 
                $i++;
				if($params->get('striptags',0)) $item->introtext = strip_tags($item->introtext,$params->get('allowed_tag',''));
				if($params->get('recortar_intro',0)&&strlen($item->introtext)>$params->get('max_characters',300))  $item->introtext = substr($item->introtext,0,$params->get('max_characters',300)).'...';
                ?>
                <div class="zaragoza-slides-slide" id="zslide-<?php echo $i; ?>">
                	<div class="zsh3"><h3><?php echo $item->text; ?></h3></div>
                    <div class="zsintrotext"><?php echo $item->introtext; ?></div>
                    <?php  if($params->get('show_readmore',1)) { ?><div class="zo-last-readmore-div"><span class="zo-last-readmore"><a href="<?php echo $item->link; ?>"><?php echo $params->get('readmore_TEXT','Leer m&aacute;s'); ?></a></span></div><?php   }  ?>
                </div>
        <?php } ?>
        </div>
    </div>
    
    <?php if($params->get('show_numbers',1)||$params->get('show_player',1)) { ?>
	<div class="buttons" id="bottombar">
    	<?php if($params->get('show_player',1)) { ?>
    	<div class="zsplayer">
        	<div class="zsplayer-boton"><span id="zsplay"><a href="javascript:void(null);"><?php echo $params->get('play','Play'); ?></a></span></div>
            <div class="zsplayer-boton"><span id="zsstop"><a href="javascript:void(null);"><?php echo $params->get('stop','Stop'); ?></a></span></div>
            <div class="zsclear"></div>
        </div>
        <?php  } ?>
        <?php if($params->get('show_numbers',1)) { ?>
    	<div id="zsnumeros">
		<?php 
            $i=0;
            foreach ($list as $item) { 
                $i++;
                ?>
			<div class="zsnumero"><a href="javascript:void(null);"><span><?php echo $i; ?></span></a></div>
        <?php } ?>
        	<div class="zsclear"></div>
		</div>
        <?php  } ?>
        <div class="zsclear"></div>
    </div>
    <?php  } ?>
</div>