<?php
/**
		Zaragoza Online Lastest News
		Based on Lastest News Joomla core module.
		GNU license
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');

class modZaragozaSlidesHelper
{
	function getList(&$params)
	{
		global $mainframe;

		$db			=& JFactory::getDBO();
		$user		=& JFactory::getUser();
		$userId		= (int) $user->get('id');
		
		$ids_ = $params->get('ids_', '');

		$count		= (int) $params->get('count', 5);
		$catid		= trim( $params->get('catid') );
		
		$categorias_si = trim( $params->get('_catid','') );
		$tags_option = $params->get('tags_option',0) ;
		
		$secid		= trim( $params->get('secid') );
		$show_front	= $params->get('show_front', 1);
		$aid		= $user->get('aid', 0);

		$contentConfig = &JComponentHelper::getParams( 'com_content' );
		$access		= !$contentConfig->get('show_noauth');

		$nullDate	= $db->getNullDate();

		$date =& JFactory::getDate();
		$now = $date->toMySQL();

		$where		= 'a.state = 1'
			. ' AND ( a.publish_up = '.$db->Quote($nullDate).' OR a.publish_up <= '.$db->Quote($now).' )'
			. ' AND ( a.publish_down = '.$db->Quote($nullDate).' OR a.publish_down >= '.$db->Quote($now).' )'
			;


		if(!$tags_option) $sufijo = ' OR ';
		else $sufijo = ' AND ';

		if($categorias_si)	{
		
			//$document->setTitle($categorias_si);
			$where .= ' AND (  ';
			$input_text = str_replace(', ', ',', $categorias_si);
			$input_text = str_replace(' ,', ', ', $input_text);
			$input_text = mb_strtolower($input_text,"UTF-8");
			
			$palabras_array = preg_split("/,/", $input_text); 
			
			$numero = 0;
			
			foreach($palabras_array as $palabra){
				if($numero) $where .= $sufijo;
				$where .= " 
				( 
					LCASE(a.metakey)='".$palabra."' OR 
					LCASE(a.metakey) LIKE '".$palabra.", %'  OR 
					LCASE(a.metakey) LIKE '%,".$palabra."' OR 
					LCASE(a.metakey) LIKE '%, ".$palabra."'  OR 
					LCASE(a.metakey) LIKE '%,".$palabra.",%' OR 
					LCASE(a.metakey) LIKE '%, ".$palabra.",%' 
				) ";
				$numero = $numero + 1;
			}
			$where .= ' ) ';
		}


		// User Filter
		switch ($params->get( 'user_id' ))
		{
			case 'by_me':
				$where .= ' AND (created_by = ' . (int) $userId . ' OR modified_by = ' . (int) $userId . ')';
				break;
			case 'not_me':
				$where .= ' AND (created_by <> ' . (int) $userId . ' AND modified_by <> ' . (int) $userId . ')';
				break;
		}

		if($ids_) {
				$where	= 'a.state = 1'
			. ' AND ( a.publish_up = '.$db->Quote($nullDate).' OR a.publish_up <= '.$db->Quote($now).' )'
			. ' AND ( a.publish_down = '.$db->Quote($nullDate).' OR a.publish_down >= '.$db->Quote($now).' ) AND ('
			;
			$contador = 0;
			$ids= explode(',',$ids_);
			foreach($ids as $id){
				if($contador) $where .= ' OR ';
				$where .= '  a.id ='.trim($id);
				$contador++;
			}
			$where .= ' ) ';
		}

		// Ordering
		switch ($params->get( 'ordering' ))
		{
			case 'm_dsc':
				$ordering		= 'a.modified DESC, a.created DESC';
				break;
			case 'c_dsc':
			default:
				$ordering		= 'a.created DESC';
				break;
		}

		if ($catid)
		{
			$ids = explode( ',', $catid );
			JArrayHelper::toInteger( $ids );
			$catCondition = ' AND (cc.id=' . implode( ' OR cc.id=', $ids ) . ')';
		}
		if ($secid)
		{
			$ids = explode( ',', $secid );
			JArrayHelper::toInteger( $ids );
			$secCondition = ' AND (s.id=' . implode( ' OR s.id=', $ids ) . ')';
		}

		// Content Items only
		$query = 'SELECT a.*, ' .
			' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(":", a.id, a.alias) ELSE a.id END as slug,'.
			' CASE WHEN CHAR_LENGTH(cc.alias) THEN CONCAT_WS(":", cc.id, cc.alias) ELSE cc.id END as catslug, cc.title as category '.
			' FROM #__content AS a' .
			($show_front == '0' ? ' LEFT JOIN #__content_frontpage AS f ON f.content_id = a.id' : '') .
			' INNER JOIN #__categories AS cc ON cc.id = a.catid' .
			' INNER JOIN #__sections AS s ON s.id = a.sectionid' .
			' WHERE '. $where .' AND s.id > 0' .
			($access ? ' AND a.access <= ' .(int) $aid. ' AND cc.access <= ' .(int) $aid. ' AND s.access <= ' .(int) $aid : '').
			($catid ? $catCondition : '').
			($secid ? $secCondition : '').
			($show_front == '0' ? ' AND f.content_id IS NULL ' : '').
			' AND s.published = 1' .
			' AND cc.published = 1' .
			' ORDER BY '. $ordering;
		$db->setQuery($query, 0, $count);
		$rows = $db->loadObjectList();

		$i		= 0;
		$lists	= array();
		
		if($ids_) {
			foreach($ids as $id){
				foreach ( $rows as $row ) {
					if($row->id==trim($id)) {
						if($row->access <= $aid) $lists[$i]->link = JRoute::_(ContentHelperRoute::getArticleRoute($row->slug, $row->catslug, $row->sectionid));
						else $lists[$i]->link = JRoute::_('index.php?option=com_user&view=login');
						$lists[$i]->text = htmlspecialchars( $row->title );
						$lists[$i]->introtext = $row->introtext;
						$lists[$i]->category = $row->category;
						$lists[$i]->created = $row->created;
						$i++;
					}
				}
			}		
		} else {
			foreach ( $rows as $row ) {
				if($row->access <= $aid) $lists[$i]->link = JRoute::_(ContentHelperRoute::getArticleRoute($row->slug, $row->catslug, $row->sectionid));
				else $lists[$i]->link = JRoute::_('index.php?option=com_user&view=login');
				$lists[$i]->text = htmlspecialchars( $row->title );
				$lists[$i]->introtext = $row->introtext;
				$lists[$i]->category = $row->category;
				$lists[$i]->created = $row->created;
				$i++;
			}
		}
		return $lists;
	}
}
