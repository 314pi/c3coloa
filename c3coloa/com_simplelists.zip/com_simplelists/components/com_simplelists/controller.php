<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('No access');

// Import the parent library
jimport('joomla.application.component.controller');

/**
 * Simplelists Component Controller
 * 
 * @package Joomla
 * @subpackage Simplelists
 */
class SimplelistsController extends JController
{
    /**
     * Method to display the right JView 
     *
     * @access public
     * @param null
     * @return null
     */
    public function display()
    {
        // Make sure we have a default view
        if( !JRequest::getVar( 'view' )) {
            JRequest::setVar('view', 'simplelist' );
        }

        // Make sure we load the right layout
        if( JRequest::getVar('view') == 'simplelist' && in_array(JRequest::getVar('format'), array('pdf', 'print'))) {
            JRequest::setVar('layout', 'print');
        }

        parent::display();
    }

    /**
     * Method to handle voting (inactive)
     *
     * @access public
     * @param null
     * @return null
     */
    public function vote()
    {
        $url = JRequest::getVar('url', '', 'default', 'string');
        $rating = JRequest::getVar('user_rating', 0, '', 'int');
        $id = JRequest::getVar('cid', 0, '', 'int');

        $model = $this->getModel('item');
        $model->setId($id);

        if(!JURI::isInternal($url)) {
            $url = JRoute::_('index.php?option=com_simplelists&view=simplelist&id='.$id);
        }

        if ($model->storeVote($rating)) {
            $this->setRedirect($url, JText::_('Thanks for rating for this item!'));
        } else {
            $this->setRedirect($url, JText::_('You already rated this item today!'));
        }
    }
}
