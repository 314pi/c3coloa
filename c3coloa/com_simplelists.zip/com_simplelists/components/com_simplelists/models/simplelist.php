<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');

/**
 * Simplelists Component Simplelist Model
 */
class SimplelistsModelSimplelist extends JModel
{
	/**
	 * Simplelist id
	 *
	 * @private int
	 */
	private $_id = null;

	/**
	 * Simplelist category
	 *
	 * @private int
	 */
	private $_category = null;

	/**
	 * Simplelist data
	 *
	 * @private array
	 */
	private $_data = null;

    /**
     * Template total
     *
     * @private integer
     */
    private $_total = null;

    /**
     * Pagination object
     *
     * @private object
     */
    private $_pagination = null;

	/**
	 * Constructor
	 *
	 */
	public function __construct()
	{
		parent::__construct();
        global $option;

        $mainframe =& JFactory::getApplication() ;
         $config = JFactory::getConfig() ;

		$this->setId( JRequest::getInt('category_id', '0' ));
		$this->setIdByAlias( JRequest::getString('alias', '' ));

        // Get the pagination request variables
        $limit = $mainframe->getUserStateFromRequest( 'global.list.limit', 'limit', $config->getValue('config.list_limit'), 'int' );
        $limitstart = JRequest::getInt( 'limitstart', 0 );

        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
	}

	/**
	 * Method to set the simplelist identifier
	 *
	 * @access	public
	 * @param	int Simplelist identifier
	 */
	public function setId($id)
	{
		$this->_id = $id;
	}

	/**
	 * Method to set the simplelist alias
	 *
	 * @access	public
	 * @param	string Simplelist category-alias
	 */
	public function setIdByAlias($alias)
	{
        if(empty($this->_id)) {
            require_once JPATH_ADMINISTRATOR.DS.'components'.DS.'com_simplelists'.DS.'helpers'.DS.'category.php';
	    	$this->_id = SimplelistsCategoryHelper::getId($alias);
        }
	}

	/**
	 * Method to get a simplelist
	 *
	 */
	public function getData($params = null)
	{
		$this->loadData($params) ;
        if( $this->_pagination ) {
            $data = array_slice( $this->_data, $this->getState('limitstart'), $this->getState('limit'));
            return $data ;
        } else {
            return $this->_data ;
        }
	}

	/**
	 * Method to load content simplelist data
	 *
	 * @access	private
	 * @return	boolean	True on success
	 */
	public function loadData($params = null)
	{
        $user = &JFactory::getUser();

		// Lets load the content if it doesn't already exist
		if (empty($this->_data))
		{
            $this->_data = array();

            // Construct the query
            $where = $this->getWhere() ;
            $orderby = $this->getOrderby($params) ;
			$query = 'SELECT w.*, c.title AS category'.
					' FROM #__simplelists_categories AS sc' .
					' LEFT JOIN #__simplelists AS w ON w.id = sc.id' .
					' LEFT JOIN #__categories AS c ON c.id = sc.category_id' .
					' WHERE sc.category_id = '.(int)$this->_id .
                    ' AND c.published = 1' .
                    ' AND w.published = 1' .
                    $where .
                    $orderby ;

            // Fetch the data from the database
			$this->_db->setQuery($query);
			$this->_data = $this->_db->loadObjectList();

            // Set the data count
            $this->_total = count( $this->_data ) ;

			return $this->_data;
		}
		return array() ;
	}

	/**
	 * Method to get a simplelist
	 *
	 */
	public function getCategory()
	{
		if( ! $this->_category )
		{
            $this->_loadCategory();
        }
		return $this->_category;
	}

    /**
	 * Method to load category data if it doesn't exist.
	 *
	 * @access	private
	 * @return	boolean	True on success
	 */
	public function _loadCategory()
	{
        $user = &JFactory::getUser();

		if (empty($this->_category))
		{
			// current category info
			$query = 'SELECT c.*, ' .
				' CASE WHEN CHAR_LENGTH(c.alias) THEN CONCAT_WS(\':\', c.id, c.alias) ELSE c.id END as slug '.
				' FROM #__categories AS c' .
				' WHERE c.id = '. (int) $this->_id .
				' AND c.section = "com_simplelists"'
            ;
			$this->_db->setQuery($query, 0, 1);
			$this->_category = $this->_db->loadObject();

            if( $this->_category == null ) {
                return $this->_initCategory();

            } else {

                // Make sure the category is published
                if (!$this->_category->published) {
                    JError::raiseError( 404, JText::_("Resource Not Found"));
                    return false;
                }

                // Check whether category access level allows access
                if ($this->_category->access > $user->get('aid', 0)) {
                    JError::raiseError( 403, JText::_('ALERTNOTAUTH') );
                    return false;
                }
            }

            // fetch the related categories (parent and children)
			$query = 'SELECT c.*, ' .
				' CASE WHEN CHAR_LENGTH(c.alias) THEN CONCAT_WS(\':\', c.id, c.alias) ELSE c.id END as slug '.
				' FROM #__categories AS c' .
				' WHERE (c.id = '. (int) $this->_category->parent_id .
                ' OR c.parent_id = '. (int) $this->_category->id . ')' .
				' AND c.section = "com_simplelists"' .
                ' AND c.published = 1' .
                ' ORDER BY ordering'
            ;
			$this->_db->setQuery($query);
			$related = $this->_db->loadObjectList();

            foreach( $related as $id => $cat ) {

                // Make sure this related category is not the parent-category
                if( $cat->id == $this->_category->parent_id ) {
                    $this->_category->parent = $cat;
                    unset( $related[$id] );
                    continue;
                }

                // Check whether category access level allows access
                if ($cat->access > $user->get('aid', 0)) {
                    unset( $related[$id] );
                    continue;
                }
            }
            $this->_category->childs = $related;
		}
		return true;
	}

    /**
     * Method to get the total number of simplelist items
     *
     * @access public
     * @return integer
     */
    public function getTotal()
    {
        return $this->_total;
    }

    /**
     * Method to get a pagination object for the simplelists
     *
     * @access public
     * @return integer
     */
    public function getPagination()
    {
        // Lets load the content if it doesn't already exist
        if (empty($this->_pagination))
        {
            jimport('joomla.html.pagination');
            $this->_pagination = new JPagination( $this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
        }
        return $this->_pagination;
    }

	/**
	 * Method to construct the where syntax for a database query
	 */
    public function getWhere() {

        $db = JFactory::getDBO();
        $where = '' ;
        if( preg_match( '/^([a-z]{1})$/', JRequest::getCmd('char'))) {
            $where .= ' AND w.title LIKE '.$db->Quote(JRequest::getCmd('char').'%') ;
        }
        return $where ;
    }

	/**
	 * Method to construct the ordering for a database query
	 */
    public function getOrderby($params) {

        if(empty($params)) {
            $params = &JComponentHelper::getParams( 'com_simplelists' );
        }

        $ordering = $params->get('orderby');
        switch( $ordering ) {
            case 'alpha': 
                $o = 'w.title ASC' ;
                break ;
            case 'ralpha': 
                $o = 'w.title DESC' ;
                break ;
            case 'date': 
                $o = 'w.created DESC, w.modified DESC' ;
                break ;
            case 'rdate': 
                $o = 'w.created ASC, w.modified ASC' ;
                break ;
            case 'random': 
                $o = 'RAND()' ;
                break ;
            case 'rorder':
                $o = 'w.ordering DESC' ;
                break ;
            default:
                $o = 'w.ordering' ;
                break ;
        }
        return ' ORDER BY '.$o ;
    }

    /**
     * Method to override the default limit configuration
     *
     * @access public
     * @param integer
     * @return boolean
     */
    public function setLimit( $limit ) {
        if( $limit > 0 ) {
            $this->setState('limit', $limit);
            return true ;
        }
        return false ;
    }

	/**
	 * Constructor
	 *
	 */
    public function _initCategory() {
        if (empty($this->_category))
        {
            $category = new stdClass();
            $category->id = 0;
            $category->parent_id = 0;
            $category->title = null;
            $category->name = null;
            $category->alias = null;
            $category->image = null;
            $category->section = null;
            $category->image_position = null;
            $category->description = null;
            $category->published = 0;
            $category->checked_out = 0;
            $category->checked_out_time = 0;
            $category->editor = null;
            $category->ordering = 0;
            $category->access = 0;
            $category->count = 0;
            $category->params = null;
            $this->_category = $category;
        }
        return $this->_category;
    }
}
