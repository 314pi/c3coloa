<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');

/**
 * Simplelists Component Categories Model
 */
class SimplelistsModelCategories extends JModel
{
	/**
	 * Simplelist categories
	 *
	 * @private array
	 */
	private $_categories = null;

	/**
	 * Parent category ID
	 *
	 * @private int
	 */
	private $_parent_id = null;

	/**
	 * Parent category
	 *
	 * @private object
	 */
	private $_parent = null;

    /**
     * Template total
     *
     * @private integer
     */
    private $_total = null;

    /**
     * Pagination object
     *
     * @private object
     */
    private $_pagination = null;

	/**
	 * Constructor
	 */
	public function __construct()
	{
		parent::__construct();
        global $option;

        $mainframe =& JFactory::getApplication() ;
        $config = JFactory::getConfig() ;

        // Get the pagination request variables
        $limit = $mainframe->getUserStateFromRequest( 'global.list.limit', 'limit', $config->getValue('config.list_limit'), 'int' );
        $limitstart = JRequest::getInt( 'limitstart', 0 );

        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
	}

	/**
	 * Method to get a list of categories
	 */
	public function getCategories($orderby = null)
	{
        $this->loadCategories($orderby);
        if( $this->_pagination ) {
            $categories = array_slice( $this->_categories, $this->getState('limitstart'), $this->getState('limit'));
            return $categories ;
        } else {
            return $this->_categories ;
        }
	}

    /**
	 * Method to load category data
	 *
	 * @access	private
	 * @return	boolean	True on success
	 */
	public function loadCategories($orderby = 'ordering')
	{
        // Only initialize the categories if they are not initialized yet
		if (empty($this->_categories))
		{
            if($orderby =='alpha') {
                $orderby = ' ORDER BY c.title ASC';
            } elseif($orderby =='ralpha') {
                $orderby = ' ORDER BY c.title DESC';
            } else {
                $orderby = ' ORDER BY c.'.$orderby;
            }

			// Construct 
			$query = 'SELECT c.*, ' .
				' CASE WHEN CHAR_LENGTH(c.alias) THEN CONCAT_WS(\':\', c.id, c.alias) ELSE c.id END as slug '.
				' FROM #__categories AS c' .
				' WHERE c.section = "com_simplelists" ' . 
                ' AND c.published = 1'
            ;

            if($this->_parent_id > 0) {
                $query .= ' AND c.parent_id = '.(int)$this->_parent_id ;
            }

            $query .= $orderby;

            // Load the categories from the database
			$this->_db->setQuery($query);
			$this->_categories = $this->_db->loadObjectList();

            if(!empty($this->_categories)) {

                $user = &JFactory::getUser();
    
                // Loop through the categories to add specific changes per category 
                foreach($this->_categories as $id => $category) {

                    // Remove categories to which we don't have access
                    if($category->access > $user->get('aid', 0)) {
                        unset($this->_categories[$id]);
                        continue;
                    }

                    $category->params = new JParameter( $category->params );
                    $this->_categories[$id] = $category;

                }
            }
		}
		return true;
	}

    /**
	 * Method to get the fully loaded parent
	 *
	 * @access	private
	 * @return	boolean	True on success
	 */
	public function getParent( $parent_id = null )
	{
		if (empty($this->_parent))
		{
            if( $parent_id != null ) {
                $this->_parent_id = (int)$parent_id ;
            }

			// current category info
			$query = 'SELECT c.*, ' .
				' CASE WHEN CHAR_LENGTH(c.alias) THEN CONCAT_WS(\':\', c.id, c.alias) ELSE c.id END as slug '.
				' FROM #__categories AS c' .
				' WHERE c.id = '.(int)$this->_parent_id;
            ;

			$this->_db->setQuery($query);
			$this->_parent = $this->_db->loadObject();

            if( $this->_parent == null ) {
                return $this->_initParent();

            } else {

                $user = &JFactory::getUser();

                // Make sure the category is published
                if (!$this->_parent->published) {
                    JError::raiseError( 404, JText::_("Resource Not Found"));
                    return false;
                }

                // Check whether category access level allows access
                if ($this->_parent->access > $user->get('aid', 0)) {
                    JError::raiseError( 403, JText::_('ALERTNOTAUTH') );
                    return false;
                }
            }
		}

		return $this->_parent;
	}

    /**
     * Method to get the total number of simplelist items
     *
     * @access public
     * @return integer
     */
    public function getTotal()
    {
        return $this->_total;
    }

    /**
     * Method to get a pagination object for the simplelists
     *
     * @access public
     * @return integer
     */
    public function getPagination()
    {
        // Lets load the content if it doesn't already exist
        if (empty($this->_pagination))
        {
            jimport('joomla.html.pagination');
            $this->_pagination = new JPagination( $this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
        }
        return $this->_pagination;
    }

    /**
     * Method to override the default limit configuration
     *
     * @access public
     * @param integer
     * @return boolean
     */
    public function setLimit( $limit ) {
        if( $limit > 0 ) {
            $this->setState('limit', $limit);
            return true ;
        }
        return false ;
    }

    /**
     * Method to set the parent category
     *
     * @access public
     * @param integer
     * @return boolean 
     */
    public function setParent( $parent_id )
    {
        if( $parent_id > 0 ) {
            $this->_parent_id = $parent_id ;
            return true ;
        }
        return false ;
    }

    /**
     * Method to initialize an empty parent-category
     *
     * @access public
     * @param integer
     * @return boolean 
     */
    public function _initParent() {
        if (empty($this->_parent))
        {
            $category = new stdClass();
            $category->id = 0;
            $category->parent_id = 0;
            $category->title = null;
            $category->name = null;
            $category->alias = null;
            $category->image = null;
            $category->section = null;
            $category->image_position = null;
            $category->description = null;
            $category->published = 0;
            $category->checked_out = 0;
            $category->checked_out_time = 0;
            $category->editor = null;
            $category->ordering = 0;
            $category->access = 0;
            $category->count = 0;
            $category->params = null;
            $this->_parent = $category;
        }
        return $this->_parent;
    }
}
