<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view');

require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'helper.php';

/**
 * HTML View class for the SimpleLists component
 */
class SimplelistsViewCategories extends JView
{
    /*
     * Method to prepare the content for display
     *
     * @param string $tpl
     * @return null
     */
    public function display($tpl = null)
    {
        $params = &JComponentHelper::getParams( 'com_simplelists' );
        $document =& JFactory::getDocument();

        // layout parameters
        $show_category_title = $params->get( 'show_category_title' );
        $show_category_description = $params->get( 'show_category_description' );
        $show_category_image = $params->get( 'show_category_image' );
        $page_title = $params->get( 'page_title');
        $show_page_title = $params->get( 'show_page_title');
        $cat_orderby = $params->get( 'cat_orderby', 'ordering');
        $layout = $params->get( 'layout', 'default' );
        $parent_id = $params->get( 'parent_id', 0 );

        // pagination parameters
        $use_pagination = $params->get('use_pagination');
        $limit = $params->get('limit');

        // get the simplelists from our model
        $model =& $this->getModel();
        $parent = $model->getParent( $parent_id );
        $categories = $model->getCategories( $cat_orderby );

        // set the page title
        if( $show_page_title == 1 && $page_title != '' ) {
            $document->setTitle( $page_title );
            $parent->title = $page_title ;
        } else {
            $document->setTitle( $parent->title );
        }

        // enable pagination
        if( $use_pagination ) {
            // customize pagination
            if( $limit > 0 ) {
                $model->setLimit( $limit ) ;
            }
            $pagination = $model->getPagination() ;
            $this->assignRef( 'pagination', $pagination );
        }

        if( count( $categories ) > 0 ) {

            // loop through the list to set things right
            foreach( $categories as $id => $category ) {
                $layout = $category->params->get( 'layout', $layout );
                $category->link = SimplelistsHelper::getUrl( $category->id, $category->alias, $layout );
                $categories[$id] = $category ;
            }

            $this->assignRef( 'categories', $categories );
        } else {
            $this->assignRef( 'message', JText::_( 'No categories found' ));
        }

        // prepare the image
        if( $show_category_image && !empty( $parent->image )) {
            $parent->image = JHTML::image( $parent->image, $parent->title, 'title="'.$parent->title.'" class="simplelists" align="'.$parent->image_position.'"');
        } else {
            $parent->image = null ;
        }

        $this->assignRef( 'category', $parent );
        $this->assignRef( 'show_category_title', $show_category_title );
        $this->assignRef( 'show_category_description', $show_category_description );
        $this->assignRef( 'show_category_image', $show_category_image );
        $this->assignRef( 'use_pagination', $use_pagination );

        parent::display($tpl);
    }
}
