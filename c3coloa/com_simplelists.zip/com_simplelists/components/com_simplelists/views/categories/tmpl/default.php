<?php 
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

$document =& JFactory::getDocument();
$document->addStyleSheet($this->baseurl.'/components/com_simplelists/css/categories.css');
?>

<?php if( $this->show_category_title ) { ?><h1 class="componentheading"><?php echo $this->category->title ?></h1><?php } ?>

<?php if( $this->show_category_image || $this->show_category_description ) { ?>
<div class="simplelists-category">
    <?php if( $this->show_category_image ) { echo $this->category->image; } ?>
    <?php if( $this->show_category_description ) { ?><span id="simplelists-description"><?php echo $this->category->description ?></span><?php } ?>
</div>
<?php } ?>


<?php if( $this->use_pagination ) { ?>
    <div class="simplelists-pagecounter">
    <?php echo $this->pagination->getPagesCounter(); ?>
    </div>
<?php } ?>

<div class="simplelists-categories">
<?php if(!empty( $this->categories )) { foreach( $this->categories as $category ) { ?>
    <h2 class="componentheading"><a href="<?php echo $category->link; ?>"><?php echo $category->title ?></a></h2>
    <?php if( $this->show_category_description ) { ?><span id="simplelists-description"><?php echo $category->description; ?></span><?php } ?>
<div class="simplelists-category">
</div>
<?php }} else { ?>
<?php echo $this->message ?>
<?php } ?>
</div>

<?php if( $this->use_pagination ) echo $this->pagination->getPagesLinks(); ?>
