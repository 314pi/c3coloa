<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// Import the needed libraries
jimport( 'joomla.application.component.view');

// Import the needed helpers
require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'helper.php' ;

/**
 * Feed View class for the SimpleLists component
 *
 * @package Joomla
 * @subpackage Simplelists
 */
class SimplelistsViewSimplelist extends JView
{
    /*
     * Method to prepare the content for display
     *
     * @param string $tpl
     * @return null
     */
    public function display($tpl = null)
    {
        // Fetch the document and set the current URL as feed-point
        $document =& JFactory::getDocument();

        // Load the model
        $model =& $this->getModel();

        // Get the category from our model
        $category = $model->getCategory() ;

        // Load the items
        $simplelist = $model->getData() ;

        // Set the document properties
        $category_url = SimpleListsHelper::getUrl( $category->id, $category->alias );
        $document->set('link', $category_url );
        $document->setGenerator('');

        if( is_array($simplelist) && count( $simplelist ) > 0 ) {

            // loop through the list to set things right
            foreach( $simplelist as $id => $item ) {

                $feed = new JFeedItem();
                $feed->set('title', $item->title);
                $feed->set('link', $category_url.'#item'.$item->id);
                $feed->set('description', $item->text);
                $feed->set('date', $item->date);
                $feed->set('category', $category->title);
                
                $document->addItem($feed);
            }
        }
    }
}
