<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// Import the needed libraries
jimport( 'joomla.application.component.view');

/**
 * HTML View class for the SimpleLists component
 *
 * @package Joomla
 * @subpackage Simplelists
 */
class SimplelistsViewSimplelist extends JView
{
    /*
     * Method to display the content 
     *
     * @param string $tpl
     * @return null
     */
    public function display($tpl = null)
    {
        $this->prepareDisplay($tpl);
        parent::display($tpl);
    }

    /*
     * Method to prepare the content for display
     *
     * @param string $tpl
     * @return null
     */
    public function prepareDisplay($tpl = null)
    {
        // Get important system variables
        $document =& JFactory::getDocument();
        $uri = &JFactory::getURI();

        // Load the component parameters
        $params = &JComponentHelper::getParams( 'com_simplelists' );

        // Determine the current layout
        if($params->get('layout') != '') {
            $layout = $params->get('layout');
            $this->setLayout($layout) ;
        } else {
            $layout = $this->getLayout() ;
        }

        // Load the simplelist-model
        $model =& $this->getModel();

        // Get the category from our model and prepare it
        $category = $model->getCategory() ;
        $this->prepareCategory($category, $params, $layout);

        // Set the page title
        if(JRequest::getCmd('option') == 'com_simplelists') {
            if( $params->get('show_page_title') == 1 && $params->get('page_title') != '' ) {
                $document->setTitle( $params->get('page_title') );
            } else {
                $document->setTitle( $category->title );
            }
        }

        // Set META information
        $this->addMetaTags($category);
        $this->addPathway($category);

        // Enable pagination
        if( $params->get('use_pagination') ) {

            // Customize pagination
            if( $params->get('limit') > 0 ) {
                $model->setLimit( $params->get('limit') ) ;
            }

            // Get the simple list from our model
            $simplelist = $model->getData($params) ;

            // Get the pagination
            $pagination = $model->getPagination() ;

        } else {

            // Get the simple list from our model without pagination
            $simplelist = $model->getData($params) ;

        }

        // Set the URL of this page
        $url = $uri->toString();

        // Set the to-top image
        if( $params->get('show_totop') == 1 ) {

            if( $params->get('totop_text') ) {
                $totop_text = $params->get('totop_text');
            } else {
                $totop_text = JText::_( 'Top' );
            }

            $totop = null;

            if( $params->get('totop_image') && is_file( JPATH_SITE.DS.'images'.DS.'simplelists'.DS.$params->get('totop_image'))) {
                $totop_image = JHTML::image( 'images/simplelists/'.$params->get('totop_image'), $totop_text );
                $totop_image = JHTML::link( $url.'#top', $totop_image, 'class="totop"' );
                $totop .= $totop_image ;
            }

            if( $params->get('totop_text') ) {
                $totop_text = '<span class="totop_text">' . $totop_text . '</span>';
                $totop_text = JHTML::link( $url.'#top', $totop_text, 'class="totop"' );
                $totop .= $totop_text ;
            }

        } else {
            $totop = null ;
        }

        // Get the simple list from our model
        $simplelist = $model->getData() ;

        // Determine whether to show the "No Items" message
        if( $params->get('show_empty_list') ) {
            $empty_list = JText::_( 'No items found' );
        } else {
            $empty_list = null;
        }

        // Check if the list is empty
        if( is_array($simplelist) && !empty( $simplelist )) {

            // Loop through the list to set things right
            foreach( $simplelist as $id => $item ) {

                // Prepare each item
                $item = $this->prepareItem($item, $params, $layout);

                // Save the item in the array
                if($item == false) {
                    unset($simplelist[$id]);
                } else {
                    $simplelist[$id] = $item ;
                }
            }

            // Add feeds to the document
            if( $params->get('show_feed') == 1 ) {
                $link = '&format=feed&limitstart=';
                $document->addHeadLink(JRoute::_($link.'&type=rss'), 'alternate', 'rel', array('type' => 'application/rss+xml', 'title' => 'RSS 2.0'));
                $document->addHeadLink(JRoute::_($link.'&type=atom'), 'alternate', 'rel', array('type' => 'application/atom+xml', 'title' => 'Atom 1.0'));
            }
        }

        // Load the default CSS only, if set through the parameters
        if( $params->get('load_css', 1) ) {
            $this->addCSS( $layout );
        }

        // Load the default JavaScript only, if set through the parameters
        if( $params->get('load_js', 1) ) {
            $this->addJS( $layout );
        }

        // Load the lightbox only, if set through the parameters
        if( $params->get('load_lightbox') ) {
            JHTML::_('behavior.modal', 'a.lightbox');
        }

        // Construct the page class
        $page_class = 'simplelists simplelists-'.$layout;
        if( $params->get('pageclass_sfx') ) {
            $page_class .= ' simplelists'.$params->get('pageclass_sfx');
        }

        // Assign all variables to this layout
        $this->assignRef( 'simplelist', $simplelist );
        $this->assignRef( 'category', $category );
        $this->assignRef( 'pagination', $pagination );
        $this->assignRef( 'totop', $totop );
        $this->assignRef( 'empty_list', $empty_list );
        $this->assignRef( 'params', $params );
        $this->assignRef( 'url', $url);
        $this->assignRef( 'page_class', $page_class);

        return;
    }

    /*
     * Method to prepare the category
     *
     * @param object $category
     * @param JParameter $params
     * @param string $layout
     * @return null
     */
    public function prepareCategory(&$category, &$params, $layout) 
    {
        // Convert the parameters to an object
        $category->params = new JParameter( $category->params );

        // Override the default parameters with the category parameters
        foreach($category->params->toArray() as $name => $value) {
            if($value != '') $params->set($name, $value);
        }

        // Override the layout
        $layout = $category->params->get('layout');
        if(!empty($layout)) {
            $this->setLayout($layout);
        }

        // Prepare the category URL
        if( $params->get('show_category_parent') && !empty( $category->parent )) {
            $id = $category->parent->id ;
            $category->parent->link = SimplelistsHelper::getUrl( $id, '' );
        }

        // Loop through the child-categories
        if( $params->get('show_category_childs') && !empty( $category->childs )) {
            foreach( $category->childs as $child ) {
                $child->params = new JParameter( $child->params );
                $child_layout = $child->params->get( 'layout', $layout );
                $child->link = SimplelistsHelper::getUrl( $child->id, $child->alias, $child_layout );
            }
        }

        // Set the correct page-title
        if( $params->get('show_page_title') == 1 && $params->get('page_title') != '' ) {
            $category->title = $params->get('page_title') ;
        }

        // Run the category content through Content Plugins
        if( $params->get('show_category_description') && !empty($category->description)) {
            $category->text = $category->description;
            $this->firePlugins($category, array());
            $category->description = $category->text; 
            $category->text = null ;
        }

        // Prepare the category image
        if( $params->get('show_category_image') && $category->image ) {
            $category->image = JHTML::image( $category->image, $category->title, array( 'align' => $category->image_position));
        } else {
            $params->set('show_category_image', 0);
        }
    }

    /*
     * Method to prepare a specific item
     *
     * @param object $item
     * @param JParameter $params
     * @param string $layout
     * @return object
     */
    public function prepareItem($item, $params, $layout) 
    {
        $user = &JFactory::getUser();
        $dispatcher =& JDispatcher::getInstance();

        // Skip this entry if it is not published
        if(!$item->published > 0) {
            return false;
        } 

        // Skip this entry if access is not allowed
        if(isset($item->access) && $item->access > $user->get('aid', 0)) {
            return false;
        } 

        // Initialize the parameters
        if( $item->params ) {
            $p = clone( $params );
            $p->merge( new JParameter( $item->params ));
            $item->params = $p;
        } else {
            $item->params = $params;
        }

        // Make sure the title is HTML-safe
        if(!empty($item->title)) {
            $item->title = htmlspecialchars($item->title);
        }

        // Run the content through Content Plugins
        if( $item->params->get('enable_content_plugins', 1) == 1 ) {
            JPluginHelper::importPlugin( 'content' );
            $iparams = array();
            $results = $dispatcher->trigger('onPrepareContent', array ( &$item, &$iparams, 0));
        }

        // Disable the text when needed
        if( $item->params->get('show_item_text') == 0 ) {
            $item->text = '' ;
        }

        // Prepare the URL
        $item->url = JRoute::_(SimplelistsPluginHelper::getLinkUrl( $item ));
        if($item->alias) {
            $item->href = $item->alias;
        } else {
            $item->href = 'item'.$item->id;
        }

        // Create a simple target-string
        switch( $item->params->get('target') ) {
            case 1:
                $item->target = ' target="_blank"' ;
                break;
            case 2:
                $item->target = ' onclick="javascript: window.open(\''. $item->url .'\', \'\', \'toolbar=no,location=no,status=no,' 
                    . 'menubar=no,scrollbars=yes,resizable=yes,width=780,height=550\'); return false"' ;
                break;
            default:
                $item->target = false;
                break;
        }

        // Set the readmore link for this item
        if( $item->params->get('readmore') == 1 && $item->url ) {
            $readmore_text = $item->params->get( 'readmore_text', JText::sprintf( 'Read more', $item->title )) ;
            $readmore_css = trim( 'readon ' . $item->params->get( 'readmore_class', '' ));
            $item->readmore = JHTML::link( $item->url, $readmore_text, 'title="'.$item->title.'" class="'.$readmore_css.'"'.$item->target );
        } else {
            $item->readmore = false;
        }

        // Set the image-alignment for this item
        if( $item->params->get('picture_alignment') != '' && $layout != 'picture' ) {
            $item->picture_alignment = ' align="' . $item->params->get('picture_alignment') . '"';
        } else {
            $item->picture_alignment = false;
        }

        // Prepare the image
        if( $item->params->get('show_item_image') && !empty( $item->picture )) {

            $attributes = 'title="'.$item->title.'" class="simplelists"'.$item->picture_alignment;
            $item->picture = SimplelistsHTML::image( $item->picture, $item->title, $attributes);

            if($item->picture && $item->params->get('image_link') && !empty( $item->url )) {

                if($item->params->get( 'link_class') != '') {
                    $item_link_class = ' class="'.$item->params->get('link_class').'"' ;
                } else {
                    $item_link_class = '';
                }

                if($item->params->get('link_rel') != '') {
                    $item_link_rel = ' rel="'.$item->params->get('link_rel').'"' ;
                } else {
                    $item_link_rel = '';
                }

                if(!empty($item->title)) {
                    $title = $item->title;
                    if(!empty($item->text)) {
                        $title .= ' :: ' . $item->text;
                    }
                } else {
                    $title = $item->target;
                }
                $title = htmlentities($title);

                $item->picture = JHTML::link( $item->url, $item->picture, 
                    'title="'.$title.'"'.$item->target.$item_link_class.$item_link_rel );
            }
        } else {
            $item->picture = null ;
        }

        // Prepare the title
        if( $item->params->get('show_item_title') ) {
            if( $item->params->get('title_link') && !empty( $item->url )) {
                $item->title = JHTML::link( $item->url, $item->title, $item->target );
            }
        } else {
            $item->title = null ;
        }

        // Set specific layout settings
        $item->style = '';
        if( $layout == 'select' || $layout == 'hover' ) {
            if(empty($firstflag)) {
                static $firstflag = 1;
                $item->style = 'display:block; visibility:visible;';
            }
        }

        // Enable parsing the content
        JPluginHelper::importPlugin( 'content' );
        $results = $dispatcher->trigger('onBeforeDisplayContent', array ( &$item, &$item->params, 0));
        foreach($results as $result) {
            if(!empty($result)) $item->text .= $result;
        }

        return $item;
    }

    /*
     * Method to load CSS depending on the layout
     * 
     * @param string $layout
     * @return null
     */
    protected function addCSS($layout) 
    {
        switch( $layout ) {
            case 'hover':
            case 'picture':
            case 'select':
            case 'table':
            case 'toggle':
                $sheet = $layout.'.css';
                break;

            default:
            case 'default':
            case 'basic':
                $sheet = 'default.css';
                break;
        }

        SimplelistsHelper::addCss($sheet);
    }

    /*
     * Method to load JavaScript depending on the layout
     * 
     * @param string $layout
     * @return null
     */
    protected function addJS($layout) 
    {
        // load javascript depending on the layout
        switch( $layout ) {
            case 'hover':
            case 'select':
            case 'toggle':
                $script = $layout.'.js';
                JHTML::_('behavior.mootools');
                break;

            default:
                $script = 'default.js';
                break;
        }

        SimplelistsHelper::addJs($script);
    }

    /*
     * Method to load META-tags in the HTML header
     * 
     * @param object $category
     * @return null
     */
    protected function addMetaTags($category) 
    {

        $params = $category->params;
        $document =& JFactory::getDocument();

        $meta_description = $params->get('description');
        if( !empty( $meta_description )) {
            $document->setDescription( $meta_description );
        }

        $meta_keywords = $params->get('keywords');
        if( !empty( $meta_keywords )) {
            $document->setMetadata( 'keywords', $meta_keywords );
        }

        $meta_author = $params->get('author');
        if( !empty( $meta_author )) {
            $document->setMetadata( 'author', $meta_author );
        }
    }

    /*
     * Method to add items to the breadcrumbs (pathway)
     *
     * @param object $category
     * @return null
     */
    protected function addPathway($category = null) 
    {
        $application = JFactory::getApplication();
        $pathway = $application->getPathway();

        if(is_object($category) && $category->parent_id > 0) {
            $pathway->addItem( $category->title ) ;
            $parent = SimplelistsHelper::getCategory($category->parent_id);
            $this->addPathway($parent);
        }
    }

    /*
     * Method to fire plugins on a certain item
     *
     * @param object $row
     * @return null
     */
    protected function firePlugins(&$row = null, $params = array()) 
    {
        $dispatcher =& JDispatcher::getInstance();
        JPluginHelper::importPlugin( 'content' );
        $results = $dispatcher->trigger('onPrepareContent', array ( &$row, &$params, 0));
    }
}
