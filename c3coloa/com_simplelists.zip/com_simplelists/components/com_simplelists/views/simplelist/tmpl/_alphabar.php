<?php
// build the alphabet
$alphabet = array();

// include an ALL-option
$uri = clone( JURI::getInstance() );
$uri->delVar( 'char' );
$url = $uri->toString();
$alphabet[] = '<span class="char"><a href="'.$url.'">' . JText::_('All') . '</a></span>';

// gather all letters
for( $i = 97 ; $i < 123 ; $i++ ) { 
    $letter = chr($i);
    $uri = clone( JURI::getInstance() );
    $uri->setVar( 'char', $letter );
    $url = JRoute::_($uri->toString(), true);

    if( strtolower( JRequest::getCmd( 'char' )) == $letter ) {
        $alphabet[] = '<span class="char">' . $letter . '</span>';
    } else {
        $alphabet[] = '<span class="char"><a href="' . $url . '">' . $letter . '</a></span>';
    }
}

echo implode( ' | ', $alphabet );
