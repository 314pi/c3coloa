<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php if( $this->params->get('show_category_image') || $this->params->get('show_category_description') ) : ?>
    <?php if( $this->params->get('show_category_image') ) : ?>
    <?php echo $this->category->image; ?>
    <?php endif;?>

    <?php if( $this->params->get('show_category_description') ) : ?>
        <p><?php echo $this->category->description ?></p>
    <?php endif; ?>
    <br/>
    <br/>
    <br/>
<?php endif; ?>

<?php if( !empty( $this->simplelist )) : ?>
<?php foreach( $this->simplelist as $item ): ?>

<?php if($item->picture): ?>
<?php echo $item->picture; ?>
<?php endif; ?>

<?php if($item->title): ?>
<h3><?php echo $item->title; ?></h3>
<?php endif; ?>

<?php if($item->text): ?>
<?php echo $item->text; ?>
<?php endif; ?>

<?php if($item->readmore): ?>
<br/>
<?php echo $item->readmore; ?>
<?php endif; ?>
<br/>
<br/>
<br/>

<?php endforeach; ?>
<?php endif; ?>

