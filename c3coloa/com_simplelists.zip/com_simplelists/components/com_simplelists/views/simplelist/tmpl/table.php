<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php echo SimplelistsHelper::loadTemplate('_header'); ?>

<?php if( !empty( $this->simplelist )) : ?>

<?php $columns = $this->params->get('columns', 1); ?>
<?php $i = 1; ?>
<table class="<?php echo $this->page_class; ?>">
<?php foreach( $this->simplelist as $item ): ?>

    <?php if($i % $columns == 1) { ?>
     <tr>
    <?php } ?>
        <td>
            <table>
                <tr class="simplelists-item">
                    <td valign="middle" align="center" class="simplelists-item-left">
                        <?php if($item->picture): ?>
                        <?php echo $item->picture; ?>
                        <?php endif; ?>
                    </td>
                    <td valign="top" class="simplelists-item-right">
    
                        <a name="<?php echo $item->href; ?>"></a>

                        <?php if($item->title): ?>
                        <h3 class="contentheading"><?php echo $item->title; ?></h3>
                        <?php endif; ?>
        
                        <?php if($item->text): ?>
                        <?php echo $item->text; ?>
                        <?php endif; ?>

                        <?php if($item->readmore): ?>
                        <br/><?php echo $item->readmore; ?>
                        <?php endif; ?>

                    </td>
                </tr>
                <?php if($this->totop): ?>
                <tr>
                    <td colspan="2">
                        <?php echo $this->totop; ?>
                    </td>
                </tr>
                <?php endif; ?>
            </table>
        </td>
    <?php if($i % $columns == 0) { ?>
    </tr>
    <?php } ?>

    <?php $i++; ?>

<?php endforeach; ?>
</table>
<?php else: ?>
    <?php echo $this->empty_list; ?>
<?php endif; ?>

<?php echo SimplelistsHelper::loadTemplate('_footer'); ?>
