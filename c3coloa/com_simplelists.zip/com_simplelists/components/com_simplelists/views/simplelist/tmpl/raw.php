<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php echo SimplelistsHelper::loadTemplate('_header'); ?>

<div class="simplelists simplelists-raw">
<?php if( !empty( $this->simplelist )): ?>
    <?php foreach( $this->simplelist as $item ): ?>

        <?php
        print_r( $item );
        ?>

    <?php endforeach; ?>
<?php else: ?>
    <?php echo $this->empty_list; ?>
<?php endif; ?>
</div>

<?php echo SimplelistsHelper::loadTemplate('_footer'); ?>
