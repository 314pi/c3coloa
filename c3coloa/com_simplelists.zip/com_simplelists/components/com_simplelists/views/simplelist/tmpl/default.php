<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php echo SimplelistsHelper::loadTemplate('_header'); ?>

<div class="<?php echo $this->page_class; ?>">
<?php if( !empty( $this->simplelist )): ?>
    <?php foreach( $this->simplelist as $item ): ?>

        <a name="<?php echo $item->href; ?>"></a>

        <div class="simplelists-item">

            <div class="image">
                <?php if($item->picture): ?>
                <?php echo $item->picture; ?>
                <?php endif; ?>
            </div>

            <div class="body">
                <?php if($item->title): ?>
                <h3 class="contentheading"><?php echo $item->title ?></h3>
                <?php endif; ?>
                
                <?php if($item->text): ?>
                <?php echo $item->text; ?>
                <?php endif; ?>

                <?php if($item->readmore): ?>
                <br/><?php echo $item->readmore; ?>
                <?php endif; ?>

                <?php if($this->totop): ?>
                <?php echo $this->totop; ?>
                <?php endif; ?>

            </div>

        </div>
    <?php endforeach; ?>
<?php else: ?>
    <?php echo $this->empty_list; ?>
<?php endif; ?>
</div>

<?php echo SimplelistsHelper::loadTemplate('_footer'); ?>
