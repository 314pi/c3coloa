<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the SimpleLists component
 *
 * @package Joomla
 * @subpackage Simplelists
 */
class SimplelistsViewItem extends JView
{
    /*
     * Method to prepare the content for display
     *
     * @param string $tpl
     * @return null
     */
    public function display($tpl = null)
    {
        $application = JFactory::getApplication();
        $document = JFactory::getDocument();

        // layout parameters
        $params = JComponentHelper::getParams( 'com_simplelists' );

        // load the model
        $model = $this->getModel();
        $model->hit();

        // get the item from our model
        $item = $model->getData();

        // Set the meta-data
        $document->setTitle( $item->title );
        $application->addMetaTag('title', $item->title);

        // Initialize the parameters
        if( $item->params ) {
            $p = clone( $params );
            $p->merge( new JParameter( $item->params ));
            $item->params = $p;
        } else {
            $item->params = $params;
        }

        if($item->params->get('meta_author') != '') {
            $application->addMetaTag('author', $item->params->get('meta_author'));
        }

        if($item->params->get('meta_description') != '') {
            $document->setDescription( $item->params->get('meta_description'));
        }

        if($item->params->get('meta_keywords') != '') {
            $document->setMetadata('keywords', $item->params->get('meta_keywords'));
        }

        // parse important parameters
        $layout = null;
        $item = $this->_prepareItem($item, $params, $layout);

        //$dispatcher =& JDispatcher::getInstance();
        //$iparams = array();
        //$results = $dispatcher->trigger('onPrepareContent', array ( &$item, &$iparams, 0));

        // when the link was "hidden", we call the link-plugin to decide what to do
        if(JRequest::getCmd('task') == 'hidden') {
            $item->params->set('show_link', 0);
            $item->extra = SimplelistsPluginHelper::getLinkHidden( $item );
        } else {
            $item->extra = null;
        }

        // assign all variables to this layout
        $this->assignRef( 'item', $item );

        parent::display($tpl);
    }

    /*
     * Method to prepare a specific item
     *
     * @param object $item
     * @param JParameter $params
     * @param string $layout
     * @return object
     */
    public function _prepareItem($item, $params, $layout) {

        $user = &JFactory::getUser();
        $dispatcher =& JDispatcher::getInstance();

        // Skip this entry if it is not published
        if(!$item->published > 0) {
            return false;
        } 

        // Skip this entry if access is not allowed
        if(isset($item->access) && $item->access > $user->get('aid', 0)) {
            return false;
        } 

        // Run the content through Content Plugins
        if( $item->params->get('enable_content_plugins', 1) == 1 ) {
            JPluginHelper::importPlugin( 'content' );
            $iparams = array();
            $results = $dispatcher->trigger('onPrepareContent', array ( &$item, &$iparams, 0));
        }

        // Disable the text when needed
        if( $item->params->get('show_item_text') == 0 ) {
            $item->text = '' ;
        }

        // Prepare the URL
        $item->url = JRoute::_(SimplelistsPluginHelper::getLinkUrl( $item ));
        if($item->alias) {
            $item->href = $item->alias;
        } else {
            $item->href = 'item'.$item->id;
        }

        // Create a simple target-string
        switch( $item->params->get('target') ) {
            case 1:
                $item->target = ' target="_blank"' ;
                break;
            case 2:
                $item->target = ' onclick="javascript: window.open(\''. $item->url .'\', \'\', \'toolbar=no,location=no,status=no,' 
                    . 'menubar=no,scrollbars=yes,resizable=yes,width=780,height=550\'); return false"' ;
                break;
            default:
                $item->target = false;
                break;
        }

        // Set the readmore link for this item
        if( $item->params->get('readmore') == 1 && $item->url ) {
            $readmore_text = $item->params->get( 'readmore_text', JText::sprintf( 'Read more', $item->title )) ;
            $readmore_css = trim( 'readon ' . $item->params->get( 'readmore_class', '' ));
            $item->readmore = JHTML::link( $item->url, $readmore_text, 'title="'.$item->title.'" class="'.$readmore_css.'"'.$item->target );
        } else {
            $item->readmore = false;
        }

        // Set the image-alignment for this item
        if( $item->params->get('picture_alignment') != '' && $layout != 'picture' ) {
            $item->picture_alignment = ' align="' . $item->params->get('picture_alignment') . '"';
        } else {
            $item->picture_alignment = false;
        }

        // Prepare the image
        if( $item->params->get('show_item_image') && !empty( $item->picture )) {

            $attributes = 'title="'.$item->title.'" class="simplelists"'.$item->picture_alignment;
            $item->picture = SimplelistsHTML::image( $item->picture, $item->title, $attributes);

            if($item->picture && $item->params->get('image_link') && !empty( $item->url )) {

                if($item->params->get( 'link_class') != '') {
                    $item_link_class = ' class="'.$item->params->get('link_class').'"' ;
                } else {
                    $item_link_class = '';
                }

                if($item->params->get('link_rel') != '') {
                    $item_link_rel = ' rel="'.$item->params->get('link_rel').'"' ;
                } else {
                    $item_link_rel = '';
                }

                if(!empty($item->title)) {
                    $title = $item->title;
                    if(!empty($item->text)) {
                        $title .= ' :: ' . $item->text;
                    }
                } else {
                    $title = $item->target;
                }
                $title = htmlentities($title);

                $item->picture = JHTML::link( $item->url, $item->picture, 
                    'title="'.$title.'"'.$item->target.$item_link_class.$item_link_rel );
            }
        } else {
            $item->picture = null ;
        }

        // Prepare the title
        if( $item->params->get('show_item_title') ) {
            if( $item->params->get('title_link') && !empty( $item->url )) {
                $item->title = JHTML::link( $item->url, $item->title, $item->target );
            }
        } else {
            $item->title = null ;
        }

        // Set specific layout settings
        $item->style = '';
        if( $layout == 'select' || $layout == 'hover' ) {
            if(empty($firstflag)) {
                static $firstflag = 1;
                $item->style = 'display:block; visibility:visible;';
            }
        }

        // Enable parsing the content
        JPluginHelper::importPlugin( 'content' );
        $results = $dispatcher->trigger('onBeforeDisplayContent', array ( &$item, &$item->params, 0));
        foreach($results as $result) {
            if(!empty($result)) $item->text .= $result;
        }

        return $item;
    }
}
