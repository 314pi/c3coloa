/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

window.addEvent('domready', function() {
	
    var accordion = new Accordion('a.heading', 'div.body', {
        opacity: false
    }, $('simplelists'));
    
    if( window.location.hash != '' ) {
    	
    	hash = window.location.hash.replace('#','');
    	accordion.elements.each(function(item, index) {
    		if( hash == item.id && index < accordion.togglers.length) {
    			accordion.display(index);
    		}
    	}); 
    }
});
