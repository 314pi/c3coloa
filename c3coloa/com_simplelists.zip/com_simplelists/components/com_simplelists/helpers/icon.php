<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * HTML Icon Helper
 * 
 * @package Joomla
 * @subpackage Simplelists
 */
if(!class_exists('JHTMLIcon')) {
    class JHTMLIcon
    {
        /**
         * Method to display a PDF-icon
         *
         * @access public
         * @param null
         * @return string HTML output
         */
        public function pdf()
        {
            $url  = 'index.php?option=com_simplelists&view=simplelist&layout=print';
            if(JRequest::getInt('category_id') > 0) $url .= '&category_id='.JRequest::getInt('category_id');
            if(JRequest::getInt('Itemid') > 0) $url .= '&Itemid='.JRequest::getInt('Itemid');
            $url .= '&format=pdf';

            $status = 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no';

            // checks template image directory for image, if non found default are loaded
            $text = JHTML::_('image.site', 'pdf_button.png', '/images/M_images/', NULL, NULL, JText::_('PDF'));

            $attribs['title']    = JText::_( 'PDF' );
            $attribs['onclick'] = "window.open(this.href,'win2','".$status."'); return false;";
            $attribs['rel']     = 'nofollow';

            return JHTML::_('link', JRoute::_($url), $text);
        }

        /**
         * Method to display a print-icon
         *
         * @access public
         * @param null
         * @return string HTML output
         */
        public function print_popup()
        {
            $url = 'index.php?option=com_simplelists&view=simplelist&layout=print';
            if(JRequest::getInt('category_id') > 0) $url .= '&category_id='.JRequest::getInt('category_id');
            if(JRequest::getInt('Itemid') > 0) $url .= '&Itemid='.JRequest::getInt('Itemid');
            $url .= '&format=print';

            $status = 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no';

            // checks template image directory for image, if non found default are loaded
            $text = JHTML::_('image.site',  'printButton.png', '/images/M_images/', NULL, NULL, JText::_( 'Print' ) );

            $attribs['title']    = JText::_( 'Print' );
            $attribs['onclick'] = "window.open(this.href,'win2','".$status."'); return false;";
            $attribs['rel']     = 'nofollow';

            return JHTML::_('link', JRoute::_($url), $text);
        }

        /**
         * Dummy method for the edit-button
         *
         * @access public
         * @param null
         * @return null
         */
        public function edit()
        {
        }
    }
}
