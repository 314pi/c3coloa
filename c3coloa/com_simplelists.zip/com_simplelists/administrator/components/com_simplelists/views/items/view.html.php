<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// Import the needed libraries
jimport( 'joomla.application.component.view');

// Import the needed helpers
require_once JPATH_COMPONENT.DS.'helpers'.DS.'html.php';

/**
 * HTML View class for the Simplelists component
 *
 * @package Joomla
 * @subpackage Simplelists
 */
class SimplelistsViewItems extends JView
{
    /*
     * Method to prepare the content for display
     *
     * @param string $tpl
     * @return null
     */
    public function display($tpl = null)
    {
        // Initialize common variables
        $application = JFactory::getApplication();
        $option = JRequest::getCmd( 'option' ).'-items';

        // Handle the filters
        $filter_state = $application->getUserStateFromRequest( $option.'filter_state', 'filter_state', '', 'word' );
        $filter_category_id = $application->getUserStateFromRequest( $option.'filter_category_id', 'filter_category_id', 0, 'int' );
        $filter_link_type = $application->getUserStateFromRequest( $option.'filter_link_type', 'filter_link_type', '', 'cmd' );
        $filter_order = $application->getUserStateFromRequest( $option.'filter_order', 'filter_order', 'a.ordering', 'cmd' );
        $filter_order_Dir = $application->getUserStateFromRequest( $option.'filter_order_Dir', 'filter_order_Dir',    '', 'word' );
        $search = $application->getUserStateFromRequest( $option.'search', 'search', '', 'string' );
        $search = JString::strtolower( $search );

        // Preliminary check to see if any categories have been configured yet
        SimplelistsHelper::checkCategories() ;

        // Get data from the model
        $items = & $this->get( 'Data');
        $total = & $this->get( 'Total');
        $pagination = & $this->get( 'Pagination' );

        // Prepare data for each simplelists item
        foreach( $items as $i => $item ) {
            $item->categories = SimplelistsHelper::getCategories( $item->id );
            $item->edit_link = JRoute::_( 'index.php?option=com_simplelists&view=item&task=edit&cid[]='. $item->id );
            $items[$i] = $item ;
        }

        // build list of categories
        $category_id_params = array( 'current' => $filter_category_id, 'javascript' => 1, 'nullvalue' => 1 );
        $lists['category_id'] = SimplelistsHTML::selectCategories( 'filter_category_id', $category_id_params );
        $lists['link_type'] = SimplelistsHTML::selectLinkType( $filter_link_type );

        // state filter
        $lists['state'] = JHTML::_('grid.state',  $filter_state );

        // table ordering
        $lists['order_Dir'] = $filter_order_Dir;
        $lists['order'] = $filter_order;

        // search filter
        $lists['search']= $search;

        $this->assignRef('user', JFactory::getUser());
        $this->assignRef('lists', $lists);
        $this->assignRef('items', $items);
        $this->assignRef('pagination', $pagination);
        
        parent::display($tpl);
    }
}
