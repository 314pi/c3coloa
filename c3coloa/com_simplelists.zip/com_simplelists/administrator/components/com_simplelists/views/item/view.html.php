<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla! 
defined('_JEXEC') or die();

// Import the needed libraries
jimport('joomla.application.component.view');
jimport('joomla.filter.output');

// Import the needed helpers
require_once JPATH_COMPONENT.DS.'helpers'.DS.'html.php';

/**
 * HTML View class for the Simplelists component
 *
 * @static
 * @package	Simplelists
 */
class SimplelistsViewItem extends JView
{
    /*
     * Method to prepare the content for display
     *
     * @param string $tpl
     * @return null
     */
	public function display($tpl = null)
	{
        // Initialize common variables
        $application =& JFactory::getApplication() ;
		$db	=& JFactory::getDBO();
		$user =& JFactory::getUser();
		$model =& $this->getModel( 'item' );
        $document =& JFactory::getDocument();
        $option = JRequest::getCmd( 'option' );

        // Initialize $lists
		$lists = array();

        // Give a warning if no categories are configured
        SimplelistsHelper::checkCategories() ;

		// Get the item
		$item =& $this->get('data');
		$isNew = ($item->id < 1);

		// fail if checked out not by 'me'
		if ($model->isCheckedOut( $user->get('id') )) {
			$msg = JText::sprintf( 'Item locked', $item->title );
			$application->redirect( 'index.php?option='. $option, $msg );
		}

		// Edit or Create?
		if (!$isNew)
		{
			$model->checkout( $user->get('id') );
		}
		else
		{
			// initialise new record
			$item->published = 1;
			$item->approved 	= 1;
			$item->order 	= 0;
		}

		// build the html select list for ordering
		$query = 'SELECT ordering AS value, title AS text'
			. ' FROM #__simplelists'
			. ' ORDER BY ordering';

        // common lists
        $categories_params = array( 'item_id' => $item->id, 'multiple' => 1 );
		$lists['categories'] = SimplelistsHTML::selectCategories( 'categories[]', $categories_params );
		$lists['ordering'] = JHTML::_('list.specificordering',  $item, $item->id, $query );
        $lists['access'] = JHTML::_('list.accesslevel', $item );
		$lists['published'] = JHTML::_('select.booleanlist',  'published', 'class="inputbox"', $item->published );
                
        $item->image_directory = COM_SIMPLELISTS_DIR ;

        // Construct the modal boxes
        $modal = array() ;
        $modal['picture'] = 'index.php?option=com_simplelists&amp;view=files&amp;tmpl=component&amp;type=picture&amp;current='.$item->picture ;
        if( $item->picture ) {
            $modal['picture'] .= '&amp;folder=/'.dirname( $item->picture );
        }

        // Include the CSS and JavaScript
		JHTML::_('script', 'mootools-cookie.js', 'administrator/components/com_simplelists/js/');
		JHTML::_('script', 'item.js', 'administrator/components/com_simplelists/js/');
		JHTML::_('script', 'browser.js', 'administrator/components/com_simplelists/js/');
        JHTML::_('stylesheet', 'item.css', 'administrator/components/com_simplelists/css/');

		// Clean the simplelist object before displaying
		JFilterOutput::objectHTMLSafe( $item, ENT_QUOTES, 'text' );
        $item->text = htmlspecialchars($item->text);

        // Read the item-parameters and merge them with the stored parameters
		$file 	= JPATH_COMPONENT.DS.'models'.DS.'item.xml';
		$params = new JParameter( $item->params, $file );

        // Copy the created & modified settings to the parameters
        $params->set('created', $item->created );
        $params->set('created_by', $item->created_by );
        $params->set('modified', $item->modified );
        $params->set('modified_by', $item->modified_by );

        //jimport('joomla.html.pane');
        //$pane = & JPane::getInstance('sliders');

        //$this->assignRef('pane', $pane);
		$this->assignRef('lists', $lists);
		$this->assignRef('modal', $modal);
		$this->assignRef('item', $item);
		$this->assignRef('params', $params);

		parent::display($tpl);
	}
}
