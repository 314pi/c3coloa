<?php 
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
JHTML::_('behavior.modal', 'a.modal-button');

// Set toolbar items for the page
$edit = JRequest::getVar('edit',true);
$text = !$edit ? JText::_( 'New' ) : JText::_( 'Edit' );
JToolBarHelper::title( JText::_( 'SimpleLists' ).' - '.JText::_( 'Item' ).': <small>[ ' . $text.' ]</small>' );
JToolBarHelper::save();
JToolBarHelper::apply();
if (!$edit)  {
    JToolBarHelper::cancel();
} else {
    JToolBarHelper::cancel( 'cancel', 'Close' );
}
//JToolBarHelper::help( 'screen.simplelist.edit' );

// Set the right image directory for JavaScipt
jimport('joomla.utilities.utility');
$js_image_directory = str_replace( DS, '/', $this->item->image_directory );
?>

<script language="javascript" type="text/javascript">
    <!--
    var image_directory = '<?php echo $js_image_directory; ?>';
    var form_no_title = '<?php echo JText::_( 'Empty title', true ); ?>' ;
    -->
</script>

<form method="post" name="adminForm" id="adminForm">
<table cellspacing="0" cellpadding="0" border="0" width="100%">
<tbody>
<tr>
<td width="50%" valign="top">
    <fieldset class="adminform">
        <legend><?php echo JText::_( 'Details' ); ?></legend>
        <table class="admintable">
        <tbody>
        <tr>
            <td width="100" align="right" class="key">
                <label for="title">
                    <?php echo JText::_( 'ID' ); ?>:
                </label>
            </td>
            <td>
                <?php echo $this->item->id; ?>
            </td>
        </tr>
        <tr>
            <td width="100" align="right" class="key">
                <label for="title">
                    <?php echo JText::_( 'Name' ); ?>:
                </label>
            </td>
            <td>
                <input class="text_area" type="text" name="title" id="title" size="48" maxlength="250" value="<?php echo $this->item->title; ?>" />
            </td>
        </tr>
        <tr>
            <td width="100" align="right" class="key">
                <label for="alias">
                    <?php echo JText::_( 'Alias' ); ?>:
                </label>
            </td>
            <td>
                <input class="text_area" type="text" name="alias" id="alias" size="48" maxlength="250" value="<?php echo $this->item->alias;?>" />
            </td>
        </tr>
        <tr>
            <td valign="top" align="right" class="key">
                <?php echo JText::_( 'Published' ); ?>:
            </td>
            <td>
                <?php echo $this->lists['published']; ?>
            </td>
        </tr>
        <tr>
            <td valign="top" align="right" class="key">
                <label for="categories">
                    <?php echo JText::_( 'Categories' ); ?>:
                </label>
            </td>
            <td>
                <?php echo $this->lists['categories']; ?>
            </td>
        </tr>
        <tr>
            <td valign="top" align="right" class="key">
                <label for="ordering">
                    <?php echo JText::_( 'Ordering' ); ?>:
                </label>
            </td>
            <td>
                <?php echo $this->lists['ordering']; ?>
            </td>
        </tr>
        <tr>
            <td valign="top" class="key">
                <label for="access">
                    <?php echo JText::_( 'Access Level' ); ?>:
                </label>
            </td>
            <td>
                <?php echo $this->lists['access']; ?>
            </td>
        </tr>
        </tbody>
    </table>
    </fieldset>
    <fieldset class="adminform">
        <legend><?php echo JText::_( 'Text' ); ?></legend>
        <table class="admintable" width="100%">
        <tbody>
        <tr>
            <td>
                <?php
                $editor =& JFactory::getEditor();
                echo $editor->display( 'text', $this->item->text, '100%', '300', '44', '9', array('pagebreak', 'readmore' )) ;
                ?>
            </td>
        </tr>
        </tbody>
        </table>
    </fieldset>
</td>
<td width="50%" valign="top">
    <div id="item" class="pane-sliders">
    <div class="panel"><h3 class="jpane-toggler title" id="image"><span><?php echo JText::_( 'Image' ); ?></span></h3>
    <div class="jpane-slider content">
    <div class="inner">
        <strong><?php echo JText::_( 'Directory' ); ?>: <?php echo $this->item->image_directory; ?></strong>
        <table class="admintable">
        <tbody>
        <tr>
            <td>
                <input type="text" id="picture_name" value="<?php echo $this->item->picture; ?>" disabled="disabled" />
                <input type="hidden" id="picture" name="picture" value="<?php echo $this->item->picture; ?>" />
            </td>
            <td>
                <div class="button2-left">
                    <div class="blank">
                        <a class="modal-button" title="<?php echo JText::_('Select an Image') ?>" href="<?php echo $this->modal['picture']; 
                        ?>" rel="{handler: 'iframe', size: {x: 770, y: 500}}">
                        <?php echo JText::_('Select an Image'); ?>
                        </a>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <?php 
                if( JFile::exists( JPATH_SITE.DS.$this->item->image_directory.DS.$this->item->picture )) {
                    echo '<img src="../' . $this->item->image_directory . '/' . $this->item->picture . '" name="item_picture" />' ;
                } else {
                    echo '<img src="images/blank.png" alt="' . JText::_( 'No image' ) . '" name="item_picture" />' ;
                } ?>
            </td>
        </tr>
        </tbody>
        </table>
    </div>
    </div></div>    
    <div class="panel"><h3 class="jpane-toggler title" id="link"><span><?php echo JText::_( 'Link Settings' ); ?></span></h3>
    <div class="jpane-slider content">
    <div class="inner">
        <table class="paramlist admintable" width="100%">
        <tbody>
        <?php foreach( SimplelistsPluginHelper::getLinkTypes() as $link_type ) { ?>
        <?php if(SimplelistsPluginHelper::enabled('link',$link_type) == false) continue; ?>
        <tr>
            <td valign="top" align="right" class="key">
                <?php $checked = ($link_type == $this->item->link_type) ? 'checked="checked"' : '' ; ?>
                <input type="radio" class="simplelists_link" id="link_type_<?php echo $link_type; ?>" name="link_type" value="<?php echo $link_type; ?>" <?php echo $checked; ?> />
            </td>
            <td>
                <div class="simplelists_link_inner" id="simplelists_link_inner<?php echo $link_type; ?>">
                <label class="simplelists_link" for="link_type_<?php echo $link_type; ?>" id="link_type_<?php echo $link_type; ?>_label">
                    <?php echo SimplelistsPluginHelper::getLinkType( $link_type ); ?>
                </label>
                <?php echo SimplelistsPluginHelper::getLinkInput( $link_type, $this->item->link, ((!empty($checked)) ? true : false )); ?>
                </div>
            </td>
        </tr>
        <?php } ?>
        </tbody>
      </table>
    </div>
    </div></div>    
    <div class="panel">
        <h3 class="jpane-toggler title" id="params"><span><?php echo JText::_( 'Parameters' ); ?></span></h3>
        <div class="jpane-slider content">
            <div class="inner">
                <table class="paramlist admintable" cellspacing="1">
                    <tbody>
                    <tr>
                        <td colspan="2">
                            <?php echo $this->params->render();?>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </div>
</td>
</tr>
</tbody>
</table>

<input type="hidden" name="option" value="com_simplelists" />
<input type="hidden" name="cid[]" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>
