<?php 
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

$root = $this->state->folder;
if( $root == '/' ) $root = '';
?>
<div class="item">
	<a href="index.php?option=com_simplelists&amp;view=files&amp;tmpl=component&amp;folder=<?php echo $root; ?>/<?php echo $this->_tmp_folder->path_relative; ?>&amp;type=<?php echo $this->state->type; ?>">
		<img src="<?php echo JURI::base() ?>components/com_media/images/folder.gif" width="80" height="80" alt="<?php echo $this->_tmp_folder->name; ?>" />
		<span><?php echo $this->_tmp_folder->name; ?></span></a>
</div>
