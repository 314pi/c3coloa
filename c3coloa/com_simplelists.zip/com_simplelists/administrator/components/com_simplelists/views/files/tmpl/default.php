<?php 
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

switch( $this->state->type ) {
    case 'picture':
        $jSelect = 'jSelectPicture';
        break;
    case 'link_image':
        $jSelect = 'jSelectLinkImage';
        break;
    case 'link_file':
        $jSelect = 'jSelectLinkFile';
        break;
    case 'default':
        $jSelect = 'jSelectLinkImage';
        break;
}
$base_path = $this->state->folder;
?>
<script type='text/javascript'>
var base_path = '<?php echo $base_path; ?>' ;
</script>
<form action="index.php" id="fileForm" method="post" enctype="multipart/form-data">
	<fieldset>
		<div style="float:left">
            <span id="folder-indicator"><?php echo $base_path; ?></span>
        </div>
		<div style="float:right">
			<button type="button" class="button" onclick="javascript:submitModalForm(window.parent.<?php echo $jSelect; ?>, current_item);"><?php echo JText::_('Select') ?></button>
			<button type="button" class="button" onclick="javascript:submitModalForm(window.parent.<?php echo $jSelect; ?>, '');"><?php echo JText::_('Reset') ?></button>
			<button type="button" class="button" onclick="javascript:submitModalForm();"><?php echo JText::_('Cancel') ?></button>
		</div>
	</fieldset>
    <div class="manager">
    <?php 
    echo $this->loadTemplate('parent');

    if( count( $this->folders ) > 0 ) {
        for ($i=0,$n=count($this->folders); $i<$n; $i++) {
            $this->setFolder($i);
            echo $this->loadTemplate('folder');
        } 
    }

    if( count( $this->files ) > 0 ) {
        for ($i=0,$n=count($this->files); $i<$n; $i++) {
            $this->setFile($i);
            echo $this->loadTemplate('item');
        }
    }

    if(!is_readable( JPATH_SITE.DS.$base_path )) {
        $message = JText::_( 'Folder not readable' );
    } elseif( empty( $this->files ) && empty( $this->folders )) {
        $message = JText::_( 'No files or folders found' );
    } elseif( empty( $this->files )) {
        $message = JText::_( 'No files found' );
    }

    if(!empty($message)) {
        echo '<div id="files-message">'.$message.'</div>';
    }
    ?>
    </div>

	<input type="hidden" id="dirPath" name="dirPath" />
	<input type="hidden" id="f_file" name="f_file" />
	<input type="hidden" id="tmpl" name="component" />
</form>
