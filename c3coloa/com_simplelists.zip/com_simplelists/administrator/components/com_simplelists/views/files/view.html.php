<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

/**
 */
class SimpleListsViewFiles extends JView
{
    /*
     * Method to prepare the content for display
     *
     * @param string $tpl
     * @return null
     */
	public function display($tpl = null)
	{
		JResponse::allowCache(false);

		JHTML::_('stylesheet', 'popup-imagelist.css', 'administrator/components/com_media/assets/');
		JHTML::_('stylesheet', 'browser.css', 'administrator/components/com_simplelists/css/');
		JHTML::_('script', 'browser.js', 'administrator/components/com_simplelists/js/');
		JHTML::_('behavior.mootools');
		JHTML::_('behavior.modal');

		$this->assign('baseURL', JURI::root());
		$this->assignRef('files', $this->get('files'));
		$this->assignRef('folders', $this->get('folders'));
		$this->assignRef('state', $this->get('state'));

		parent::display($tpl);
	}

    /*
     * Method to prepare the content for display
     *
     * @param int $index
     * @return null
     */
	public function setFolder($index = 0)
	{
		if (isset($this->folders[$index])) {
			$this->_tmp_folder = &$this->folders[$index];
		} else {
			$this->_tmp_folder = new JObject;
		}
	}

    /*
     * Method to prepare the content for display
     *
     * @param int $index
     * @return null
     */
	public function setFile($index = 0)
	{
		if (isset($this->files[$index])) {
			$this->_tmp_file = &$this->files[$index];
		} else {
			$this->_tmp_file = new JObject;
		}
	}
}
