<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!  
defined('_JEXEC') or die();

// Import Joomla! libraries
jimport( 'joomla.application.component.view');

// Require the SimpleLists helper
require_once JPATH_COMPONENT.DS.'helpers'.DS.'plugin.php';

/**
 * HTML View class for the Simplelists component
 *
 * @static
 * @package	Simplelists
 */
class SimplelistsViewPlugins extends JView
{
    /*
     * Method to prepare the content for display
     *
     * @param string $tpl
     * @return null
     */
	public function display($tpl = null)
	{
        $application = JFactory::getApplication();
        $option = JRequest::getCmd( 'option' ).'-plugins';

		$db =& JFactory::getDBO();
		$uri =& JFactory::getURI();

		$filter_order = $application->getUserStateFromRequest( $option.'filter_order', 'filter_order', 'l.ordering', 'cmd' );
		$filter_order_Dir = $application->getUserStateFromRequest( $option.'filter_order_Dir', 'filter_order_Dir',	'', 'word' );

		// Get data from the model
		$items = & $this->get( 'Data');
		$total = & $this->get( 'Total');
		$pagination = & $this->get( 'Pagination' );

		// table ordering
		$lists['order_Dir'] = $filter_order_Dir;
		$lists['order'] = $filter_order;

		$this->assignRef('user',		JFactory::getUser());
		$this->assignRef('lists',		$lists);
		$this->assignRef('items',		$items);
		$this->assignRef('pagination',	$pagination);
		
		parent::display($tpl);
	}
}
