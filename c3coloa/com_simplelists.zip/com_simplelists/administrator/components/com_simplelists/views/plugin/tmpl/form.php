<?php 
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');

// Set toolbar items for the page
$edit = JRequest::getVar('edit',true);
$text = !$edit ? JText::_( 'New' ) : JText::_( 'Edit' );

$cparams = JComponentHelper::getParams ('com_media');

JToolBarHelper::title( JText::_( 'SimpleLists' ).' - '.JText::_( 'Plugin' ).': <small>[ ' . $text.' ]</small>' );
JToolBarHelper::save();
JToolBarHelper::apply();
if (!$edit)  {
    JToolBarHelper::cancel();
} else {
    JToolBarHelper::cancel( 'cancel', 'Close' );
}
?>

<script language="javascript" type="text/javascript">
    <!--
    function submitbutton(pressbutton) {
        var form = document.adminForm;
        if (pressbutton == 'cancel') {
            submitform( pressbutton );
            return;
        }

        // do field validation
        if (form.title.value == ""){
            alert( "<?php echo JText::_( 'Empty title', true ); ?>" );
        } else {
            submitform( pressbutton );
        }
    }
    -->
</script>
<style type="text/css">
    table.paramlist td.paramlist_key {
        width: 142px;
        text-align: left;
        height: 30px;
    }
</style>

<table width="100%">
<tr>
<td align="left" valign="top">
<form method="post" name="adminForm" id="adminForm">
    <fieldset class="adminform">
        <legend><?php echo JText::_( 'Details' ); ?></legend>
        <table class="admintable">
        <tr>
            <td width="100" align="right" class="key">
                <label for="title">
                    <?php echo JText::_( 'Title' ); ?>:
                </label>
            </td>
            <td>
                <input class="text_area" type="text" name="title" id="title" size="48" maxlength="250" value="<?php echo $this->plugin->title;?>" />
            </td>
        </tr>
        <tr>
            <td width="100" align="right" class="key">
                <label for="title">
                    <?php echo JText::_( 'Name' ); ?>:
                </label>
            </td>
            <td>
                <?php echo $this->plugin->name; ?>
            </td>
        </tr>
        <tr>
            <td width="100" align="right" class="key">
                <label for="title">
                    <?php echo JText::_( 'Group' ); ?>:
                </label>
            </td>
            <td>
                <?php echo $this->plugin->group; ?>
            </td>
        </tr>
        <tr>
            <td valign="top" align="right" class="key">
                <?php echo JText::_( 'Published' ); ?>:
            </td>
            <td>
                <?php echo $this->lists['published']; ?>
            </td>
        </tr>
        <tr>
            <td valign="top" align="right" class="key">
                <label for="ordering">
                    <?php echo JText::_( 'Order' ); ?>:
                </label>
            </td>
            <td>
                <?php echo $this->lists['ordering']; ?>
            </td>
        </tr>
        <tr>
            <td valign="top" class="key">
                <label for="access">
                    <?php echo JText::_( 'Access Level' ); ?>:
                </label>
            </td>
            <td>
                <?php echo $this->lists['access']; ?>
            </td>
        </tr>
    </table>
    </fieldset>
</td>
<td width="480" valign="top">
    <?php
    echo $this->pane->startPane("content-pane");

    $title = JText::_('Parameters').' ('.JText::_('Basic').')';
    echo $this->pane->startPanel( $title, 'params-basic' );
    echo $this->params->render( 'params', 'basic' );
    echo $this->pane->endPanel();

    $title = JText::_('Parameters').' ('.JText::_('Advanced').')';
    echo $this->pane->startPanel( $title, 'params-advanced' );
    echo $this->params->render( 'params', 'advanced' );
    echo $this->pane->endPanel();

    echo $this->pane->endPane();
    ?>
</td>
</tr>
</table>
<input type="hidden" name="option" value="com_simplelists" />
<input type="hidden" name="view" value="plugin" />
<input type="hidden" name="cid[]" value="<?php echo $this->plugin->id; ?>" />
<input type="hidden" name="task" value="" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>
</div>
