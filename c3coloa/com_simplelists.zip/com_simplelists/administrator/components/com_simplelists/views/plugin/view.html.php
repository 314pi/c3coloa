<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!  
defined('_JEXEC') or die();

// Import the needed libraries
jimport('joomla.application.component.view');
jimport('joomla.html.pane');
jimport('joomla.filter.output');

// Import the needed helpers
require_once JPATH_COMPONENT.DS.'helpers'.DS.'html.php';

/**
 * HTML View class for the Simplelists component
 *
 * @static
 * @package	Simplelists
 */
class SimplelistsViewPlugin extends JView
{
    /*
     * Method to prepare the content for display
     *
     * @param string $tpl
     * @return null
     */
	public function display($tpl = null)
	{
        // Initialize common variables
        $application =& JFactory::getApplication() ;
        $option = JRequest::getCmd( 'option' ).'-plugin';
		$user =& JFactory::getUser();
        $pane = & JPane::getInstance('sliders');
		$model	=& $this->getModel( 'plugin' );

		$lists = array();

		// get the plugin
		$plugin =& $this->get('data');
		$isNew = ($plugin->id < 1);

		// fail if checked out not by 'me'
		if ($model->isCheckedOut( $user->get('id') )) {
			$msg = JText::sprintf( 'Plugin locked', $plugin->title );
			$application->redirect( 'index.php?option='. $option, $msg );
		}

		$model->checkout( $user->get('id') );

		// build the html select list for ordering
		$query = 'SELECT ordering AS value, title AS text'
			. ' FROM #__simplelists_plugins'
			. ' ORDER BY ordering';

		// Common lists
		$lists['ordering'] = JHTML::_('list.specificordering',  $plugin, $plugin->id, $query, 1 );
        $lists['access'] = JHTML::_('list.accesslevel', $plugin );
		$lists['published'] = JHTML::_('select.booleanlist', 'published', 'class="inputbox"', $plugin->published );
        
        // Read the parameters
        $params = new JParameter( $plugin->params, JPATH_COMPONENT.DS.'models'.DS.'plugin.xml');
        
		$this->assignRef('lists', $lists);
		$this->assignRef('plugin', $plugin);
		$this->assignRef('params', $params);
        $this->assignRef('pane', $pane);

		parent::display($tpl);
	}
}
