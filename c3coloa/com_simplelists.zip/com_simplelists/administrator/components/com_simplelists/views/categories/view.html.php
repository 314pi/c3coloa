<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!  
defined('_JEXEC') or die();

// Import Joomla! libraries
jimport( 'joomla.application.component.view');

// Require the SimpleLists helper
require_once JPATH_COMPONENT.DS.'helpers'.DS.'category.php';

/**
 * HTML View class for the Simplelists component
 *
 * @static
 * @package	Simplelists
 */
class SimplelistsViewCategories extends JView
{
    /*
     * Method to prepare the content for display
     *
     * @param string $tpl
     * @return null
     */
	public function display($tpl = null)
	{
        $application = JFactory::getApplication();
        $option = JRequest::getCmd( 'option' ).'-categories';

		$db =& JFactory::getDBO();
		$uri =& JFactory::getURI();

        $listview = $application->getUserStateFromRequest( $option.'listview', 'listview', 'tree', 'cmd' );
		$filter_order = $application->getUserStateFromRequest( $option.'filter_order', 'filter_order', 'c.ordering', 'cmd' );
		$filter_order_Dir = $application->getUserStateFromRequest( $option.'filter_order_Dir', 'filter_order_Dir',	'', 'word' );
		$search = $application->getUserStateFromRequest( $option.'search', 'search', '', 'string' );
		$search = JString::strtolower( $search );

		// Get data from the model
		$items = & $this->get( 'Data');
		$total = & $this->get( 'Total');
		$pagination = & $this->get( 'Pagination' );

        // Re-order the items by parent
        if( $listview == 'tree' ) {
            $tree = new SimplelistsCategoryTree();
            $tree->setItems( $items );
            $items = $tree->getList();
        }

		// table ordering
		$lists['order_Dir'] = $filter_order_Dir;
		$lists['order'] = $filter_order;

        // listview box
        $options[] = array( 'id' => 'tree', 'title' => 'Tree' );
        $options[] = array( 'id' => 'flat', 'title' => 'Flat list' );
		$extra = 'onchange="document.adminForm.submit();"';
		$lists['listview'] = JHTML::_('select.genericlist', $options, 'listview', $extra, 'id', 'title', $listview );

		// search filter
		$lists['search']= $search;

		$this->assignRef('user',		JFactory::getUser());
		$this->assignRef('lists',		$lists);
		$this->assignRef('items',		$items);
		$this->assignRef('pagination',	$pagination);
		
		parent::display($tpl);
	}
}
