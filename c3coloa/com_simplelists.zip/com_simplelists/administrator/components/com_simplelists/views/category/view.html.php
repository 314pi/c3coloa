<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!  
defined('_JEXEC') or die();

// Import the needed libraries
jimport('joomla.application.component.view');
jimport('joomla.html.pane');
jimport('joomla.filesystem.file');
jimport('joomla.filter.output');

// Import the needed helpers
require_once JPATH_COMPONENT.DS.'helpers'.DS.'html.php';

/**
 * HTML View class for the Simplelists component
 *
 * @static
 * @package	Simplelists
 */
class SimplelistsViewCategory extends JView
{
    /*
     * Method to prepare the content for display
     *
     * @param string $tpl
     * @return null
     */
	public function display($tpl = null)
	{
        // Initialize common variables
        $application =& JFactory::getApplication() ;
        $option = JRequest::getCmd( 'option' ).'-category';
		$user =& JFactory::getUser();
        $pane = & JPane::getInstance('sliders');
		$model	=& $this->getModel( 'category' );

		$lists = array();

		// get the category
		$category =& $this->get('data');
		$isNew = ($category->id < 1);

		// fail if checked out not by 'me'
		if ($model->isCheckedOut( $user->get('id') )) {
			$msg = JText::sprintf( 'Category locked', $category->title );
			$application->redirect( 'index.php?option='. $option, $msg );
		}

		// Edit or Create
		if (!$isNew)
		{
			$model->checkout( $user->get('id') );
		}
		else
		{
			// initialise new record
			$category->published = 1;
			$category->approved = 1;
			$category->order = 0;
		}

		// build the html select list for ordering
		$query = 'SELECT ordering AS value, title AS text'
			. ' FROM #__categories'
			. ' WHERE section = "com_simplelists"' 
			. ' ORDER BY ordering';

		// Common lists
		$parent_id_params = array('nullvalue' => 1, 'current' => $category->parent_id );
		$lists['parent_id'] = SimplelistsHTML::selectCategories( 'parent_id', $parent_id_params );
		$lists['ordering'] = JHTML::_('list.specificordering',  $category, $category->id, $query, 1 );
        $lists['access'] = JHTML::_('list.accesslevel', $category );
		$lists['published'] = JHTML::_('select.booleanlist', 'published', 'class="inputbox"', $category->published );
		$lists['image_position'] = SimplelistsHTML::selectImagePosition( 'image_position', $category->image_position ? $category->image_position : 'left');
        
        // Construct the modal boxes
        $modal = array() ;
        $modal['image'] = 'index.php?option=com_simplelists&amp;view=files&amp;tmpl=component&amp;type=picture' ;
	    if( $category->image ) {
            $modal['image'] .= '&amp;folder=/'.dirname($category->image).'&amp;current='.$category->image;
        } else {
            $modal['image'] .= '&amp;current=';
        }

		//clean category data
        $category->image_directory = COM_SIMPLELISTS_DIR ;
		JFilterOutput::objectHTMLSafe( $category, ENT_QUOTES, 'text' );

        $params = new JParameter( $category->params, JPATH_COMPONENT.DS.'models'.DS.'category.xml');
        
        // Include the CSS and JavaScript
        JHTML::_('script', 'category.js', 'administrator/components/com_simplelists/js/');

		$this->assignRef('lists', $lists);
		$this->assignRef('modal', $modal);
		$this->assignRef('category', $category);
		$this->assignRef('params', $params);
        $this->assignRef('pane', $pane);

		parent::display($tpl);
	}
}
