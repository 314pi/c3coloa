<?php 
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');

// Set toolbar items for the page
$edit = JRequest::getVar('edit',true);
$text = !$edit ? JText::_( 'New' ) : JText::_( 'Edit' );

$cparams = JComponentHelper::getParams ('com_media');

JToolBarHelper::title( JText::_( 'SimpleLists' ).' - '.JText::_( 'Category' ).': <small>[ ' . $text.' ]</small>' );
JToolBarHelper::save();
JToolBarHelper::apply();
if (!$edit)  {
    JToolBarHelper::cancel();
} else {
    JToolBarHelper::cancel( 'cancel', 'Close' );
}
?>

<script language="javascript" type="text/javascript">
    <!--
    function submitbutton(pressbutton) {
        var form = document.adminForm;
        if (pressbutton == 'cancel') {
            submitform( pressbutton );
            return;
        }

        // do field validation
        if (form.title.value == ""){
            alert( "<?php echo JText::_( 'Empty title', true ); ?>" );
        } else {
            submitform( pressbutton );
        }
    }
    -->
</script>
<style type="text/css">
    table.paramlist td.paramlist_key {
        width: 142px;
        text-align: left;
        height: 30px;
    }
</style>

<table width="100%">
<tr>
<td align="left" valign="top">
<form action="index.php?option=com_simplelists&amp;view=item" method="post" name="adminForm" id="adminForm">
    <fieldset class="adminform">
        <legend><?php echo JText::_( 'Details' ); ?></legend>
        <table class="admintable">
        <tr>
            <td width="100" align="right" class="key">
                <label for="title">
                    <?php echo JText::_( 'Name' ); ?>:
                </label>
            </td>
            <td>
                <input class="text_area" type="text" name="title" id="title" size="48" maxlength="250" value="<?php echo $this->category->title;?>" />
            </td>
        </tr>
        <tr>
            <td width="100" align="right" class="key">
                <label for="alias">
                    <?php echo JText::_( 'Alias' ); ?>:
                </label>
            </td>
            <td>
                <input class="text_area" type="text" name="alias" id="alias" size="48" maxlength="250" value="<?php echo $this->category->alias;?>" />
            </td>
        </tr>
        <tr>
            <td valign="top" align="right" class="key">
                <?php echo JText::_( 'Published' ); ?>:
            </td>
            <td>
                <?php echo $this->lists['published']; ?>
            </td>
        </tr>
        <tr>
            <td valign="top" align="right" class="key">
                <label for="parent_id">
                    <?php echo JText::_( 'Parent category' ); ?>:
                </label>
            </td>
            <td>
                <?php echo $this->lists['parent_id']; ?>
            </td>
        </tr>
        <tr>
            <td valign="top" align="right" class="key">
                <label for="ordering">
                    <?php echo JText::_( 'Category Order' ); ?>:
                </label>
            </td>
            <td>
                <?php echo $this->lists['ordering']; ?>
            </td>
        </tr>
        <tr>
            <td valign="top" class="key">
                <label for="access">
                    <?php echo JText::_( 'Access Level' ); ?>:
                </label>
            </td>
            <td>
                <?php echo $this->lists['access']; ?>
            </td>
        </tr>
        <tr>
            <td valign="top" class="key">
                <label for="image">
                    <?php echo JText::_( 'Image' ); ?>
                </label>
            </td>
            <td>
                <div class="button2-left">
                    <div class="blank">
                        <a class="modal-button" title="<?php echo JText::_('Select an Image') ?>" href="<?php echo $this->modal['image']; 
                        ?>" rel="{handler: 'iframe', size: {x: 770, y: 500}}">
                        <?php echo JText::_('Select an Image'); ?>
                        </a>
                    </div>
                </div>
                &nbsp;
                <input type="text" id="image_name" value="<?php echo $this->category->image; ?>" disabled="disabled" />
                <input type="hidden" id="image" name="image" value="<?php echo $this->category->image; ?>" />
            </td>
        </tr>
        <tr>
            <td class="key">
                <label for="image_position">
                    <?php echo JText::_( 'Image Position' ); ?>:
                </label>
            </td>
            <td>
                <?php echo $this->lists['image_position']; ?>
            </td>
        </tr>
    </table>
    </fieldset>
    <fieldset class="adminform">
        <legend><?php echo JText::_( 'Text' ); ?></legend>
        <table class="admintable" width="100%">
        <tr>
            <td>
                <?php
                $editor =& JFactory::getEditor();
                echo $editor->display( 'description', $this->category->description, '100%', '300', '44', '9' ) ;
                ?>
            </td>
        </tr>
        </table>
    </fieldset>
</td>
<td width="480" valign="top">
    <?php
    echo $this->pane->startPane("content-pane");

    $title = JText::_('Parameters').' ('.JText::_('Category').')';
    echo $this->pane->startPanel( $title, "params-category" );
    echo $this->params->render( 'params', 'details' );
    echo $this->pane->endPanel();

    $title = JText::_('Parameters').' ('.JText::_('Layout').')';
    echo $this->pane->startPanel( $title, "params-layout" );
    echo $this->params->render( 'params', 'layout' );
    echo $this->pane->endPanel();

    $title = JText::_( 'Metadata Information' );
    echo $this->pane->startPanel( $title, "metadata-category" );
    echo $this->params->render( 'params', 'metadata' );
    echo $this->pane->endPanel();

    echo $this->pane->endPane();
    ?>
</td>
</tr>
</table>
<input type="hidden" name="option" value="com_simplelists" />
<input type="hidden" name="view" value="category" />
<input type="hidden" name="cid[]" value="<?php echo $this->category->id; ?>" />
<input type="hidden" name="task" value="" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>
</div>
