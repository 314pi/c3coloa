<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

class SimplelistsPluginLinkDefault {

    /*
     * Method to check whether this plugin can be used or not
     *
     * @access public
     * @param null
     * @return bool
     */
    public function isEnabled() {
        return true;
    }

    /*
     * Method to get the title for this plugin 
     *
     * @access public
     * @param null
     * @return string
     */
    public function getTitle() {
        return 'None';
    }

    /*
     * Method the friendly name of a specific item
     *
     * @access public
     * @param mixed $link
     * @return string
     */
    public function getName($link = null) {
        return $link;
    }

    /*
     * Method to build the item URL 
     *
     * @access public
     * @param object $item
     * @return string
     */
    public function getUrl($item = null) {
        return null;
    }

    /*
     * Method to build the HTML when editing a item-link with this plugin
     *
     * @access public
     * @param mixed $current
     * @return string
     */
    public function getInput($current = null) {
        return null;
    }

    /*
     * Method to display the hidden-context of this item
     *
     * @access public
     * @param object $item
     * @return mixed
     */
    public function getHidden($item) {
        header('Location: '.$this->getUrl($item->link));
        exit;
    }

    /*
     * Method to display a modal-box
     *
     * @access public
     * @param string $type
     * @param string $modal_link
     * @param mixed $current
     * @return string
     */
    public function getModal($type, $modal_link, $current = null) {
        ?>
        <div style="float:left;">
            <input type="text" id="link_name_<?php echo $type; ?>" value="<?php echo $this->getName($current); ?>" disabled="disabled" />
        </div>
        <div class="button2-left">
            <div class="blank">
                <a class="modal-button" title="<?php echo JText::_('Select '.$type); ?>" href="<?php echo $modal_link; ?>" rel="{handler: 'iframe', size: {x: 770, y: 500}}">
                    <?php echo JText::_('Select a '.$type); ?>
                </a>
            </div>
        </div>
        <input type="hidden" id="link_<?php echo $type; ?>" name="link_<?php echo $type; ?>" value="<?php echo $current; ?>" />
        <div style="clear:both"></div>
        <?php
    }
}
