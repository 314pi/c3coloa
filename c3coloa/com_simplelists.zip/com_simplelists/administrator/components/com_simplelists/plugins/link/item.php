<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// No direct access
defined('_JEXEC') or die('Restricted access');

// Include the parent class
require_once dirname(__FILE__).DS.'default.php';

class SimplelistsPluginLinkItem extends SimplelistsPluginLinkDefault {

    /*
     * Method to get the title for this plugin 
     *  
     * @access public
     * @param null
     * @return string
     */
    public function getTitle() {
        return 'Item itself';
    }    

    /*
     * Method to build the item URL 
     *
     * @access public
     * @param object $item
     * @return string
     */
    public function getUrl($item = null) {
        $slug = (int)$item->id;
        if(!empty($item->alias)) $slug .= ':'.$item->alias;
        return 'index.php?option=com_simplelists&view=item&id='.$slug;
    }

    /*
     * Method to build the HTML when editing a item-link with this plugin
     *
     * @access public
     * @param mixed $current
     * @return string
     */
    public function getInput($current = null) {
        return null;
    }
}
