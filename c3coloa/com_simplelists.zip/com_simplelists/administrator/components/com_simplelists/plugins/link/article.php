<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// No direct access
defined('_JEXEC') or die('Restricted access');

// Include the parent-class
require_once dirname(__FILE__).DS.'default.php';

class SimplelistsPluginLinkArticle extends SimplelistsPluginLinkDefault {

    /*
     * Method to get the title for this plugin 
     *  
     * @access public
     * @param null
     * @return string
     */
    public function getTitle() {
        return 'Internal article';
    }    

    /*
     * Method the friendly name of a specific item
     *
     * @access public
     * @param mixed $link
     * @return string
     */
    public function getName($link) {
        $query = "SELECT `title` FROM #__content WHERE `id`=".(int)$link;
        $db =& JFactory::getDBO();
        $db->setQuery( $query );
        $row = $db->loadObject() ;
        if(is_object($row)) {
            return $row->title ;
        } else {
            return '' ;
        }
    }

    /*
     * Method to build the item URL 
     *
     * @access public
     * @param object $item
     * @return string
     */
    public function getUrl($item = null) {

        require_once JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php' ;
        $link = $item->link;
        $url = ContentHelperRoute::getArticleRoute((int)$link);

        if(!strstr($url,'Itemid=')) {

            $query = "SELECT * FROM #__content WHERE `id`=".(int)$link;
            $db =& JFactory::getDBO();
            $db->setQuery( $query );
            $article = $db->loadObject();

            if(!empty($article)) {
                $url = ContentHelperRoute::getArticleRoute($article->id.':'.$article->alias, $article->catid, $article->sectionid );
            }
        }

        if(!strstr($url,'Itemid=')) {
            $url .= '&Itemid='.JRequest::getInt('Itemid');
        }

        return $url;
    }

    /*
     * Method to build the HTML when editing a item-link with this plugin
     *
     * @access public
     * @param mixed $current
     * @return string
     */
    public function getInput($current = null) {
        $modal_link = 'index.php?option=com_content&amp;task=element&amp;tmpl=component';
        return $this->getModal('article', $modal_link, $current);
    }
}
