<div class="simplelists-item-link-vimeo">
<object width="<?php echo $width; ?>" height="<?php echo $height; ?>">
    <param name="allowfullscreen" value="true" />
    <param name="allowscriptaccess" value="always" />
    <param name="movie" value="http://vimeo.com/moogaloop.swf?<?php echo $params; ?>" />
    <embed src="http://vimeo.com/moogaloop.swf?<?php echo $params; ?>" type="application/x-shockwave-flash" allowfullscreen="true"
    allowscriptaccess="always" width="<?php echo $width; ?>" height="<?php echo $height; ?>"></embed>
</object>
</div>
