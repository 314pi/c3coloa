<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.controller' );
require_once( JPATH_COMPONENT.DS.'helpers'.DS.'helper.php' );

/**
 * Simplelists Controller
 *
 * @package Joomla
 * @subpackage Simplelists
 */
class SimplelistsController extends JController
{
    /*
     * Variable containing the current model-name
     */
    private $model_name = null;

    /*
     * Variable containing the latest message
     */
    private $msg = null;

    /**
     * Constructor
     * @access public
     * @subpackage SimpleLists
     */
    public function __construct()
    {
        // Make sure we have set the proper view
        $this->setViewType();

        // Call the normal parent constructor
        parent::__construct();

        // Register task handlers
        $this->registerTask( 'accesspublic', 'access' );
        $this->registerTask( 'accessregistered', 'access' );
        $this->registerTask( 'accessspecial', 'access' );
        $this->registerTask( 'copy', 'edit' );
    }


    /**
     * Display the current page
     * @access public
     * @subpackage SimpleLists
     */
    public function display( )
    {
        parent::display();
    }


    /**
     * Handle the task 'add'
     * @access public
     * @subpackage SimpleLists
     */
    public function add()
    {
        $this->setForm();
        JRequest::setVar( 'edit', false );
        parent::display();
    }

    /**
     * Handle the task 'edit'
     * @access public
     * @subpackage SimpleLists
     */
    public function edit()
    {
        $this->setForm() ;
        JRequest::setVar( 'edit', true );
        $model = $this->loadModel();
        $model->checkout();
        parent::display();
    }

    /**
     * Handle the task 'store'
     * @access public
     * @subpackage SimpleLists
     */
    public function store()
    {
        JRequest::checkToken() or jexit( 'Invalid Token' );
        $post = JRequest::get('post');
        $cid = JRequest::getVar( 'cid', array(0), 'post', 'array' );
        $post['id'] = (int)$cid[0];
        $this->id = $post['id'] ;
        $post['text'] = JRequest::getVar('text', '', 'post', 'string', JREQUEST_ALLOWRAW);
        $post['description'] = JRequest::getVar('description', '', 'post', 'string', JREQUEST_ALLOWRAW);

        $model = $this->loadModel();

        if ($model->store($post)) {
            $this->id = $model->getId();
            $this->msg = JText::sprintf( 'Saved', $this->item_type );
        } else {
            $this->msg = JText::sprintf( 'Error Saving', $this->item_type );
        }

        // Check the table in so it can be edited.... we are done with it anyway
        $model->checkin();
    }


    /**
     * Handle the task 'save'
     * @access public
     * @subpackage SimpleLists
     */
    public function save()
    {
        JRequest::checkToken() or jexit( 'Invalid Token' );
        $this->store() ;

        $this->setOverviewRedirect();
    }


    /**
     * Handle the task 'apply'
     * @access public
     * @subpackage SimpleLists
     */
    public function apply()
    {
        JRequest::checkToken() or jexit( 'Invalid Token' );
        $this->store() ;

        $view = (JRequest::getVar('view') == 'category') ? 'category' : 'item' ;
        $link = 'index.php?option=com_simplelists&view='.$view.'&task=edit&cid[]=' . $this->id ;
        $this->setRedirect($link, $this->msg);
    }


    /**
     * Handle the task 'remove'
     * @access public
     * @subpackage SimpleLists
     */
    public function remove()
    {
        JRequest::checkToken() or jexit( 'Invalid Token' );
        $cid = JRequest::getVar( 'cid', array(), 'post', 'array' );
        JArrayHelper::toInteger($cid);

        if (count( $cid ) < 1) {
            JError::raiseError(500, JText::_( 'Select an item to delete' ) );
        }

        $model = $this->loadModel();
        if(!$model->delete($cid)) {
            $this->msg = $model->getError() ;
        } else {
            $this->msg = JText::sprintf( $this->item_type . ' Removed', count($cid) );
        }

        $this->setOverviewRedirect();
    }


    /**
     * Handle the task 'publish'
     * @access public
     * @subpackage SimpleLists
     */
    public function publish()
    {
        JRequest::checkToken() or jexit( 'Invalid Token' );
        $cid = JRequest::getVar( 'cid', array(), 'post', 'array' );
        JArrayHelper::toInteger($cid);

        if (count( $cid ) < 1) {
            JError::raiseError(500, JText::_( 'Select an item to publish' ) );
        }

        $model = $this->loadModel();
        if(!$model->publish($cid, 1)) {
            echo "<script> alert('".$model->getError(true)."'); window.history.go(-1); </script>\n";
        } else {
            $this->msg = JText::sprintf( $this->item_type . ' Published', count($cid) );
        }

        $this->setOverviewRedirect();
    }


    /**
     * Handle the task 'unpublish'
     * @access public
     * @subpackage SimpleLists
     */
    public function unpublish()
    {
        JRequest::checkToken() or jexit( 'Invalid Token' );
        $cid = JRequest::getVar( 'cid', array(), 'post', 'array' );
        JArrayHelper::toInteger($cid);

        if (count( $cid ) < 1) {
            JError::raiseError(500, JText::_( 'Select an item to unpublish' ) );
        }

        $model = $this->loadModel();
        if(!$model->publish($cid, 0)) {
            echo "<script> alert('".$model->getError(true)."'); window.history.go(-1); </script>\n";
        } else {
            $this->msg = JText::sprintf( $this->item_type . ' Unpublished', count($cid) );
        }
        $this->setOverviewRedirect();
    }


    /**
     * Handle the task 'cancel'
     * @access public
     * @subpackage SimpleLists
     */
    public function cancel()
    {
        JRequest::checkToken() or jexit( 'Invalid Token' );

        // Checkin the model
        $model = $this->loadModel();
        $model->checkin();

        $this->setOverviewRedirect();
    }


    /**
     * Handle the task 'orderup'
     * @access public
     * @subpackage SimpleLists
     */
    public function orderup()
    {
        JRequest::checkToken() or jexit( 'Invalid Token' );

        $model = $this->loadModel();
        $model->move(-1);

        $this->setOverviewRedirect();
    }


    /**
     * Handle the task 'orderdown'
     * @access public
     * @subpackage SimpleLists
     */
    public function orderdown()
    {
        JRequest::checkToken() or jexit( 'Invalid Token' );

        $model = $this->loadModel();
        $model->move(1);

        $this->setOverviewRedirect();
    }


    /**
     * Handle the task 'saveorder'
     * @access public
     * @subpackage SimpleLists
     */
    public function saveorder()
    {
        JRequest::checkToken() or jexit( 'Invalid Token' );
        $cid = JRequest::getVar( 'cid', array(), 'post', 'array' );
        $order = JRequest::getVar( 'order', array(), 'post', 'array' );
        JArrayHelper::toInteger($cid);
        JArrayHelper::toInteger($order);

        $model = $this->loadModel();
        $model->saveorder($cid, $order);

        $this->setOverviewRedirect();
    }

    /**
     * Handle the task 'access'
     * @access public
     * @subpackage SimpleLists
     */
    public function access( )
    {
        // Check for request forgeries
        JRequest::checkToken() or jexit( 'Invalid Token' );

        $cid    = JRequest::getVar( 'cid', array(0), 'post', 'array' );
        JArrayHelper::toInteger($cid, array(0));

        $uid    = $cid[0];
        $access = $this->getTask();
        $model = $this->loadModel();

        $db =& JFactory::getDBO();
        switch ( $access )
        {
            case 'accesspublic':
                $access = 0;
                break;

            case 'accessregistered':
                $access = 1;
                break;

            case 'accessspecial':
                $access = 2;
                break;
        }

        $row =& JTable::getInstance($this->model_name, 'Table');
        $row->load( $uid );
        $row->access = $access;

        if ( !$row->check() ) {
            return $row->getError();
        }
        if ( !$row->store() ) {
            return $row->getError();
        }

        $this->setOverviewRedirect();
    }

    /**
     * Helper function to set a type-string for later use
     * @access protected
     * @subpackage SimpleLists
     */
    protected function setViewType()
    {
        if(JRequest::getCmd('view') == '') {
            JRequest::setVar('view', 'items');
        }
    
        switch(JRequest::getCmd( 'view'))
        {
            case 'category':
                $this->item_type = 'Category' ;
                break ;
            case 'categories':
                $this->item_type = 'Categories' ;
                break ;
            case 'plugin':
                $this->item_type = 'Plugin' ;
                break ;
            case 'plugins':
                $this->item_type = 'Plugins' ;
                break ;
            case 'item':
                $this->item_type = 'Item' ;
                break ;
            default:
                $this->item_type = 'Items' ;
                break ;
        }
    }


    /**
     * Helper function to set the overview page
     * @access protected
     * @subpackage SimpleLists
     */
    public function setOverviewRedirect() {

        $view = JRequest::getCmd('view');

        switch($view) {
            case 'category':
            case 'categories':
                $view = 'categories';
                break ;

            case 'plugin':
            case 'plugins':
                $view = 'plugins';
                break ;

            default:
                $view = 'items';
                break ;
        }

        $msg = (!empty($this->msg)) ? $this->msg : null;
        $link = 'index.php?option=com_simplelists&view='.$view ;
        $this->setRedirect( $link, $msg );
    }

    /**
     * Helper function to set the form page
     * @access protected
     * @subpackage SimpleLists
     */
    protected function setForm() {

        $view = JRequest::getCmd('view');
        $task = JRequest::getCmd('task');
        $id = JRequest::getInt('id');
        $cid = JRequest::getVar('cid');

        switch($view) {
            case 'category':
            case 'categories':
                JRequest::setVar('view', 'category');
                break ;
            case 'plugin':
            case 'plugins':
                JRequest::setVar('view', 'plugin');
                break ;
            default:
                JRequest::setVar('view', 'item');
                break ;
        }

        // Hide the menu while editing or adding an item
        JRequest::setVar( 'hidemainmenu', 1 );

        // Set the layout template to 'form'
        JRequest::setVar( 'layout', 'form' );

        // If the request doesn't match the current URL, redirect
        if( JRequest::getVar('view') != $view ) {
            $link = 'index.php?option=com_simplelists&view='.JRequest::getVar('view') ;
            if(!empty($task)) $link .= '&task='.$task;
            if(!empty($id)) $link .= '&id='.$id;
            if(!empty($cid)) $link .= '&cid[]='.$cid[0];
            $this->setRedirect( $link, $this->msg);
            return false;
        }
    }


    /**
     * Helper function to load the current model
     * @access protected
     * @subpackage SimpleLists
     */
    protected function loadModel()
    {
        switch(JRequest::getVar('view')) {

            case 'category':
            case 'categories':
                $model = 'category';
                break ;

            case 'plugin':
            case 'plugins':
                $model = 'plugin';
                break;

            default:
                $model = 'item' ;
                break ;
        }
        $this->model_name = $model;
        return $this->getModel( $model );
    }
}
