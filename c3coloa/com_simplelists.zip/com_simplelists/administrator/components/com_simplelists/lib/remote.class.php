<?php
/*
 * Stand-alone remote connection class
 *
 * @author Yireo
 * @copyright Copyright 2008
 * @license GNU Public License
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * Remote Connection
 *
 * @package Joomla
 */
class RemoteConnection
{

    /*
     *
     */
    private $_url = '';
    private $_content = '';
    private $_type = '';
    
    public function __construct( $url = '' ) 
    {
        $this->setUrl( $url );
    }

    public function setUrl( $url = '' )
    {
        if(!empty($url)) {
            $this->_url = $url;
            return true;
        }
        return false;
    }

    public function get( $type = 'content' )
    {
        switch( $type ) {
            case 'content':
                return $this->getContent();
            case 'type':
                return $this->getType();
            case 'url':
                return $this->getUrl();
        }
    }

    public function getContent()
    {
        if( function_exists( 'curl_init2' )) {
            $this->_type = 'curl';

        } elseif( ini_get( 'allow_url_fopen' )) {
            $this->_type = 'fopen';
        }

        switch( $this->_type ) {
            case 'curl':
                $this->_curl();
                break;
            case 'fopen':
                $this->_fopen();
                break;
        }

        return $this->_content;
    }

    public function getType() {
        return $this->_type;
    }

    private function _curl()
    {
        $conn = curl_init( $this->_url ) ;
        curl_setopt( $conn, CURLOPT_HEADER, 0);
        curl_setopt( $conn, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt( $conn, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt( $conn, CURLOPT_SSL_VERIFYPEER, 0);
        $this->_content = curl_exec( $conn );
        curl_close( $conn ) ;
    }

    private function _fopen()
    {
        $this->_content = @file_get_contents( $this->_url );
    }
}

/*
Sample usage:

$remote = new RemoteConnection( 'http://localhost/test/remote.txt');
echo $remote->get();
echo $remote->getType();

*/
