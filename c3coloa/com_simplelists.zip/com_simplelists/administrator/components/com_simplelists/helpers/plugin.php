<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * Simplelists Plugin Helper
 * 
 * @package Joomla
 * @subpackage Simplelists
 */
class SimplelistsPluginHelper
{

    /**
     * Method to get the title of the specified link type
     *
     * @access public
     * @param string Tag for link type
     * @return string Title of link type
     */
    public function getLinkTypes() {
        return array(
            'default',
            'item',
            'custom',
            'menuitem',
            'article',
            'image',
            'file',
            'simplelist',
            'cbprofile',
            'vimeo',
        );
    }

    /**
     * Method to check wheather a certain plugin is enabled or not
     *
     * @access public
     * @param string Plugin group
     * @param string Plugin type
     * @return boolean True if enabled
     */
    public function enabled( $group, $type ) {
        return SimplelistsPluginHelper::getMethod( $group, $type, 'isEnabled' );
    }

    /**
     * Method to get a plugin resource
     *
     * @access public
     * @param string Plugin type
     * @return string Title of link type
     */
    public function getMethod( $group = null, $type = null, $method = null, $argument = null ) {
        if(!empty($type) && !empty($method)) {
            try {
                require_once JPATH_ADMINISTRATOR.DS.'components'.DS.'com_simplelists'.DS.'plugins'.DS.$group.DS.$type.'.php';
                $classname = 'SimplelistsPluginLink'.ucfirst($type);
                $class = new $classname;
                return JText::_( $class->$method($argument) );
            } catch(Exception $e) {
                return false;
            }
        }
        return false;
    }

    /**
     * Method to get the title of the specified link type
     *
     * @access public
     * @param string Plugin-type
     * @return string Title of link type
     */
    public function getLinkType( $type = null ) {
        $return = SimplelistsPluginHelper::getMethod( 'link', $type, 'getTitle' );
        return ($return == true) ? $return : JText::_('None');
    }

    /**
     * Method to get the short name of the specified link type
     *
     * @access public
     * @param string Plugin-type
     * @param string Link-string of link type
     * @return string Name of link type
     */
    public function getLinkName( $type, $link = null) {
        $return = SimplelistsPluginHelper::getMethod( 'link', $type, 'getName', $link );
        return ($return == true) ? $return : null;
    }

    /**
     * Method to get the the URL of the specified link type
     *
     * @access public
     * @param object String
     */
    public function getLinkUrl( $item ) {

        if(!is_a($item->params, 'JParameter')) {
            $item->params = new JParameter($item->params);
        }

        if($item->params->get('link_show', 1) == 0 && !empty($item->link)) {
            $url = 'index.php?option=com_simplelists&view=item&task=hidden&tmpl=component&id='.$item->id;
            if($item->alias) $url .= ':'.$item->alias;
            $return = JRoute::_( $url );

        } else {
            $return = SimplelistsPluginHelper::getMethod( 'link', $item->link_type, 'getUrl', $item );
        }
        return ($return == true) ? $return : null;
    }

    /**
     * Method to get the HTML input-box for a specific link-plugin
     *
     * @access public
     * @param string Plugin-type
     * @param string Link-string of link type
     * @return string URL of link type
     */
    public function getLinkInput( $type, $current, $selected ) {
        if($selected == false) $current = null;
        $return = SimplelistsPluginHelper::getMethod( 'link', $type, 'getInput', $current );
        return ($return == true) ? $return : null;
    }

    /**
     * Method to get the HTML input for a specific link-plugin
     *
     * @access public
     * @param string Plugin-type
     * @return object Item
     */
    public function getLinkHidden( $item ) {
        return SimplelistsPluginHelper::getMethod( 'link', $item->link_type, 'getHidden', $item );
    }
}
