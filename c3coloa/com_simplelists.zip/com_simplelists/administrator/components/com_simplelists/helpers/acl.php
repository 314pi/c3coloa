<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

$auth =& JFactory::getACL();
$auth->addACL('com_simplelists', 'manage', 'users', 'super administrator');
$auth->addACL('com_simplelists', 'manage', 'users', 'administrator');
$auth->addACL('com_simplelists', 'manage', 'users', 'manager');

