<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * Simplelists Helper
 * 
 * @package Joomla
 * @subpackage Simplelists
 */
class SimplelistsHelper
{
    /**
     * Method to fetch a single category from the database
     *
     * @access public
     * @param int ID of category
     * @return array List with this category
     */
    public function getCategory( $id = null ) {

        $query = 'SELECT c.* FROM `#__categories` AS c WHERE c.`id` = '.(int)$id;

        $db =& JFactory::getDBO();
        $db->setQuery( $query ) ;

        $rows = $db->loadObjectList() ;

        return $rows ;
    }

    /**
     * Method to fetch a list of categories from the database
     *
     * @access public
     * @param int ID of current item
     * @param int ID of parent category
     * @return array List of categories
     */
    public function getCategories( $id = null, $parent_id = null ) {

        if( is_numeric( $id )) {
            $query = 'SELECT c.* FROM `#__simplelists_categories` AS s LEFT JOIN `#__categories` AS c ON c.`id` = s.`category_id` WHERE s.`id`='.(int)$id ;
        } elseif( (int)$parent_id > 0 ) {
            $query = 'SELECT c.* FROM `#__categories` AS c WHERE c.`section` = "com_simplelists" AND c.`parent_id` = '.(int)$parent_id ;
        } else {
            $query = 'SELECT c.* FROM `#__categories` AS c WHERE c.`section` = "com_simplelists"' ;
        }

        $db =& JFactory::getDBO();
        $db->setQuery( $query ) ;

        $rows = $db->loadObjectList() ;

        return $rows ;
    }

    /**
     * Method to get the number of items within a category
     *
     * @access public
     * @param int ID of category
     * @return int Number of items
     */
    public function getNumItems( $category_id ) {

        $query = 'SELECT id FROM `#__simplelists_categories` WHERE `category_id`='.(int)$category_id ;

        $db =& JFactory::getDBO();
        $db->setQuery( $query ) ;

        $rows = $db->loadAssocList() ;
        return count($rows);
    }

    /**
     * Method to create the SimpleLists image directory
     *
     * @access public
     * @param folder-name (default 'images/simplelists')
     * @return boolean True if the folder has been created successfully
     */
    public function checkDirectory( $folder = '' ) {

        $application = JFactory::getApplication() ;

        if( $folder == '' ) {
            $folder = COM_SIMPLELISTS_BASE;
        }
        if( JFolder::exists( $folder )) {
            return true ;
        } else {
            if( JFolder::create( $folder )) {
                $application->enqueueMessage( JText::sprintf( 'Created image directory', $folder ) , 'notice' ) ;
                return true ;
            } else {
                $application->enqueueMessage( JText::sprintf( 'Failed to create directory', $folder ), 'error' ) ;
                return false ;
            }
        }
    }

    /**
     * Method to check if there is at least 1 category
     *
     * @access public
     * @param null
     * @return boolean True if there is at least 1 category
     */
    public function checkCategories() {

        $application = JFactory::getApplication() ;
        $db =& JFactory::getDBO();
        $db->setQuery( "SELECT * FROM #__categories WHERE `section`='com_simplelists'" ) ;
        $rows = $db->loadAssocList() ;
        if(empty($rows)) {
            $application->enqueueMessage( JText::_( 'No categories' ), 'notice' ) ;
            return false ;
        }
        return true ;
    }

    /**
     * Method to check the PHP-version and Joomla! version
     *
     * @access public
     * @param null
     * @return boolean True if all versions are acceptable
     */
    public function checkVersions() {

        $application = JFactory::getApplication() ;

        // Check the PHP-version
        if(version_compare(phpversion(), '5.2.0', '>=') == false) {
            $application->enqueueMessage( JText::_( 'PHP 5.2.0 or higher is required.' ), 'error' ) ;
            return false ;
        }

        // Check the Joomla!-version
        $jversion = new JVersion();
        if(version_compare($jversion->getShortVersion(), '1.5.9', '>=') == false) {
            $application->enqueueMessage( JText::_( 'Joomla! 1.5.9 or higher is required.' ), 'error' ) ;
            return false ;
        }

        return true ;
    }

    /*
     * Helper-function to return a specific Menu-Item
     *  
     * @access public
     * @param int $Itemid
     * @return object
     */
    public function getMenuItemFromItemid($Itemid = 0) {

        static $menu_items;
        if (empty($menu_items)) {
            $component = &JComponentHelper::getComponent('com_simplelists');
            $menu = &JSite::getMenu();
            $menu_items = $menu->getItems('componentid', $component->id);
           }

        foreach($menu_items as $menu_item) {
            if($menu_item->id == $Itemid) {
                return $menu_item;
            }
        }

        return null;
    }

    /*
     * Helper-function that tries to match the given category-settings with an existing Menu-Item
     *
     * @access public
     * @param int $category_id
     * @param string $layout
     * @return object
     */
    public function getMenuItem($category_id = 0, $layout = 'default') {

        static $menu_items;
        if (empty($menu_items)) {
            $component = &JComponentHelper::getComponent('com_simplelists');
            $menu = &JSite::getMenu();
            $menu_items = $menu->getItems('componentid', $component->id);
           }
           
           $near_match = null;

        if(!empty($menu_items)) {
            foreach($menu_items as $menu_item) {
                if(!empty($menu_item->query['category_id']) && !empty($menu_item->query['layout'])
                    && $menu_item->query['category_id'] == $category_id && $menu_item->query['layout'] == $layout ){
                    return $menu_item;
                } elseif( $near_match == null && !empty( $menu_item->query['category_id'] ) 
                    && $menu_item->query['category_id'] == $category_id ) {
                    $near_match = $menu_item;                  
                }
            }
        }
        return $near_match;
    }

    /*
     * Helper-function to build a proper SimpleLists system-URL
     * 
     * @access public
     * @param int $category_id
     * @param string $category_alias
     * @param string $layout
     * @param int $item_id
     * @param int $menu_id
     * @param string $item_alias
     * @return string
     */
    public function getUrl( $category_id = 0, $category_alias = '', $layout = '', $item_id = null, $menu_id = null, $item_alias = null )
    {
        $url = 'index.php?option=com_simplelists&view=simplelist' ;

        if(empty($layout)) {
            $layout = JRequest::getCmd('layout');
        }

        if( !empty($layout)) {
            $url .= '&layout='.$layout ;
        }

        if( empty( $category_alias )) {
            require_once (dirname(__FILE__).DS.'category.php');
            $category_alias = SimplelistsCategoryHelper::getAlias($category_id);
        }
        $url .= '&category_id='.(int)$category_id.':'.$category_alias;

        if( !empty($menu_id)) {
            $url .= '&Itemid='.$menu_id;
        }
        
        $url = JRoute::_( $url );

        if(!empty($item_alias)) {
            $url .= '#' . $item_alias;
        } elseif( $item_id > 0 ) {
            $url .= '#item' . (int)$item_id ;
        }

        return $url;
    }

    /*
     * An override of the original JView-function to allow template-files across multiple layouts
     *
     * @access public
     * @param string $file
     * @return string
     */
    public function loadTemplate($file = null)
    {
        // clear prior output
        $output = null;

        // clean the file name
        $file = preg_replace('/[^A-Z0-9_\.-]/i', '', $file);

        // load the template script
        jimport('joomla.filesystem.path');
        $filetofind = $this->_createFileName('template', array('name' => $file));
        $template = JPath::find($this->_path['template'], $filetofind);

        if ($template != false)
        {
            // unset so as not to introduce into template scope
            unset($file);

            // never allow a 'this' property
            if (isset($this->this)) {
                unset($this->this);
            }

            // start capturing output into a buffer
            ob_start();
            // include the requested template filename in the local scope
            // (this will execute the view logic).
            include $template;

            // done with the requested template; get the buffer and
            // clear it.
            $output = ob_get_contents();
            ob_end_clean();

            return $output;
        }
        else {
            return null;
        }
    }

    /*
     * Helper-method to add CSS-stylesheets to the HTML-document
     * 
     * @access public
     * @param string $sheet
     * @return string
     */
    public function addCss($sheet = null)
    {
        $template = JFactory::getApplication()->getTemplate();
        if(file_exists(JPATH_SITE.DS.'templates'.DS.$template.DS.'html'.DS.'com_simplelists'.DS.'css'.DS.$sheet)) {
            JHTML::_( 'stylesheet', 'templates/'.$template.'/html/com_simplelists/css/'.$sheet, '' );
        } elseif(file_exists(JPATH_SITE.DS.'components'.DS.'com_simplelists'.DS.'css'.DS.$sheet)) {
            JHTML::_( 'stylesheet', 'components/com_simplelists/css/'.$sheet, '' );
        }
    }

    /*
     * Helper-method to add JavaScript-scripts to the HTML-document
     * 
     * @access public
     * @param string $script
     * @return string
     */
    public function addJs($script = null)
    {
        $template = JFactory::getApplication()->getTemplate();
        if(file_exists(JPATH_SITE.DS.'templates'.DS.$template.DS.'html'.DS.'com_simplelists'.DS.'js'.DS.$script)) {
            JHTML::_( 'script', 'templates/'.$template.'/html/com_simplelists/js/'.$script, '' );
        } elseif(file_exists(JPATH_SITE.DS.'components'.DS.'com_simplelists'.DS.'js'.DS.$script)) {
            JHTML::_( 'script', 'components/com_simplelists/js/'.$script, '' );
        }
    }

    /*
     * Helper-method to create a backend thumbnail for an image
     * 
     * @access public
     * @param string $script
     * @return string
     */
    public function createThumbnail($image, $ext, $src_width, $src_height, $dest_width, $dest_height)
    {
        // Check for the caching folder
        $folder = JPATH_ADMINISTRATOR.DS.'cache'.DS.'com_simplelists';
        if(!JFolder::exists($folder)) {
            JFolder::create($folder);
        }

        // Check again for the caching folder
        if(!JFolder::exists($folder)) {
            // @todo: Create a warning
            return null;
        }

        // Check for an existing thumbnail image
        $thumb_file = md5($image).'.'.$ext;
        $thumb_path = $folder.DS.$thumb_file;
        if(is_file($thumb_path) && is_readable($thumb_path)) {
            return 'administrator/cache/com_simplelists/'.$thumb_file;
        }

        // Create an image depending on the image-type
        switch($ext) {
            case 'jpg':
            case 'jpeg':
                $source = imagecreatefromjpeg($image);
                break;
            case 'gif':
                $source = imagecreatefromgif($image);
                break;
            case 'png':
                $source = imagecreatefrompng($image);
                break;
            default:
                return $image;
        }

        // Initialize the thumbnail
        $thumb = imagecreatetruecolor($dest_width, $dest_height);

        // Resize the thumbnail
        imagecopyresized($thumb, $source, 0, 0, 0, 0, $dest_width, $dest_height, $src_width, $src_height);

        // Save the thumbnail
        switch($ext) {
            case 'jpg':
            case 'jpeg':
                imagejpeg( $thumb, $thumb_path, 50 );
                break;
            case 'png':
                imagepng( $thumb, $thumb_path, 50 );
                break;
            case 'gif':
                imagegif( $thumb, $thumb_path );
                break;
            default:
                return $image;
        }

        // Return the thumbnail
        return 'administrator/cache/com_simplelists/'.$thumb_file;
    }
}
