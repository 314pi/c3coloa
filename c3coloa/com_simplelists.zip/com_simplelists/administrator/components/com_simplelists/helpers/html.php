<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * Simplelists HTML Helper
 * 
 * @package Joomla
 * @subpackage Simplelists
 */
class SimplelistsHTML
{

	/**
	 * Method to parse a list of categories into a HTML selectbox
	 *
	 * @access	public
	 * @param	int ID of current item 
	 * @param	int ID of parent category
	 * @return	string HTML output
	 */
    public function getCategories( $parent_id = 0 ) 
    {

        // Include the SimplelistsCategoryTree helper-class
        require_once JPATH_ADMINISTRATOR.DS.'components'.DS.'com_simplelists'.DS.'helpers'.DS.'category.php';

        // Fetch the categories and parse them in a tree
        $categories = SimplelistsHelper::getCategories( null, $parent_id ) ;
        $tree = new SimplelistsCategoryTree( $categories );
        $categories = $tree->getList();

        // Add a prefix to the category-title depending on the category-level
        foreach( $categories as $cid => $category ) {

            // Add a simple prefix to the category name
            $prefix = '';
            for( $i = 1; $i < $category->level; $i++ ) {
                $prefix .= '--';
            }

            if( !empty( $prefix )) {
                $category->title = $prefix . ' ' . $category->title ;
            }

            $categories[$cid] = $category;
        }

		return $categories;
    }

	/**
	 * Method to set the current category
	 *
	 * @access	public
	 * @param	int ID of current item 
	 * @param	int ID of parent category
	 * @return	string HTML output
	 */
    public function getCurrentCategory( $categories, $item_id = 0 ) 
    {

        // If there is no current item yet and we only have one category, select it
        if( $item_id == 0 ) {
            if( count($categories) == 1 ) {
                $current = $categories ;
            } else {
                $application = JFactory::getApplication();
                $option = JRequest::getCmd('option');
        		$id = $application->getUserStateFromRequest( $option.'filter_category_id', 'filter_category_id', 0, 'int' );
                $current = SimplelistsHelper::getCategory( $id );
            }
        
        // Fetch the categories currently selected with the item
        } else {
            $current = SimplelistsHelper::getCategories( $item_id ) ;
        }

		return $current;
    }

	/**
	 * Method to parse a list of categories into a HTML selectbox
	 *
	 * @access	public
	 * @param	int ID of current item 
	 * @param	int ID of parent category
	 * @return	string HTML output
	 */
    public function selectCategories( $name = '', $params = array()) 
    {

    	// If the $parent_id is set, only return those categories below it 
    	if(isset($params['parent_id'])) {
    		$categories = SimplelistsHTML::getCategories( $params['parent_id'] );
    		
    	// Otherwise fetch all categories
    	} else {
    		$categories = SimplelistsHTML::getCategories();
    	}
	
    	// If the $item_id is set, find all the current categories for a SimpleLists item
    	$current = null;
    	if(isset($params['item_id'])) {
    		$current = SimplelistsHTML::getCurrentCategory( $categories, $params['item_id'] );
    	}
    	$current = (isset($params['current'])) ? $params['current'] : $current;
        
        $extra = '';

        // If $multiple is true, we assume we're in the Item Edit form
        if( isset($params['multiple']) && $params['multiple'] == 1 ) {
            $size = (count($categories) < 10) ? count($categories) : 10 ;
            $extra .= 'size="'.$size.'" multiple';
        }
        
        // If $none is true, we include an extra option
        if( isset($params['nullvalue']) && $params['nullvalue'] == 1) {
        	array_unshift( $categories, JHTML::_('select.option', 0, '- '.JText::_( 'Select Category' ).' -', 'id', 'title' ));
        }

        // If $javascript is true, we submit the form as soon as an option has been selected
        if( isset($params['javascript']) && $params['javascript'] == 1 ) {
		    $extra .= 'onchange="document.adminForm.submit();"';
        }

		return JHTML::_('select.genericlist', $categories, $name, $extra, 'id', 'title', $current );
    }

	/**
	 * Method to parse a list of link-types into a HTML selectbox
	 *
	 * @access	public
	 * @param	int ID of current option
	 * @return	string HTML output
	 */
    public function selectLinkType( $current = '' ) 
    {

        $options = array();

        $options[] = JHTML::_('select.option', '', '- '.JText::_( 'Select Link Type' ).' -', 'id', 'title' );
        foreach( SimplelistsPluginHelper::getLinkTypes() as $link_type ) {
            $options[] = JHTML::_('select.option', $link_type, SimplelistsPluginHelper::getLinkType( $link_type ), 'id', 'title' );
        }

		$javascript 	= 'onchange="document.adminForm.submit();"';

		return JHTML::_('select.genericlist', $options, 'filter_link_type', $javascript, 'id', 'title', $current );
    }

	/**
	 * Method to parse a list of link-types into a HTML selectbox
	 *
	 * @access	public
	 * @param	int ID of current option
	 * @return	string HTML output
	 */
    public function selectImagePosition($name, $default) 
    {
        $options[] = array( 'id' => 'left', 'title' => 'Left' );
        $options[] = array( 'id' => 'right', 'title' => 'Right' );
        $options[] = array( 'id' => 'center', 'title' => 'Center' );
        $options[] = array( 'id' => 'top', 'title' => 'Top' );
        $options[] = array( 'id' => 'bottom', 'title' => 'Bottom' );
		return JHTML::_('select.genericlist', $options, $name, null, 'id', 'title', $default);
    }
}
