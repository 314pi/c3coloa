<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!  
defined('_JEXEC') or die();

// Import Joomla! libraries
jimport('joomla.application.component.model');

class SimplelistsModelItems extends JModel
{
    /**
     * Item data array
     *
     * @var array
     */
    var $_data = null;

    /**
     * Item total
     *
     * @var integer
     */
    var $_total = null;

    /**
     * Pagination object
     *
     * @var object
     */
    var $_pagination = null;

    /**
     * Constructor
     *
     * @access public
     * @param null
     * @return null
     */
    public function __construct()
    {
        parent::__construct();

        $application = JFactory::getApplication();
        $option = JRequest::getCmd( 'option' ).'-items';

        // Get the pagination request variables
        $limit = $application->getUserStateFromRequest( 'global.list.limit', 'limit', $application->getCfg('list_limit'), 'int' );
        $limitstart = $application->getUserStateFromRequest( $option.'limitstart', 'limitstart', 0, 'int' );

        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
    }

    /**
     * Method to get items data
     *
     * @access public
     * @param null
     * @return array
     */
    public function getData()
    {
        // Lets load the content if it doesn't already exist
        if (empty($this->_data)) {
            $query = $this->_buildQuery();
            $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
            //echo $this->_db->getQuery();
        }

        return $this->_data;
    }

    /**
     * Method to get the total number of items
     *
     * @access public
     * @param null
     * @return integer
     */
    public function getTotal()
    {
        // Lets load the content if it doesn't already exist
        if (empty($this->_total)) {
            $query = $this->_buildQuery();
            $this->_total = $this->_getListCount($query);
        }

        return $this->_total;
    }

    /**
     * Method to get a pagination object for the items
     *
     * @access public
     * @param null
     * @return integer
     */
    public function getPagination()
    {
        // Lets load the content if it doesn't already exist
        if (empty($this->_pagination)) {
            jimport('joomla.html.pagination');
            $this->_pagination = new JPagination( $this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
        }

        return $this->_pagination;
    }

    /**
     * Method to build the database query
     *
     * @access private
     * @param null
     * @return null
     */
    private function _buildQuery()
    {
        // Get the WHERE and ORDER BY clauses for the query
        $where = $this->_buildContentWhere();
        $orderby = $this->_buildContentOrderBy();

        $query = ' SELECT a.*, u.name AS editor, g.name AS groupname '
            . ' FROM #__simplelists AS a '
            . ' LEFT JOIN #__users AS u ON u.id = a.checked_out '
            . ' LEFT JOIN #__groups AS g ON g.id = a.access'
            . $where
            . $orderby
        ;

        return $query;
    }

    /**
     * Method to build the ORDERBY-part of the database query
     *
     * @access private
     * @param null
     * @return string
     */
    private function _buildContentOrderBy()
    {
        $application = JFactory::getApplication();
        $option = JRequest::getCmd( 'option' ).'-items';

        $filter_order = $application->getUserStateFromRequest( $option.'filter_order', 'filter_order', 'a.ordering', 'cmd' );
        $filter_order_Dir = $application->getUserStateFromRequest( $option.'filter_order_Dir', 'filter_order_Dir', '', 'word' );

        if ($filter_order == 'a.ordering'){
            $orderby = ' ORDER BY a.ordering '.$filter_order_Dir;
        } else {
            $orderby = ' ORDER BY '.$filter_order.' '.$filter_order_Dir.' , a.ordering ';
        }

        return $orderby;
    }

    /**
     * Method to build the WHERE-part of the database query
     *
     * @access private
     * @param null
     * @return string
     */
    private function _buildContentWhere()
    {
        $application = JFactory::getApplication();
        $option = JRequest::getCmd( 'option' ).'-items';

        $filter_state = $application->getUserStateFromRequest( $option.'filter_state', 'filter_state', '', 'word' );
        $filter_link_type = $application->getUserStateFromRequest( $option.'filter_link_type', 'filter_link_type', '', 'cmd' );
        $filter_category_id = $application->getUserStateFromRequest( $option.'filter_category_id', 'filter_category_id', 0, 'int' );
        $filter_order = $application->getUserStateFromRequest( $option.'filter_order', 'filter_order', 'a.ordering', 'cmd' );
        $filter_order_Dir = $application->getUserStateFromRequest( $option.'filter_order_Dir', 'filter_order_Dir', '', 'word' );
        $search = $application->getUserStateFromRequest( $option.'search', 'search', '', 'string' );
        $search = JString::strtolower( $search );

        $where = array();

        if ($filter_category_id > 0) {
            $where[] = 'a.id IN (SELECT `id` FROM `#__simplelists_categories` WHERE `category_id`='.(int) $filter_category_id.')';
        }

        if (!empty($filter_link_type)) {
            if($filter_link_type == 'none') $filter_link_type = '';
            $where[] = 'a.link_type ='. $this->_db->Quote( $filter_link_type );
        }

        if ($search) {
            $where[] = 'LOWER(a.title) LIKE '.$this->_db->Quote('%'.$search.'%');
        }

        if ( $filter_state ) {
            if ( $filter_state == 'P' ) {
                $where[] = 'a.published = 1';
            } else if ($filter_state == 'U' ) {
                $where[] = 'a.published = 0';
            }
        }

        $where = ( count( $where ) ? ' WHERE '. implode( ' AND ', $where ) : '' );

        return $where;
    }
}
