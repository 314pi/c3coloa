<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!  
defined('_JEXEC') or die();

// Import Joomla! libraries
jimport('joomla.application.component.model');

class SimplelistsModelCategories extends JModel
{
    /**
     * Category data array
     *
     * @var array
     */
    var $_data = null;

    /**
     * Category total
     *
     * @var integer
     */
    var $_total = null;

    /**
     * Pagination object
     *
     * @var object
     */
    var $_pagination = null;

    /**
     * Constructor
     *
     * @access public
     * @param null
     * @return null
     */
    public function __construct()
    {
        parent::__construct();

        $application = JFactory::getApplication();
        $option = JRequest::getCmd( 'option' ).'-categories';

        // Get the pagination request variables
        $limit = $application->getUserStateFromRequest( 'global.list.limit', 'limit', $application->getCfg('list_limit'), 'int' );
        $limitstart = $application->getUserStateFromRequest( $option.'limitstart', 'limitstart', 0, 'int' );

        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
    }

    /**
     * Method to get simplelists item data
     *
     * @access public
     * @param null
     * @return array
     */
    public function getData()
    {
        // Lets load the content if it doesn't already exist
        if (empty($this->_data)) {
            $query = $this->_buildQuery();
            $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
            if(!empty( $this->_data )) {
                foreach( $this->_data as $category ) {
                    $category->active = $this->getActive( $category->id ) ;
                }
            }
        }

        return $this->_data;
    }

    /**
     * Method to get the total number of categories
     *
     * @access public
     * @param null
     * @return integer
     */
    public function getTotal()
    {
        // Lets load the content if it doesn't already exist
        if (empty($this->_total)) {
            $query = $this->_buildQuery();
            $this->_total = $this->_getListCount($query);
        }

        return $this->_total;
    }

    /**
     * Method to get a pagination object for the simplelists
     *
     * @access public
     * @param null
     * @return JPagination
     */
    public function getPagination()
    {
        // Lets load the content if it doesn't already exist
        if (empty($this->_pagination)) {
            jimport('joomla.html.pagination');
            $this->_pagination = new JPagination( $this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
        }

        return $this->_pagination;
    }

    /**
     * Method to get the number of active items
     *
     * @access public
     * @param 
     * @return JPagination
     */
    public function getActive( $catid = 0 )
    {
        $query = 'SELECT COUNT( s.id )'
            . ' FROM #__simplelists AS s'
            . ' WHERE s.simplelists_id = '. (int)$catid 
        ;
        $this->_db->setQuery( $query );
        $active = $this->_db->loadResult();
        return $active ;
    }

    /**
     * Method to build the database query
     *
     * @access private
     * @param null
     * @return string
     */
    private function _buildQuery()
    {
        // Get the WHERE and ORDER BY clauses for the query
        $where = $this->_buildContentWhere();
        $orderby = $this->_buildContentOrderBy();

        $query = ' SELECT c.*, u.name AS editor, g.name AS groupname, p.title AS parent_title, p.checked_out AS parent_checked_out '
            . ' FROM #__categories AS c '
            . ' LEFT JOIN #__categories AS p ON p.id = c.parent_id '
            . ' LEFT JOIN #__users AS u ON u.id = c.checked_out '
            . ' LEFT JOIN #__groups AS g ON g.id = c.access'
            . $where
            . $orderby
        ;

        return $query;
    }

    /**
     * Method to build the ORDERBY-part of the database query
     *
     * @access private
     * @param null
     * @return string
     */
    private function _buildContentOrderBy()
    {
        $application = JFactory::getApplication();
        $option = JRequest::getCmd( 'option' ).'-categories';

        $filter_order = $application->getUserStateFromRequest( $option.'filter_order',        'filter_order',        'c.ordering',    'cmd' );
        $filter_order_Dir = $application->getUserStateFromRequest( $option.'filter_order_Dir',    'filter_order_Dir',    '',                'word' );

        if ($filter_order == 'c.ordering'){
            $orderby = ' ORDER BY c.ordering '.$filter_order_Dir;
        } else {
            $orderby = ' ORDER BY '.$filter_order.' '.$filter_order_Dir.' , c.ordering ';
        }

        return $orderby;
    }

    /**
     * Method to build the WHERE-part of the database query
     *
     * @access private
     * @param null
     * @return string
     */
    private function _buildContentWhere()
    {
        $application = JFactory::getApplication();
        $option = JRequest::getCmd( 'option' ).'-categories';

        $filter_state = $application->getUserStateFromRequest( $option.'filter_state', 'filter_state', '', 'word' );
        $filter_category_id = $application->getUserStateFromRequest( $option.'filter_category_id','filter_category_id', 0, 'int' );
        $filter_order = $application->getUserStateFromRequest( $option.'filter_order', 'filter_order', 'c.ordering', 'cmd' ); 
        $filter_order_Dir = $application->getUserStateFromRequest( $option.'filter_order_Dir', 'filter_order_Dir', '', 'word' );
        $search = $application->getUserStateFromRequest( $option.'search', 'search', '', 'string' );
        $search = JString::strtolower( $search );

        $where = array();

        $where[] = 'c.section = "com_simplelists"' ;

        //if ($filter_category_id > 0) {
        //    $where[] = 'a.category_id = '.(int) $filter_category_id;
        //}

        if ($search) {
            $where[] = 'LOWER(c.title) LIKE '.$this->_db->Quote('%'.$search.'%');
        }
        if ( $filter_state ) {
            if ( $filter_state == 'P' ) {
                $where[] = 'c.published = 1';
            } else if ($filter_state == 'U' ) {
                $where[] = 'c.published = 0';
            }
        }

        $where = ( count( $where ) ? ' WHERE '. implode( ' AND ', $where ) : '' );

        return $where;
    }
}
