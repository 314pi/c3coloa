<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// Import Joomla! libraries
jimport('joomla.application.component.model');

class SimplelistsModelPlugin extends JModel
{
    /**
     * Plugin id
     *
     * @var int
     */
    var $_id = null;

    /**
     * Plugin data
     *
     * @var array
     */
    var $_data = null;

    /**
     * Constructor
     *
     * @param null
     * @return null
     */
    public function __construct()
    {
        parent::__construct();

        $array = JRequest::getVar('cid', array(0), '', 'array');
        $edit = JRequest::getVar('edit',true);
        if($edit) $this->setId((int)$array[0]);
    }

    /**
     * Method to set the cateogry identifier
     *
     * @access public
     * @param int $id Plugin identifier
     * @return null
     */
    public function setId($id)
    {
        // Set category id and wipe data
        $this->_id = $id;
        $this->_data = null;
    }

    /**
     * Method to get the item identifier
     *
     * @access public
     * @param null
     * @return int Item identifier
     */
    public function getId()
    {
        return $this->_id;
    }

    /**
     * Method to get a category
     *
     * @access public
     * @param null
     * @return array
     */
    public function &getData()
    {
        // Load the category data
        if ($this->_loadData()) {
            // Initialize some variables
            $user = &JFactory::getUser();

            // Check to see if the category is published
            if (!$this->_data->published) {
                JError::raiseError( 404, JText::_("Resource Not Found") );
                return;
            }

            // Check whether category access level allows access
            if ($this->_data->access > $user->get('aid', 0)) {
                JError::raiseError( 403, JText::_('Not authorized') );
                return;
            }
        }
        else  $this->_initData();

        return $this->_data;
    }

    /**
     * Tests if category is checked out
     *
     * @access public
     * @param int $uid A user ID
     * @return boolean True if checked out
     */
    public function isCheckedOut($uid = 0)
    {
        if ($this->_loadData()) {
            if ($uid) {
                return ($this->_data->checked_out && $this->_data->checked_out != $uid);
            } else {
                return $this->_data->checked_out;
            }
        }
    }

    /**
     * Method to checkin/unlock the category
     *
     * @access public
     * @param null
     * @return boolean True on success
     */
    public function checkin()
    {
        if ($this->_id) {
            $category = & $this->getTable();
            if(! $category->checkin($this->_id)) {
                $this->setError($this->_db->getErrorMsg());
                return false;
            }
        }
        return false;
    }

    /**
     * Method to checkout/lock the category
     *
     * @access public
     * @param int $uid User ID of the user checking the article out
     * @return boolean True on success
     */
    public function checkout($uid = null)
    {
        if ($this->_id) {
            // Make sure we have a user id to checkout the article with
            if (is_null($uid)) {
                $user =& JFactory::getUser();
                $uid = $user->get('id');
            }
            // Lets get to it and checkout the thing...
            $category = & $this->getTable();
            if(!$category->checkout($uid, $this->_id)) {
                $this->setError($this->_db->getErrorMsg());
                return false;
            }

            return true;
        }
        return false;
    }

    /**
     * Method to store the category
     *
     * @access public
     * @param array $data
     * @return boolean True on success
     */
    public function store($data)
    {
        $row =& $this->getTable();

        // Bind the form fields to the category table
        if (!$row->bind($data)) {
            $this->setError($this->_db->getErrorMsg());
            return false;
        }

        // if new item, order last in appropriate group
        //if (!$row->id) {
        //    $where = 'category_id = ' . (int) $row->category_id ;
        //    $row->ordering = $row->getNextOrder( $where );
        //}

        // Make sure the category table is valid
        if (!$row->check()) {
            $this->setError($this->_db->getErrorMsg());
            return false;
        }

        // Store the category table to the database
        if (!$row->store()) {
            $this->setError($this->_db->getErrorMsg());
            return false;
        }

        return true;
    }

    /**
     * Method to remove a category
     *
     * @access public
     * @param array $cid
     * @return boolean True on success
     */
    public function delete($cid = array())
    {
        if (count( $cid )) {
            JArrayHelper::toInteger($cid);
            $cids = implode( ',', $cid );

            $query = 'DELETE FROM #__simplelists_plugins'
                . ' WHERE id IN ( '.$cids.' )';
            $this->_db->setQuery( $query );
            if(!$this->_db->query()) {
                $this->setError($this->_db->getErrorMsg());
                return false;
            }
        }

        return true;
    }

    /**
     * Method to (un)publish a plugin
     *
     * @access public
     * @param array $cid
     * @param int $publish
     * @return boolean True on success
     */
    public function publish($cid = array(), $publish = 1)
    {
        $user =& JFactory::getUser();

        if (count( $cid )) {
            JArrayHelper::toInteger($cid);
            $cids = implode( ',', $cid );

            $query = 'UPDATE #__simplelists_plugins'
                . ' SET published = '.(int) $publish
                . ' WHERE id IN ( '.$cids.' )'
                . ' AND ( checked_out = 0 OR ( checked_out = '.(int) $user->get('id').' ) )'
            ;
            $this->_db->setQuery( $query );
            if (!$this->_db->query()) {
                $this->setError($this->_db->getErrorMsg());
                return false;
            }
        }

        return true;
    }

    /**
     * Method to move a plugin
     *
     * @access public
     * @param array $cid
     * @param string $order
     * @return boolean True on success
     */
    public function saveorder($cid = array(), $order)
    {
        $row =& $this->getTable();

        // update ordering values
        for( $i=0; $i < count($cid); $i++ ) {
            $row->load( (int) $cid[$i] );
            if ($row->ordering != $order[$i]) {
                $row->ordering = $order[$i];
                if (!$row->store()) {
                    $this->setError($this->_db->getErrorMsg());
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Method to move a plugin
     *
     * @access public
     * @param int $i
     * @return boolean True on success
     */
    public function move($i) 
    {
        $row =& $this->getTable();
        $row->load( (int)$this->_id );
        $row->ordering = $row->ordering + $i;
        if (!$row->store()) {
            $this->setError($this->_db->getErrorMsg());
            return false;
        }
        return true;
    }

    /**
     * Method to load content plugin data
     *
     * @access private
     * @param null
     * @return boolean True on success
     */
    private function _loadData()
    {
        // Lets load the content if it doesn't already exist
        if (empty($this->_data)) {
            $query = 'SELECT p.* '.
                ' FROM #__simplelists_plugins AS p' .
                ' WHERE p.id = '.(int) $this->_id;
            $this->_db->setQuery($query);
            $this->_data = $this->_db->loadObject();
            return (boolean) $this->_data;
        }
        return true;
    }

    /**
     * Method to initialise the plugin data
     *
     * @access private
     * @param null
     * @return boolean True on success
     */
    private function _initData()
    {
        // Lets load the content if it doesn't already exist
        if (empty($this->_data)) {
            $plugin = new stdClass();
            $plugin->id = 0;
            $plugin->title = null;
            $plugin->name = null;
            $plugin->group = null;
            $plugin->checked_out = 0;
            $plugin->checked_out_time = null;
            $plugin->published = 0;
            $plugin->ordering = 0;
            $plugin->access = null;
            $plugin->params = null;
            $this->_data = $plugin;
            return (boolean) $this->_data;
        }
        return true;
    }
}
