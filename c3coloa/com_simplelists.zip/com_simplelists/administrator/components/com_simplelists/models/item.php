<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// Import Joomla! libraries
jimport('joomla.application.component.model');
jimport('joomla.utilities.date');

class SimplelistsModelItem extends JModel
{
    /**
     * Item id
     *
     * @var int
     */
    var $_id = null;

    /**
     * Item data
     *
     * @var array
     */
    var $_data = null;

    /**
     * Constructor
     *
     * @access public
     * @param null
     * @return null
     */
    public function __construct()
    {
        parent::__construct();

        $array = JRequest::getVar('cid', array(0), '', 'array');
        $edit = JRequest::getVar('edit',true);
        if($edit && $this->_id == null) {
            $this->setId((int)$array[0]);
        }
    }

    /**
     * Method to set the item identifier
     *
     * @access public
     * @param int $id Item identifier
     * @return null
     */
    public function setId($id)
    {
        // Set item id and wipe data
        $this->_id = $id;
        $this->_data = null;
    }

    /**
     * Method to get the item identifier
     *
     * @access public
     * @param null
     * @return int Item identifier
     */
    public function getId()
    {
        return $this->_id;
    }

    /**
     * Method to set something in the internal data
     *
     * @access public
     * @param string $name
     * @param mixed $value
     * @return null
     */
    public function setData($name, $value = null)
    {
        $this->_data->$name = $value;
    }

    /**
     * Method to get an item
     *
     * @access public
     * @param null
     * @return null
     */
    public function &getData()
    {
        // Load the item data
        if (!$this->_loadData()) {
            $this->_initData();

        } else {
            // Initialize some variables
            $user = &JFactory::getUser();

            // Check whether category access level allows access
            if ($this->_data->access > $user->get('aid', 0)) {
                JError::raiseError( 403, JText::_('Not authorized') );
                return;
            }

        }
        return $this->_data;
    }

    /**
     * Tests if item is checked out
     *
     * @access public
     * @param int $uid A user id
     * @return boolean True if checked out
     */
    public function isCheckedOut($uid = 0)
    {
        if ($this->_loadData()) {
            if ($uid) {
                return ($this->_data->checked_out && $this->_data->checked_out != $uid);
            } else {
                return $this->_data->checked_out;
            }
        }
    }

    /**
     * Method to checkin/unlock the item
     *
     * @access public
     * @param null
     * @return boolean True on success
     */
    public function checkin()
    {
        if ($this->_id) {
            $item = &$this->getTable();
            if(!$item->checkin($this->_id)) {
                $this->setError($this->_db->getErrorMsg());
                return false;
            }
        }
        return false;
    }

    /**
     * Method to checkout/lock the item
     *
     * @access public
     * @param int $uid User ID of the user checking the article out
     * @return boolean True on success
     */
    public function checkout($uid = null)
    {
        if ($this->_id) {
            // Make sure we have a user id to checkout the article with
            if (is_null($uid)) {
                $user =& JFactory::getUser();
                $uid = $user->get('id');
            }

            // Checkout the table
            $item = & $this->getTable();
            if(!$item->checkout($uid, $this->_id)) {
                $this->setError($this->_db->getErrorMsg());
                return false;
            }

            return true;
        }
        return false;
    }

    /**
     * Method to store the item
     *
     * @access public
     * @param array $data
     * @return boolean True on success
     */
    public function store($data)
    {
        $row =& $this->getTable();

        // Insert $categories manually
        if(!empty( $data['categories'] )) {
            $categories = $data['categories'] ;
            unset($data['categories']) ;
        }

        // Insert $link manually
        $type = $data['link_type'];
        if(!empty($data['link_'.$type])) {
            $data['link'] = $data['link_'.$type];
        }

        // Get the user metadata
        $now = new JDate('now');
        $user =& JFactory::getUser();
        $uid = $user->get('id');

        // Set the modification date
        $data['modified'] = (!empty( $data['params']['modified'] ))? $data['params']['modified'] : $now->toMySQL();
        $data['modified_by'] = (!empty( $data['params']['modified_by'] ))? $data['params']['modified_by'] : $uid;
        unset( $data['params']['modified'] );
        unset( $data['params']['modified_by'] );

        // Set the creation date if the item is new
        if( $data['id'] == 0 ) {
            $data['created'] = $now->toMySQL();
            $data['created_by'] = $uid ;
        }
        
        // Overwrite the creation date if it is set in the parameters
        if(!empty( $data['params']['created'] )) {
            $data['created'] = $data['params']['created'];
        }
        if(!empty( $data['params']['created_by'] )) {
            $data['created_by'] = $data['params']['created_by'];
        }
        unset( $data['params']['created'] );
        unset( $data['params']['created_by'] );
        
        // Remove the old category-relations
        if( $data['id'] == 0 && count($categories) == 1 ) {
            $query = 'SELECT MAX(item.ordering) FROM `#__simplelists` AS item '
                . ' LEFT JOIN `#__simplelists_categories` AS category ON category.id = item.id '
                . ' WHERE category.category_id = '.$categories[0];
            $this->_db->setQuery( $query );
            $data['ordering'] = $this->_db->loadResult() + 1;
        }

        // Bind the form fields to the item table
        if (!$row->bind($data)) {
            $this->setError($this->_db->getErrorMsg());
            return false;
        }

        // Make sure the item table is valid
        if (!$row->check()) {
            $this->setError($this->_db->getErrorMsg());
            return false;
        }

        // Store the item table to the database
        if (!$row->store()) {
            $this->setError($this->_db->getErrorMsg());
            return false;
        }

        // Save the ID for later usage
        $this->_id = $row->id;

        // Remove the old category-relations
        if( $row->id > 0 ) {
            $query = 'DELETE FROM `#__simplelists_categories` WHERE id='.(int)$row->id;
            $this->_db->setQuery( $query );
            $this->_db->query();
        }

        // Store the new category-relations
        if( !empty($categories) ) {
            foreach( $categories as $c ) {
                $query = 'INSERT INTO `#__simplelists_categories` SET id='.(int)$row->id.', category_id='.(int)$c;
                $this->_db->setQuery( $query );
                $this->_db->query();
            }
        }

        return true;
    }

    /**
     * Method to remove an item
     *
     * @access public
     * @param array $cid
     * @return boolean True on success
     */
    public function delete($cid = array())
    {
        $result = false;

        if (count( $cid )) {
            JArrayHelper::toInteger($cid);
            $cids = implode( ',', $cid );
            $query = 'DELETE FROM #__simplelists WHERE id IN ( '.$cids.' )';
            $this->_db->setQuery( $query );
            if(!$this->_db->query()) {
                $this->setError($this->_db->getErrorMsg());
                return false;
            }

            $query = 'DELETE FROM #__simplelists_categories WHERE id IN ( '.$cids.' )';
            $this->_db->setQuery( $query );
            if(!$this->_db->query()) {
                $this->setError($this->_db->getErrorMsg());
                return false;
            }

        }

        return true;
    }

    /**
     * Method to (un)publish an item
     *
     * @access public
     * @param array $cid
     * @param int $publish
     * @return boolean True on success
     */
    public function publish($cid = array(), $publish = 1)
    {
        $user =& JFactory::getUser();

        if (count( $cid )) {
            JArrayHelper::toInteger($cid);
            $cids = implode( ',', $cid );

            $query = 'UPDATE #__simplelists'
                . ' SET published = '.(int) $publish
                . ' WHERE id IN ( '.$cids.' )'
                . ' AND ( checked_out = 0 OR ( checked_out = '.(int) $user->get('id').' ) )'
            ;
            $this->_db->setQuery( $query );
            if (!$this->_db->query()) {
                $this->setError($this->_db->getErrorMsg());
                return false;
            }
        }

        return true;
    }

    /**
     * Method to move an item
     *
     * @access public
     * @param string $direction
     * @return boolean True on success
     */
    public function move($direction)
    {
        $row =& $this->getTable();
        if (!$row->load($this->_id)) {
            $this->setError($this->_db->getErrorMsg());
            return false;
        }

        if (!$row->move( $direction, ' published >= 0 ' )) {
            $this->setError($this->_db->getErrorMsg());
            return false;
        }

        return true;
    }

    /**
     * Method to move an item
     *
     * @access public
     * @param array $cid
     * @param string $order
     * @return boolean True on success
     */
    public function saveorder($cid = array(), $order)
    {
        $row =& $this->getTable();
        $groupings = array();

        // Update ordering values
        for( $i=0; $i < count($cid); $i++ ) {
            $row->load( (int) $cid[$i] );

            if ($row->ordering != $order[$i])
            {
                $row->ordering = $order[$i];
                if (!$row->store()) {
                    $this->setError($this->_db->getErrorMsg());
                    return false;
                }
            }
        }
        
        // Check if only one category has been selected
        $application = JFactory::getApplication();
        $option = JRequest::getCmd('option');
        $filter_category_id = $application->getUserStateFromRequest( $option.'filter_category_id', 'filter_category_id', 0, 'int' );
        if( $filter_category_id > 0 ) {
            $row->reorder( 'id IN ( '. implode( ',', $cid ) .')');
        }
        return true;
    }

    /**
     * Method to load content item data
     *
     * @access private
     * @param null
     * @return boolean True on success
     */
    private function _loadData()
    {
        // Lets load the content if it doesn't already exist
        if (empty($this->_data)) {
            $query = 'SELECT w.*' .
                ' FROM #__simplelists AS w' .
                ' WHERE w.id = '.(int) $this->_id ;
            $this->_db->setQuery($query);
            $this->_data = $this->_db->loadObject();

            // Fetch the extra link data
            if( $this->_data ) {
                $this->_data->link_data = array();
                if( $this->_data->link_type ) {
                    $this->_data->link_data[$this->_data->link_type] = SimplelistsPluginHelper::getLinkName( $this->_data->link_type, $this->_data->link );
                }
            }

            // Set the items data
            if(JRequest::getCmd('task') == 'copy') {
                $this->_data->id = 0;
                $this->_data->title = $this->_data->title.' ['.JText::_('Copy').']';
                $this->_data->alias = null;
            }

            return (boolean) $this->_data;
        }
        return true;
    }

    /**
     * Method to initialise the item data
     *
     * @access private
     * @param null
     * @return boolean True on success
     */
    private function _initData()
    {
        // Lets load the content if it doesn't already exist
        if (empty($this->_data)) {
            $item = new stdClass();
            $item->id = 0;
            $item->created = null;
            $item->created_by = 0;
            $item->created_by_alias = null;
            $item->modified = null;
            $item->modified_by = 0;
            $item->modified_by_alias = null;
            $item->title = null;
            $item->alias = null;
            $item->link_type = null; 
            $item->link_data = null;
            $item->link = null;
            $item->text = null;
            $item->published = 0;
            $item->access = 0;
            $item->checked_out = 0;
            $item->checked_out_time = 0;
            $item->ordering = 0;
            $item->hits = 0;
            $item->params = null;
            $item->picture = null;
            $this->_data = $item;
            return (boolean) $this->_data;
        }
        return true;
    }
}
