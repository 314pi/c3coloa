<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Include library dependencies
jimport('joomla.filter.input');

/**
* Plugin Table class
*
* @package SimpleLists
*/
class TablePlugin extends JTable
{
	/**
	 * Primary Key
	 *
	 * @public int
	 */
	public $id = null;

	/**
	 * @public string
	 */
	public $title = null;

	/**
	 * @public string
	 */
	public $name = null;

	/**
	 * @public string
	 */
	public $group = null;

	/**
	 * @public int
	 */
	public $checked_out = 0;

	/**
	 * @public int
	 */
	public $checked_out_time = 0;

	/**
	 * @public int
	 */
	public $published = 0;

	/**
	 * @public int
	 */
	public $ordering = 0;

	/**
	 * @public int
	 */
	public $access = 0;

	/**
	 * @public int
	 */
	public $params = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	public function __construct(& $db) {
		parent::__construct('#__simplelists_plugins', 'id', $db);
	}

	/**
	* Overloaded bind function
	*
	* @acces public
	* @param array $hash named array
	* @return null|string	null is operation was satisfactory, otherwise returns an error
	*/
	public function bind($array, $ignore = '')
	{
		if (key_exists( 'params', $array ) && is_array( $array['params'] )) {
			$registry = new JRegistry();
			$registry->loadArray($array['params']);
			$array['params'] = $registry->toString();
		}

		return parent::bind($array, $ignore);
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 */
	public function check()
	{
        $application =& JFactory::getApplication() ;

		/** check for valid name */
		if (trim($this->title) == '') {
            $application->enqueueMessage( JText::_('Empty title'), 'error' ) ;
			return false;
		}

		jimport('joomla.filter.output');

		return true;
	}
}
