<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Include library dependencies
jimport('joomla.filter.input');

/**
* Item Table class
*
* @package		SimpleLists
* @since 1.5.0.1
*/
class TableItem extends JTable
{
	/**
	 * Primary Key
	 *
	 * @public int
	 */
	public $id = null;

	/**
	 * @public string
	 */
	public $title = null;

	/**
	 * @public string
	 */
	public $alias = null;

	/**
	 * @public string
	 */
	public $link = null;

	/**
	 * @public int
	 */
	public $link_type = null;

	/**
	 * @public string
	 */
	public $text = null;

	/**
	 * @public string
	 */
	public $picture = null;

	/**
	 * @public boolean
	 */
	public $checked_out = 0;

	/**
	 * @public string
	 */
	public $created = null;

	/**
	 * @public int
	 */
	public $created_by = null;

	/**
	 * @public string
	 */
	public $created_by_alias = null;

	/**
	 * @public string
	 */
	public $modified = null;

	/**
	 * @public int
	 */
	public $modified_by = null;

	/**
	 * @public string
	 */
	public $modified_by_alias = null;

	/**
	 * @public int
	 */
	public $ordering = null;

	/**
	 * @public int
	 */
	public $hits = null;

	/**
	 * @public int
	 */
	public $published = null;

	/**
	 * @public int
	 */
	public $access = null;

	/**
	 * @public int
	 */
	public $params = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	public function __construct(& $db) {
		parent::__construct('#__simplelists', 'id', $db);
	}

	/**
	* Overloaded bind function
	*
	* @acces public
	* @param array $hash named array
	* @return null|string	null is operation was satisfactory, otherwise returns an error
	*/
	public function bind($array, $ignore = '')
	{
        if( empty($array['alias'])) {
            $array['alias'] = JFilterOutput::stringURLSafe($array['title']);
        }

		if (key_exists( 'params', $array ) && is_array( $array['params'] )) {
			$registry = new JRegistry();
			$registry->loadArray($array['params']);
			$array['params'] = $registry->toString();
		}

		return parent::bind($array, $ignore);
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 */
	public function check()
	{
		/** check for valid name */
		if (trim($this->title) == '') {
			$this->_error = JText::_('Empty title');
			return false;
		}

		jimport('joomla.filter.output');

		return true;
	}
}
