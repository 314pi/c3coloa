<?php
/**
 * Joomla! 1.5 component Simple Lists
 *
 * @author Yireo
 * @copyright Copyright (C) 2008 Yireo
 * @license GNU/GPL
 * @link https://www.yireo.com/
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Include library dependencies
jimport('joomla.filter.input');

/**
* Category Table class
*
* @package SimpleLists
*/
class TableCategory extends JTable
{
	/**
	 * Primary Key
	 *
	 * @public int
	 */
	public $id = null;

	/**
	 * @public int
	 */
	public $parent_id = null;

	/**
	 * @public string
	 */
	public $title = null;

	/**
	 * @public string
	 */
	public $name = null;

	/**
	 * @public string
	 */
	public $alias = null;

	/**
	 * @public string
	 */
	public $image = null;

	/**
	 * @public string
	 */
	public $section = null;

	/**
	 * @public string
	 */
	public $image_position = null;

	/**
	 * @public string
	 */
	public $description = null;

	/**
	 * @public int
	 */
	public $published = 0;

	/**
	 * @public int
	 */
	public $checked_out = 0;

	/**
	 * @public int
	 */
	public $checked_out_time = 0;

	/**
	 * @public string
	 */
	public $editor = null;

	/**
	 * @public int
	 */
	public $ordering = 0;

	/**
	 * @public int
	 */
	public $access = 0;

	/**
	 * @public int
	 */
	public $count = 0;

	/**
	 * @public int
	 */
	public $params = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	public function __construct(& $db) {
		parent::__construct('#__categories', 'id', $db);
	}

	/**
	* Overloaded bind function
	*
	* @acces public
	* @param array $hash named array
	* @return null|string	null is operation was satisfactory, otherwise returns an error
	*/
	public function bind($array, $ignore = '')
	{
        if( empty($array['alias'])) {
            $array['alias'] = JFilterOutput::stringURLSafe($array['title']);
        }

		if (key_exists( 'params', $array ) && is_array( $array['params'] )) {
			$registry = new JRegistry();
			$registry->loadArray($array['params']);
			$array['params'] = $registry->toString();
		}

        // Allways override the section
        $array['section'] = 'com_simplelists' ;

		return parent::bind($array, $ignore);
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 */
	public function check()
	{
        $application =& JFactory::getApplication() ;

        /** make sure the parent_id doesn't match the id */
        if ($this->id > 0 && $this->id == $this->parent_id) {
            $application->enqueueMessage( JText::_('Category can not be its own parent'), 'error' ) ;
			return false;
        }

		/** check for valid name */
		if (trim($this->title) == '') {
            $application->enqueueMessage( JText::_('Empty title'), 'error' ) ;
			return false;
		}

		jimport('joomla.filter.output');

		return true;
	}
}
