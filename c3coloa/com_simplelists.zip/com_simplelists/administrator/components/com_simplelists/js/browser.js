var current_item = '' ;

function setModalItem( path, file ) {

    if( base_path ) {
        current_item = base_path.replace(/^\//, '') + '/' + file;
    } else {
        current_item = file;
    }

        $$('div.item a').setStyle('background-color', '#ffffff' );
        $$('div.item a').setStyle('border-color', '#eeeeee' );

    $(path).setStyle('background-color', '#eeeeee'); 
    $(path).setStyle('border-color', '#5a5a5a'); 
    $('folder-indicator').setText( current_item );
}

function submitModalForm(target, value) {
    /*if(target != null && value != null && value.length > 0) {*/
    if(target != null) {
        target(value);
    }
    window.parent.document.getElementById('sbox-window').close();
}
