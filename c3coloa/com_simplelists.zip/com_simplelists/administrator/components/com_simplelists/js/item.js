function submitbutton(pressbutton) {

    var form = document.adminForm;
    if (pressbutton == 'cancel') {
        submitform( pressbutton );
        return;
    }

    // do field validation
    if (form.title.value == ""){
        alert( form_no_title );
    } else {
        submitform( pressbutton );
    }
}

function jSelectArticle(id, title) {
    document.getElementById('link_article').value = id;
    document.getElementById('link_name_article').value = title;
    document.getElementById('link_type_article').checked = true;
    document.getElementById('sbox-window').close();
}

function jSelectLinkImage(path) {
    document.getElementById('link_image').value = path;
    document.getElementById('link_name_image').value = path;
    document.getElementById('link_type_image').checked = true;
    document.getElementById('sbox-window').close();
}

function jSelectLinkFile(path) {
    document.getElementById('link_file').value = path;
    document.getElementById('link_name_file').value = path;
    document.getElementById('link_type_file').checked = true;
    document.getElementById('sbox-window').close();
}

function jSelectPicture(path) {
    document.getElementById('picture_name').value = path;
    document.getElementById('picture').value = path;
    document.getElementById('sbox-window').close();
    /*
    if (document.adminForm.picture.value !='') {
        document.adminForm.item_picture.src= '../images/simplelists/' + document.adminForm.picture.value;
    } else {
        document.adminForm.item_picture.src='images/blank.png';
    }
    */
}

function createCookie(name,value,days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime()+(days*24*60*60*1000));
        var expires = "; expires="+date.toGMTString();
    }
    else var expires = "";
    document.cookie = name +"="+value+expires+"; path=/";
}

function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}

window.addEvent('domready', function() {

    jpanes = new Accordion($$('.panel h3.jpane-toggler'), $$('.panel div.jpane-slider'), {
        onActive: function(toggler, i) {
            toggler.addClass('jpane-toggler-down'); 
            toggler.removeClass('jpane-toggler'); 
        },
        onBackground: function(toggler, i) { 
            toggler.addClass('jpane-toggler');
            toggler.removeClass('jpane-toggler-down'); 
        },
        onComplete: function() {
            SLCookie.write('jpane', this.previous );  
        },
        duration: 300,
        opacity: false 
    });

    var current = SLCookie.read('jpane');
    if( current > 0 ) {
        jpanes.display( current );
    } else {
        jpanes.display( 0 );
    }

});

