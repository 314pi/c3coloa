DROP TABLE `#__attachments`;
