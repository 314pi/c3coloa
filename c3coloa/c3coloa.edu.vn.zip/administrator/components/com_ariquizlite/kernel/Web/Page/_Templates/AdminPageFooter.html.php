<?php
	defined('ARI_FRAMEWORK_LOADED') or die('Direct Access to this location is not allowed.');
?>
<br/>
<div style="text-align: center;">
<a href="http://www.ari-soft.com/Joomla-Components/ARI-Quiz-Lite/Detailed-product-flyer.html" target="_blank" title="ARI Quiz Lite">ARI Quiz Lite</a> is developed by <a href="http://www.ari-soft.com" target="_blank" title="ARI Soft">ARI Soft</a> under <a href="http://www.gnu.org/licenses/gpl-2.0.html" target="_blank">GNU/GPL License</a>.
</div>