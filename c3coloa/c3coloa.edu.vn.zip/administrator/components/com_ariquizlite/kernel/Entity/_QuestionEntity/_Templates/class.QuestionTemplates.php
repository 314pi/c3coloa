<?php
define('ARI_QT_TEMPLATE_XML', '<?xml version="1.0" encoding="%s" ?><%s />');
?>