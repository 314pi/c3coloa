<?php
	defined('ARI_FRAMEWORK_LOADED') or die('Direct Access to this location is not allowed.');
?>
<table class="adminlist">
	<tr>
		<td>
			<?php AriQuizWebHelper::displayResValue('RichText.Help', false); ?>
		</td>
	</tr>
</table>