<?php
require_once 'blang_add.html.php';
?>