<?php
if (!isset($GLOBALS['_ariQuizConfig'])) $GLOBALS['_ariQuizConfig'] = array (
  'Version' => '1.1.3',
);
?>