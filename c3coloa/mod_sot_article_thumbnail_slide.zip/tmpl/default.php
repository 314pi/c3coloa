<?php
/*------------------------------------------------------------------------
 # Sot Article Thumbnail Slide  - Version 1.0
 # @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 # @Author: Sky Of Tech
 # @Websites: http://skyoftech.com
 # @Email: contactnum1@gmail.com
 # Copyright (C) 2010-2011 Sky Of Tech. All Rights Reserved.
 -------------------------------------------------------------------------*/
 
defined( '_JEXEC' ) or die( 'Restricted access' );

if(count($items)>0):
$imgLeft = ceil(($small_thumb_width+10)/2);
$document =& JFactory::getDocument();
$width_sot_nav = count($items)*17;

if($browser->Name=='msie' && intval($browser->Version)==7){
	$bottom = 12;
} else { $bottom = 0; }

$styles =
'#sot_container_'.$module->id.' span.sot_thumbnail_row{ background:transparent url("'.JURI::root().'/modules/mod_sot_article_thumbnail_slide/assets/images/triangle.png") no-repeat top center !important;
	width:15px; height:6px; position:absolute; bottom:0px; left:'.($imgLeft-8).'px;
}
#sot_container_'.$module->id.' ul.sot_nav li.sot_preview{ display:none; width:'.$small_thumb_width.'px; bottom:'.$bottom.'px; z-index: 1001; position:absolute;
}
#sot_container_'.$module->id.' .sot_preview_wrapper{ width:'.$small_thumb_width.'px; height:'.$small_thumb_height.'px; border:5px solid #fff; bottom:6px; overflow:hidden; position:relative; -moz-box-shadow:0px 0px 5px #999; -webkit-box-shadow:0px 0px 5px #999; box-shadow:0px 0px 5px #999;
}
#sot_container_'.$module->id.' .sot_image_wrapper{ width:'.$thumb_width.'px; height:'.$thumb_height.'px; overflow:hidden; position:relative;margin:0 auto;-moz-box-shadow:0px 0px 5px #999;-webkit-box-shadow:0px 0px 5px #999;box-shadow:0px 0px 5px #999;
}
#sot_container_'.$module->id.' ul.sot_nav{ list-style:none;position:relative;top:10px;margin:0 auto; width:'.$width_sot_nav.'px}
';

$document->addStyleDeclaration($styles);

?>

<div style="position:relative;margin-top:30px"></div>
<div id="sot_container_<?php echo $module->id;?>" class="sot_container" style="width: <?php echo ($thumb_width);?>px; height: <?php echo ($thumb_height);?>px; background-color:red; position:relative">
	<div class="sot_image_wrapper">
		<!-- First initial image -->
		<img src="<?php echo $items[0]['thumb'];?>" alt="" />
	</div>
	<div id="sot-thumbSlide-shortDesc-<?php echo $module->id;?>" style="width: <?php echo ($thumb_width);?>px; overflow:hidden; position:absolute; bottom:0px;height:100%;left:0px;">
		<?php foreach($items as $key=>$item): ?>	
			<div id="thumbSlide-shortDesc-<?php echo $module->id."-".$key;?>" class="sot-cs-title" <?php if($key!=0):?> style="display:none" <?php  endif;?> >
				<div style="position:relative; padding:0px 10px 0px 10px">
					<div class="sot-thumbnail-slide-title">
						<?php if($link_title):?>
							<a href="<?php echo $item['link'];?>" target="<?php echo $target;?>" style="font-weight:bold;color:#264AF4; text-decoration:none; border:none"><?php echo $item['sub_title'];?></a>
						<?php else:?>
							<?php echo $item['sub_title'];?>
						<?php endif;?>
					</div>
					<div><?php echo $item['sub_content'];?></div>
					<?php if($show_readmore):?>
						<div>
							<a href="<?php echo $item['link'];?>" target="<?php echo $target;?>" style="font-weight:bold;color:#264AF4; text-decoration:none; border:none">++ <?php echo JText::_('read more ');?></a>
						</div>
					<?php endif; ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
	<?php if(!$show_navigation){ $style='style="display:none"';} else {$style='';} ?>
		<!-- Navigation items -->
		<div class="sot_next" <?php echo $style;?>></div>
		<div class="sot_prev" <?php echo $style;?>></div>
		<!-- Dot list with thumbnail preview -->
	
		<ul class="sot_nav" <?php echo $style;?>>
			<?php foreach($items as $key=>$item):?>		
				<li <?php if($key==0):?>class="selected"<?php endif;?> ><a href="javascript:void(0)" rel="<?php echo $item['thumb']."::::".$item['small_thumb'];?>" onclick="javascript:void(0)"><?php echo htmlspecialchars($item['sub_title']);?></a></li>
			<?php endforeach; ?>
			
			<li class="sot_preview">
				<div class="sot_preview_wrapper">
					<!-- Thumbnail comes here -->
				</div>
				<!-- Little triangle -->
				<span class="sot_thumbnail_row"></span>
			</li>
		</ul>

</div>
<div style="position:relative; margin-bottom:20px"></div>

<script type="text/javascript">
	jSot(document).ready(function($) {
		$objSweetThumb = jSot("#sot_container_<?php echo $module->id;?>").sweetThumbnails({
			$imgLeft:<?php echo $imgLeft;?>,
			$moduleId:<?php echo $module->id;?>,
			$timer:<?php echo $timer;?>,
			$stop_when_hover:<?php echo $hover;?>,
			$auto_play:<?php echo $auto_play;?>		
		});				
	
	});
</script>
<?php endif;?>