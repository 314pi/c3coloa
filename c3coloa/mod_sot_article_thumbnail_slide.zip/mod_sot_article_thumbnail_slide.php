<?php
/*------------------------------------------------------------------------
 # Sot Article Thumbnail Slide  - Version 1.0
 # @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 # @Author: Sky Of Tech
 # @Websites: http://skyoftech.com
 # @Email: contactnum1@gmail.com
 # Copyright (C) 2010-2011 Sky Of Tech. All Rights Reserved.
 -------------------------------------------------------------------------*/
 
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once (dirname(__FILE__).DS.'helper.php');

/*-- start---*/
$description 			= $params->get("description", 0);
$thumb_width 			= $params->get("thumb_width", 500);
$thumb_height 			= $params->get("thumb_height", 300);
$small_thumb_width 		= $params->get("small_thumb_width", 70);
$small_thumb_height 	= $params->get("small_thumb_height", 40);
$auto_play				= $params->get("auto_play", 1);
$navigation_position	= $params->get("navigation_position", 'bottom');
$timer					= $params->get("timer", 4000);
$show_navigation		= $params->get("show_navigation", 1);
$show_readmore			= $params->get("show_readmore", 1);
$link_title				= $params->get("link_title", 1);
$hover					= $params->get("hover", 1);	
$target					= $params->get("target", 1);

JHTML::stylesheet('style.css', JURI::base() . '/modules/'.$module->module.'/assets/');		
$modArHelper = new modArticlesHelper();
$items = $modArHelper->excute($params, $module);

$browser = new Browser();

/** include js file **/
if (!defined ('SOTJQUERY'))
{
	define ('SOTJQUERY', 1);
	JHTML::script('jquery1.5-sot.min.js', JURI::base() . 'modules/'.$module->module.'/assets/');
}	

if (!defined ('SOTTHUMBSLIDE'))
{
	define ('SOTTHUMBSLIDE', 1);
	JHTML::script('sweet_thumbnails.js', JURI::base() . 'modules/'.$module->module.'/assets/');
}
/** include js file **/

$path = JModuleHelper::getLayoutPath( 'mod_sot_article_thumbnail_slide');
if (file_exists($path)) {
	require($path);
}
?>
