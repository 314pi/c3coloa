<?php
/*------------------------------------------------------------------------
 # Sot Article Thumbnail Slide  - Version 1.0
 # Copyright (C) 2010-2011 Sky Of Tech. All Rights Reserved.
 # @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 # Author: Sky Of Tech
 # Websites: http://skyoftech.com
 -------------------------------------------------------------------------*/
 

require_once (JPATH_SITE . '/components/com_content/helpers/route.php');
require_once (JPATH_SITE .DS.'modules'.DS.$module->module.DS.'libs'.DS.'SimpleImage'.DS.'SimpleImage.php');

if (! class_exists("SotArticles") ) {
class SotArticles {
	var $sections_cates = array();
	var $article_ids = array();	
	var $is_frontpage = 0;	// 0 - without frontpage, 1 - only frontpage - 2 both
	var $type = 0;
	var $limit = 5;	
	var $sort_order_field = 'created';
	var $type_order = 'ASC';	
	var $thumb_width = '40';
	var $thumb_height = '40';
	var $web_url = '';	
	var $cropresizeimage = 0;
	var $max_title = 0;
	var $max_description = 0;
	var $resize_folder = '';
	var $url_to_resize = '';
	
	function Article() {
		
	}
		
	function getList() {
			global $mainframe;			
			$items = array();
			
			$db = & JFactory::getDBO ();
			$user = & JFactory::getUser ();
			$aid = $user->get ( 'aid', 0 );
			
			$contentConfig = &JComponentHelper::getParams ( 'com_content' );
			$noauth = ! $contentConfig->get ( 'shownoauth' );
			
			jimport ( 'joomla.utilities.date' );
			$date = new JDate ( );
			$now = $date->toMySQL ();	
			$nullDate = $db->getNullDate ();	
								
			/** Get category ids **/            
			$str_cat_ids = '';
			$str_art_ids = '';
			if($this->article_ids=='')
			{
				$sections_cates = $this->sections_cates;
				if (is_array($sections_cates)){
					$arr_s = array();
					$arr_c = array();
					foreach($sections_cates as $key=>$sc){
						$data = split('-',$sc);
						if($data[0]=='cat'){
							$arr_c[$data[2].'-'.$data[1]] = $data[1];
						} else {
							$arr_s[$data[1]] = $data[2];
						}
					}
					if(!empty($arr_c)){
						foreach($arr_c as $key=>$c){
							$s_id = split('-',$key);
							if(array_key_exists($s_id[0],$arr_s)){
								unset($arr_s[$s_id[0]]);
							}
						}
					}
					
					$arr_result = array_merge($arr_s,$arr_c);
					$str_cat_ids = implode(',',$arr_result);
				   
					
				} else { 
					$data = split('-',$sections_cates);
					if($data[0]=='cat'){
						$str_cat_ids = $data[1];
					}else{
						$str_cat_ids = $data[2];
					}     
				}
			}
			else
			{
				$str_art_ids = trim($this->article_ids);
			}
			/** Get category ids **/
			
			// query to determine article count
			$query = 'SELECT a.*,u.name as creater,cc.description as catdesc, cc.title as cattitle,s.description as secdesc, s.title as sectitle,' 
				. ' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(":", a.id, a.alias) ELSE a.id END as slug,' 
				. ' CASE WHEN CHAR_LENGTH(cc.alias) THEN CONCAT_WS(":", cc.id, cc.alias) ELSE cc.id END as catslug,' 
				. ' CASE WHEN CHAR_LENGTH(s.alias) THEN CONCAT_WS(":", s.id, s.alias) ELSE s.id END as secslug' 
				. ' FROM #__content AS a' . ' INNER JOIN #__categories AS cc ON cc.id = a.catid' 
				. ' INNER JOIN #__sections AS s ON s.id = a.sectionid' . ' left JOIN #__users AS u ON a.created_by = u.id';          
			
             $query .= ' WHERE a.state = 1 ' . ($noauth ? ' AND a.access <= ' . ( int ) $aid . ' AND cc.access <= ' . ( int ) $aid . ' AND s.access <= ' . ( int ) $aid : '') 
				 . ' AND (a.publish_up = ' . $db->Quote ( $nullDate ) . ' OR a.publish_up <= ' . $db->Quote ( $now ) . ' ) ' 
				 . ' AND (a.publish_down = ' . $db->Quote ( $nullDate ) . ' OR a.publish_down >= ' . $db->Quote ( $now ) . ' )' 				 
				 . ' AND cc.section = s.id' 
				 . ' AND cc.published = 1' 
				 . ' AND s.published = 1';
            
			if ($this->is_frontpage == 0) {
				$query .= ' AND a.id not in (SELECT content_id FROM #__content_frontpage )';
			} else if ($this->is_frontpage == 1) {
				$query .= ' AND a.id in (SELECT content_id FROM #__content_frontpage )';
			}

			if($str_art_ids!='')
			{
				$query .= " AND a.id in (".$str_art_ids.")";
			}
			else{
				$query .= " AND cc.id in (". $str_cat_ids .")";
			}

			if ($this->sort_order_field == 'random') {				
				$orderby =  ' ORDER BY rand()';			
			} 
			else 
			{				
				$orderby = ' ORDER BY ' . $this->sort_order_field . ' ' . $this->type_order;			
			}
			$limit = " LIMIT {$this->limit}";

			$query .= $orderby . $limit;     
			$db->setQuery ( $query );			  			
			$rows = $db->loadObjectList ();
				
			JPluginHelper::importPlugin ( 'content' );
			$dispatcher = & JDispatcher::getInstance ();
			$params =& JComponentHelper::getParams('com_content');
			
			$limitstart = $this->limit;
			
			for($i = 0; $i < count ( $rows ); $i ++) {
				$rows [$i]->text = $rows [$i]->introtext;
				$results = $dispatcher->trigger ( 'onPrepareContent', array (& $rows [$i], & $params, $limitstart ) );
				$rows [$i]->introtext = $rows [$i]->text;
				$items[$i]['id'] = $rows [$i]->id;
				$items[$i]['img'] = $this->getImage($rows [$i]->text);
				$items[$i]['title'] = $rows[$i]->title;
				$items[$i]['content'] = $this->removeImage($rows [$i]->text);
				
				$link   = JRoute::_(ContentHelperRoute::getArticleRoute($rows [$i]->slug, $rows [$i]->catslug, $rows [$i]->sectionid));				
				$items[$i]['link'] = $link;
			}
			
			$items = $this->update($items);
			
			return $items;
		}		
	
	
	function getImage($str){
			
    		$regex = "/\<img.+src\s*=\s*\"([^\"]*)\"[^\>]*\>/";
    		$matches = array();
			preg_match ( $regex, $str , $matches );    
			$images = (count($matches)) ? $matches : array ();
			$image = count($images) > 1 ? $images[1] : '';
						
			return $image;
	}
	
	function getItemid($sectionid) {
		$contentConfig = &JComponentHelper::getParams ( 'com_content' );
		$noauth = ! $contentConfig->get ( 'shownoauth' );
		$user = & JFactory::getUser ();
		$aid = $user->get ( 'aid', 0 );
		$db = & JFactory::getDBO ();
		$query = "SELECT id FROM #__menu WHERE `link` like '%option=com_content%view=section%id=$sectionid%'" . ' AND published = 1' . ($noauth ? ' AND access <= ' . ( int ) $aid : '');
		
		$db->setQuery ( $query );
		return $db->loadResult ();
	}
	
	function removeImage($str) {
		$regex1 = "/\<img[^\>]*>/";
		$str = preg_replace ( $regex1, '', $str );
		$regex1 = "/<div class=\"mosimage\".*<\/div>/";
		$str = preg_replace ( $regex1, '', $str );
		$str = trim ( $str );
		
		return $str;
	}
		
	
	function update($items) {		
		$tmp = array();
		
		foreach ($items as $key => $item) {
			if (!isset($item['sub_title'])) {
				$item['sub_title'] = $this->truncate($item['title'], $this->max_title, '...', true, true);
			}
			if (!isset($item['sub_content'])) {
				$content = $this->truncate($item['content'], $this->max_description, '...', true, true);
				$item['sub_content'] = $content;//preg_replace(array('/<a/','/<\/a>/'), array('&lt;a','&lt;/a&gt;'), $content);
			}
			
			if (!isset($item['thumb']) && $item['img'] != '') {
				$item['thumb'] = $this->processImage($item['img'], $this->thumb_width, $this->thumb_height);
			} else {
				$item['thumb'] = '';
			}		
			
			if (!isset($item['small_thumb']) && $item['img'] != '') {
				$item['small_thumb'] = $this->processImage($item['img'], $this->small_thumb_width, $this->small_thumb_height);
			} else {
				$item['small_thumb'] = '';
			}
			
			if ($item['thumb'] != '') {			
				$tmp[] = $item;
			}
		}
		
		return $tmp;				
	}
	
	function processImage($img, $width, $height) {
				
		if ($this->cropresizeimage == 0) {
			return $this->resizeImage($img, $width, $height);
		} else {
			return $this->cropImage($img, $width, $height);
		}
	}
		
	function resizeImage($imagePath, $width, $height) {
		global $module;
				
		$folderPath = $this->resize_folder;
		 
		 if(!JFolder::exists($folderPath)){
		 		JFolder::create($folderPath);	 
		 }
		 
		 $nameImg = str_replace('/','',strrchr($imagePath,"/"));
			
		 $ext = substr($nameImg, strrpos($nameImg, '.'));
		
		 $file_name = substr($nameImg, 0,  strrpos($nameImg, '.'));
		
		 $nameImg = $file_name . "_" . $width . "_" . $height .  $ext;
		 		 
		 if(!JFile::exists($folderPath.DS.$nameImg)){
			 $image = new SimpleImage();
	  		 $image->load($imagePath);
	  		 $image->resize($width,$height);
	   		 $image->save($folderPath.DS.$nameImg);
		 }else{
		 		 list($info_width, $info_height) = @getimagesize($folderPath.DS.$nameImg);
		 		 if($width!=$info_width||$height!=$info_height){
		 		 	 $image = new SimpleImage();
	  				 $image->load($imagePath);
	  				 $image->resize($width,$height);
	   				 $image->save($folderPath.DS.$nameImg);
		 		 }
		 }
   		 return $this->url_to_resize . $nameImg;
	}
	
	function cropImage($imagePath, $width, $height) {
		global $module;
		
		$folderPath = $this->resize_folder;
		 
		if(!JFolder::exists($folderPath)){
		 		JFolder::create($folderPath);	 
		}
		 
		$nameImg = str_replace('/','',strrchr($imagePath,"/"));		 
		 
		 if(!JFile::exists($folderPath.DS.$nameImg)){
			 $image = new SimpleImage();
	  		 $image->load($imagePath);
	  		 $image->crop($width,$height);
	   		 $image->save($folderPath.DS.$nameImg);
		 }else{
		 		 list($info_width, $info_height) = @getimagesize($folderPath.DS.$nameImg);
		 		 if($width!=$info_width||$height!=$info_height){
		 		 	 $image = new SimpleImage();
	  				 $image->load($imagePath);
	  				 $image->crop($width,$height);
	   				 $image->save($folderPath.DS.$nameImg);
		 		 }
		 }
		 
   		 return $this->url_to_resize . $nameImg;
	}
	
	/**
	 * Truncates text.
	 *
	 * Cuts a string to the length of $length and replaces the last characters
	 * with the ending if the text is longer than length.
	 *
	 * @param string  $text String to truncate.
	 * @param integer $length Length of returned string, including ellipsis.
	 * @param string  $ending Ending to be appended to the trimmed string.
	 * @param boolean $exact If false, $text will not be cut mid-word
	 * @param boolean $considerHtml If true, HTML tags would be handled correctly
	 * @return string Trimmed string.
	 */
	function truncate($text, $length = 100, $ending = '...', $exact = true, $considerHtml = false) {
		if ($considerHtml) {
			// if the plain text is shorter than the maximum length, return the whole text
			if (strlen(preg_replace('/<.*?>/', '', $text)) <= $length) {
				return $text;
			}
			// splits all html-tags to scanable lines
			preg_match_all('/(<.+?>)?([^<>]*)/s', $text, $lines, PREG_SET_ORDER);
			$total_length = strlen($ending);
			$open_tags = array();
			$truncate = '';
			foreach ($lines as $line_matchings) {
				// if there is any html-tag in this line, handle it and add it (uncounted) to the output
				if (!empty($line_matchings[1])) {
					// if it's an "empty element" with or without xhtml-conform closing slash (f.e. <br/>)
					if (preg_match('/^<(\s*.+?\/\s*|\s*(img|br|input|hr|area|base|basefont|col|frame|isindex|link|meta|param)(\s.+?)?)>$/is', $line_matchings[1])) {
						// do nothing
					// if tag is a closing tag (f.e. </b>)
					} else if (preg_match('/^<\s*\/([^\s]+?)\s*>$/s', $line_matchings[1], $tag_matchings)) {
						// delete tag from $open_tags list
						$pos = array_search($tag_matchings[1], $open_tags);
						if ($pos !== false) {
							unset($open_tags[$pos]);
						}
					// if tag is an opening tag (f.e. <b>)
					} else if (preg_match('/^<\s*([^\s>!]+).*?>$/s', $line_matchings[1], $tag_matchings)) {
						// add tag to the beginning of $open_tags list
						array_unshift($open_tags, strtolower($tag_matchings[1]));
					}
					// add html-tag to $truncate'd text
					$truncate .= $line_matchings[1];
				}
				// calculate the length of the plain text part of the line; handle entities as one character
				$content_length = strlen(preg_replace('/&[0-9a-z]{2,8};|&#[0-9]{1,7};|[0-9a-f]{1,6};/i', ' ', $line_matchings[2]));
				if ($total_length+$content_length> $length) {
					// the number of characters which are left
					$left = $length - $total_length;
					$entities_length = 0;
					// search for html entities
					if (preg_match_all('/&[0-9a-z]{2,8};|&#[0-9]{1,7};|[0-9a-f]{1,6};/i', $line_matchings[2], $entities, PREG_OFFSET_CAPTURE)) {
						// calculate the real length of all entities in the legal range
						foreach ($entities[0] as $entity) {
							if ($entity[1]+1-$entities_length <= $left) {
								$left--;
								$entities_length += strlen($entity[0]);
							} else {
								// no more characters left
								break;
							}
						}
					}
					$truncate .= substr($line_matchings[2], 0, $left+$entities_length);
					// maximum lenght is reached, so get off the loop
					break;
				} else {
					$truncate .= $line_matchings[2];
					$total_length += $content_length;
				}
				// if the maximum length is reached, get off the loop
				if($total_length>= $length) {
					break;
				}
			}
		} else {
			if (strlen($text) <= $length) {
				return $text;
			} else {
				$truncate = substr($text, 0, $length - strlen($ending));
			}
		}
		// if the words shouldn't be cut in the middle...
		if (!$exact) {
			// ...search the last occurance of a space...
			$spacepos = strrpos($truncate, ' ');
			if (isset($spacepos)) {
				// ...and cut the text in this position
				$truncate = substr($truncate, 0, $spacepos);
			}
		}
		// add the defined ending to the text
		$truncate .= $ending;
		if($considerHtml) {
			// close all unclosed html-tags
			foreach ($open_tags as $tag) {
				$truncate .= '</' . $tag . '>';
			}
		}
		return $truncate;
	}

	function substrwords($text,$maxchar,$end='...'){
		if(strlen($text)>$maxchar){
			$words=explode(" ",$text);
			$output = '';
			$i=0;
			while(1){
			$length = (strlen($output)+strlen($words[$i]));
				if($length>$maxchar){
					break;
				}else{
					$output = $output." ".$words[$i];
					++$i;
				};
			};
		}else{
			$output = $text;
		}
		return $output.$end;
	}
	
}
}


?>
