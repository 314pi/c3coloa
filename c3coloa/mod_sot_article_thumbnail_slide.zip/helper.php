<?php 
/*------------------------------------------------------------------------
 # Sot Article Thumbnail Slide  - Version 1.0
 # Copyright (C) 2010-2011 Sky Of Tech. All Rights Reserved.
 # @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 # Author: Sky Of Tech
 # Websites: http://skyoftech.com
 -------------------------------------------------------------------------*/
 
defined('_JEXEC') or die('Restricted access');

if (! class_exists("modArticlesHelper") ) { 
require_once (dirname(__FILE__) .DS. 'assets' .DS.'SotArticles.php');

class modArticlesHelper {
	var $module_name = '';
	function excute($params, $module) {
		$enable_cache 		=   $params->get('cache',1);
		$cachetime			=   $params->get('cache_time',0);
		$this->module_name = $module->module;
		
		if($enable_cache==1) {		
			$conf =& JFactory::getConfig();
			$cache = &JFactory::getCache($module->module);
			$cache->setLifeTime( $params->get( 'cache_time', $conf->getValue( 'config.cachetime' ) * 60 ) );
			$cache->setCaching(true);
			$cache->setCacheValidation(true);
			$items =  $cache->get( array('modArticlesHelper', 'getArticles'), array($params, $module));
		} else {
			$items = modArticlesHelper::getArticles($params, $module);
		}		
		return $items;			
	}
	
	
	function getArticles($params, $module) {				
        $articles = new SotArticles();
        
       	$articles->sections_cates 		= $params->get('sections_cates', '');
       	$articles->article_ids 			= $params->get('article_ids', '');
	   	$articles->is_frontpage 		= $params->get('is_frontpage', 2); 
        $articles->limit 				= $params->get('total', 5);
        
        $articles->thumb_height 		= $params->get('thumb_height', "700px");
        $articles->thumb_width 			= $params->get('thumb_width', "400px");   
        $articles->small_thumb_height 	= $params->get('small_thumb_height', "70px");
        $articles->small_thumb_width 	= $params->get('small_thumb_width', "40px");
		
        $articles->sort_order_field 	= $params->get('sort_order_field', "created");
        $articles->type_order 			= $params->get('sort_order', "ASC");
		
        $articles->web_url 				= JURI::base();
        $articles->max_title        	= $params->get('limittitle',25);
        $articles->max_description      = $params->get('limit_description',25); 
        
        $articles->resize_folder 		= JPATH_CACHE.DS. $module->module .DS."images";
        $articles->url_to_resize 		= $articles->web_url . "cache/". $module->module ."/images/";
        $articles->cropresizeimage 		= $params->get('cropresizeimage', 1);
               
		
		$items = $articles->getList();
				
		return $items;
	}
}
			
} 
if(!class_exists('Browser')){
	class Browser
	{
		private $props    = array("Version" => "0.0.0",
									"Name" => "unknown",
									"Agent" => "unknown") ;
	
		public function __Construct()
		{
			$browsers = array("firefox", "msie", "opera", "chrome", "safari",
								"mozilla", "seamonkey",    "konqueror", "netscape",
								"gecko", "navigator", "mosaic", "lynx", "amaya",
								"omniweb", "avant", "camino", "flock", "aol");
	
			$this->Agent = strtolower($_SERVER['HTTP_USER_AGENT']);
			foreach($browsers as $browser)
			{
				if (preg_match("#($browser)[/ ]?([0-9.]*)#", $this->Agent, $match))
				{
					$this->Name = $match[1] ;
					$this->Version = $match[2] ;
					break ;
				}
			}
		}
	
		public function __Get($name)
		{
			if (!array_key_exists($name, $this->props))
			{
				die("No such property or function {$name}");
			}
			return $this->props[$name] ;
		}
	
		public function __Set($name, $val)
		{
			if (!array_key_exists($name, $this->props))
			{
				SimpleError("No such property or function.", "Failed to set $name", $this->props);
				die;
			}
			$this->props[$name] = $val ;
		}
	
	} 
}	
?>

