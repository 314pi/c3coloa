<?php
/*------------------------------------------------------------------------
 # Sot Article Slideshow  - Version 1.0
 # Copyright (C) 2010-2011 Sky Of Tech. All Rights Reserved.
 # @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 # Author: Sky Of Tech
 # Websites: http://skyoftech.com
 -------------------------------------------------------------------------*/

// Check to ensure this file is within the rest of the framework
defined('JPATH_BASE') or die();
/**
* Renders the TC logo
*
* @package Joomla.Framework
* @subpackage Parameter
* @since 1.5
*/
class JElementLogo extends JElement
{
/**
* Element name
*
* @access protected
* @var string
*/
var $_name = 'Logo';
function fetchTooltip($label, $description, &$node, $control_name, $name) {
return '&nbsp;';
}
function fetchElement($name, $value, &$node, $control_name)
{
if ($value) {
return JText::_($value);
} else {
$db = &JFactory::getDBO();
$module_id = isset($_REQUEST['cid'][0])?$_REQUEST['cid'][0]:(isset($_REQUEST['cid'])?$_REQUEST['cid']:0);
if(!$module_id) $module_id = (isset($_REQUEST['id']))?$_REQUEST['id']:0;
$q = "SELECT module FROM `#__modules` WHERE id=".$module_id;
$db->setQuery($q);
$module_name = "";
if($result = $db->loadObjectList()){
	$module_name = $result[0]->module;
}

return '<a href="http://skyoftech.com" target="_blank"><img border="0" src="../modules/'.$module_name.'/elements/logo.gif"  title="skyoftech.com" alt="skyoftech.com" ></a>';
}
}
}