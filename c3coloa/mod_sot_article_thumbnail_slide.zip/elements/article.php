<?php
/*------------------------------------------------------------------------
 # Sot Article Slideshow  - Version 1.0
 # Copyright (C) 2010-2011 Sky Of Tech. All Rights Reserved.
 # @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 # Author: Sky Of Tech
 # Websites: http://skyoftech.com
 -------------------------------------------------------------------------*/

class JElementArticle extends JElement {
  var   $_name = 'article';
  function fetchElement($name, $value, &$node, $control_name){
  		$document = &JFactory::getDocument();
  		
  		$db = &JFactory::getDBO();

  		/*SHOW SECTIONS & CATEGORIES*/
  		$listSecCat  = "<div id='sections_cats'>";
  		$query = "SELECT title,id FROM `#__sections` WHERE `published`='1'";
  		$db->setQuery($query);
  		$sections = $db->loadObjectList();
  		
		$query = "SELECT c.title, c.id, s.title as section_title, s.id as section_id FROM `#__categories` c INNER JOIN `#__sections` s ON s.id = c.section WHERE c.published='1'";
  		$db->setQuery($query);
  		$categories = $db->loadObjectList();

		
  		foreach ($sections as $key=>$s){
			//var_dump(JHTML::_('select.option', 'sec-'.$s->id, $s->title.'&nbsp;(Section)'));die;
			$sec[$key]			= JHTML::_('select.option', 'sec-'.$s->id, $s->title.'&nbsp;(Section)');
			$cates_ids = array();
			foreach ($categories as $key1=>$c){
				
				if($c->section_id==$s->id){
					$cates_ids[] 	= $c->id;
					$sec[$key.$key1]			= JHTML::_('select.option', 'cat-'.$c->id.'-'.$s->id, '&nbsp;&nbsp;&nbsp;|-- ' . $c->title);
				}
			}
			
			$sec[$key]->value .= '-'.implode(",",$cates_ids);
			
		}
		$lists['sections-cates']	= JHTML::_('select.genericlist', $sec,$control_name."[sections_cates][]", 'class="inputbox" size="12"  style="width:100%"  multiple="multiple"', 'value', 'text',$this->_parent->get('sections_cates'));
  		$listSecCat .= $lists['sections-cates'];
  		$listSecCat .= "</div>" ;
  		/*SHOW SECTIONS & CATEGORIES*/
  		  		
  		$listSecCat .= "</div>" ;  		

    return  $listSecCat;

  }
}
?>
		

				