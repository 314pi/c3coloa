<?php
# $Id: vi-VN.ignore.ini 2009-10-25 11:16:20 vhv_alex $
# Joomla! Vietnamese Translation
# Copyright (C) 2005 - 2009 Open Source Matters. All rights reserved.
# Copyright (C) Translation 2006- 2009 Joomlaviet.org
# License http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL, see LICENSE.php
# Note : All ini files need to be saved as UTF-8 - No BOM

$search_ignore[] = "và";
$search_ignore[] = "trong";
$search_ignore[] = "trên";
?>